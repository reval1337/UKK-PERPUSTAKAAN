// ============================================================================
// SCREEN - User History (Riwayat Peminjaman Siswa)
// ============================================================================
// Halaman untuk menampilkan seluruh catatan transaksi buku yang pernah dilakukan
// oleh siswa, baik yang masih dipinjam maupun yang sudah dikembalikan.

import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../../services/firestore_service.dart';
import '../../services/auth_service.dart';

class UserHistoryScreen extends StatefulWidget {
  const UserHistoryScreen({super.key});

  @override
  State<UserHistoryScreen> createState() => _UserHistoryScreenState();
}

class _UserHistoryScreenState extends State<UserHistoryScreen> {
  final _fs = FirestoreService.instance;
  
  // Koleksi transaksi (gabungan aktif dan selesai)
  List<Map<String, dynamic>> _transactions = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadHistory();
  }

  // --------------------------------------------------------------------------
  // LOAD DATA - Mengambil semua riwayat transaksi dari Firestore
  // --------------------------------------------------------------------------
  Future<void> _loadHistory() async {
    setState(() => _isLoading = true);
    final user = await AuthService.instance.getCurrentUser();
    
    if (user != null && user.memberId != null) {
      try {
        final transactions = await _fs.getTransactionsByMember(user.memberId!);
        setState(() {
          _transactions = transactions;
          _isLoading = false;
        });
      } catch (e) {
        setState(() => _isLoading = false);
      }
    } else {
      setState(() => _isLoading = false);
    }
  }

  // HELPER - Menentukan warna badge berdasarkan status transaksi
  Color _getStatusColor(String status) {
    switch (status) {
      case 'dipinjam':
        return Colors.orange;      // Masih di tangan siswa
      case 'dikembalikan':
        return Colors.green;       // Sudah selesai
      case 'terlambat':
        return Colors.red;         // Melewati jatuh tempo
      default:
        return Colors.grey;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Riwayat Peminjaman'),
        backgroundColor: Colors.orange,
        foregroundColor: Colors.white,
        elevation: 0,
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _transactions.isEmpty
          ? Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.history_rounded, size: 72, color: Colors.grey.shade300),
                  const SizedBox(height: 16),
                  const Text('Belum ada catatan aktivitas.', style: TextStyle(fontSize: 16, color: Colors.grey, fontWeight: FontWeight.w500)),
                ],
              ),
            )
          : ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: _transactions.length,
              itemBuilder: (context, index) {
                final t = _transactions[index];
                final status = t['status'] as String;
                
                // Parsing tanggal-tanggal transaksi dengan null safety
                final tglPinjamStr = t['tanggal_pinjam'] as String?;
                final tglTempoStr = t['tanggal_jatuh_tempo'] as String?;
                final tglKembaliStr = t['tanggal_kembali'] as String?;
                
                final tglPinjam = tglPinjamStr != null ? DateTime.tryParse(tglPinjamStr) : null;
                final tglTempo = tglTempoStr != null ? DateTime.tryParse(tglTempoStr) : null;
                final tglKembali = tglKembaliStr != null ? DateTime.tryParse(tglKembaliStr) : null;
                
                // Fallback jika tanggal null
                final displayTglPinjam = tglPinjam ?? DateTime.now();
                final displayTglTempo = tglTempo ?? DateTime.now().add(const Duration(days: 7));
                final displayTglKembali = tglKembali;

                return Card(
                  margin: const EdgeInsets.only(bottom: 12),
                  elevation: 2,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        // BARIS ATAS: Judul Buku & Badge Status
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(t['book_judul'] as String? ?? 'Judul tidak tersedia', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                                  Text('Penulis: ${t['book_pengarang'] as String? ?? 'Tidak diketahui'}', style: TextStyle(color: Colors.grey.shade600, fontSize: 13)),
                                ],
                              ),
                            ),
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                              decoration: BoxDecoration(color: _getStatusColor(status).withOpacity(0.1), borderRadius: BorderRadius.circular(20)),
                              child: Text(status.toUpperCase(), style: TextStyle(color: _getStatusColor(status), fontWeight: FontWeight.bold, fontSize: 11)),
                            ),
                          ],
                        ),
                        const Divider(height: 24),
                        
                        // INFO TANGGAL
                        _buildInfoRow(Icons.calendar_today, 'Tanggal Pinjam', DateFormat('dd MMM yyyy').format(displayTglPinjam)),
                        _buildInfoRow(Icons.event, 'Jatuh Tempo', DateFormat('dd MMM yyyy').format(displayTglTempo)),
                        
                        if (displayTglKembali != null)
                          _buildInfoRow(Icons.check_circle_outline, 'Dikembalikan pada', DateFormat('dd MMM yyyy').format(displayTglKembali), iconColor: Colors.green),
                        
                        // INFO DENDA (Jika ada)
                        if (t['denda'] != null && t['denda'] > 0)
                          Padding(
                            padding: const EdgeInsets.only(top: 8),
                            child: Row(
                              children: [
                                const Icon(Icons.payments_outlined, size: 16, color: Colors.red),
                                const SizedBox(width: 8),
                                Text('Denda Terbayar: Rp ${NumberFormat('#,##0').format(t['denda'])}', style: const TextStyle(color: Colors.red, fontWeight: FontWeight.bold, fontSize: 13)),
                              ],
                            ),
                          ),
                      ],
                    ),
                  ),
                );
              },
            ),
    );
  }

  // HELPER WIDGET - Baris Info Transaksi
  Widget _buildInfoRow(IconData icon, String label, String value, {Color iconColor = Colors.grey}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 4),
      child: Row(
        children: [
          Icon(icon, size: 14, color: iconColor),
          const SizedBox(width: 8),
          Text('$label: ', style: const TextStyle(fontSize: 12, color: Colors.grey)),
          Text(value, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w500)),
        ],
      ),
    );
  }
}

