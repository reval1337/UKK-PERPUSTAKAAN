// ============================================================================
// SCREEN - User Return (Siswa Mengembalikan Buku)
// ============================================================================
// Halaman bagi siswa untuk melihat daftar buku yang sedang mereka pinjam
// dan melakukan proses pengembalian serta melihat hitungan denda jika terlambat.

import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../../services/firestore_service.dart';
import '../../services/auth_service.dart';
import '../../services/pdf_service.dart';

class UserReturnScreen extends StatefulWidget {
  const UserReturnScreen({super.key});

  @override
  State<UserReturnScreen> createState() => _UserReturnScreenState();
}

class _UserReturnScreenState extends State<UserReturnScreen> {
  final _fs = FirestoreService.instance;
  
  // Koleksi buku yang sedang dipinjam (Filter status: 'dipinjam')
  List<Map<String, dynamic>> _borrowedBooks = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadBorrowedBooks();
  }

  // --------------------------------------------------------------------------
  // LOAD DATA - Mengambil daftar buku milik user yang berstatus 'dipinjam'
  // --------------------------------------------------------------------------
  Future<void> _loadBorrowedBooks() async {
    final user = await AuthService.instance.getCurrentUser();
    if (user != null && user.memberId != null) {
      try {
        final transactions = await _fs.getTransactionsByMember(user.memberId!);
        // Hanya tampilkan yang belum dikembalikan
        final borrowed = transactions.where((t) => t['status'] == 'dipinjam').toList();
        setState(() {
          _borrowedBooks = borrowed;
          _isLoading = false;
        });
      } catch (e) {
        setState(() => _isLoading = false);
      }
    } else {
      setState(() => _isLoading = false);
    }
  }

  // --------------------------------------------------------------------------
  // RETURN ACTION - Logika pengembalian buku dan hitung denda
  // --------------------------------------------------------------------------
  Future<void> _returnBook(Map<String, dynamic> transactionData) async {
    if (transactionData['status'] == 'dikembalikan') return;
    
    // Tampilkan loading dialog
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => const Center(child: CircularProgressIndicator()),
    );

    final now = DateTime.now();
    int? fine;
    
    try {
      final user = await AuthService.instance.getCurrentUser();
      final member = user?.memberId != null ? await _fs.getMemberByDocId(user!.memberId!) : null;
      
      // Update status di Firestore
      await _fs.returnBook(
        transactionDocId: transactionData['docId'] as String,
        tanggalKembali: now,
      );
      
      // Hitung denda: Rp 1.000 per hari keterlambatan
      final jatuhTempo = DateTime.parse(transactionData['tanggal_jatuh_tempo'] as String);
      if (now.isAfter(jatuhTempo)) {
        fine = now.difference(jatuhTempo).inDays * 1000;
      }
      
      if (mounted) {
        Navigator.pop(context); // Tutup loading
        
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(fine != null && fine > 0
                ? 'Berhasil! Denda keterlambatan: Rp ${NumberFormat('#,##0').format(fine)}'
                : 'Buku berhasil dikembalikan tepat waktu.'),
            backgroundColor: Colors.green,
          ),
        );
        
        // Munculkan dialog struk pengembalian
        _showReturnReceiptDialog(
          bookTitle: transactionData['book_judul'] as String,
          memberName: member?['nama'] ?? user?.username ?? '-',
          memberNis: member?['nis'] ?? '-',
          returnDate: now,
          fine: fine,
        );
        
        _loadBorrowedBooks(); // Segarkan list (buku yang baru dibalikin harus hilang)
      }
    } catch (e) {
      if (mounted) {
        Navigator.pop(context);
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Error: $e'), backgroundColor: Colors.red));
      }
    }
  }

  // DIALOG - Opsi Cetak Bukti Pengembalian (PDF)
  void _showReturnReceiptDialog({
    required String bookTitle,
    required String memberName,
    required String memberNis,
    required DateTime returnDate,
    int? fine,
  }) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Pengembalian Berhasil!'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.check_circle, color: Colors.green, size: 64),
            const SizedBox(height: 16),
            Text('Buku "$bookTitle" telah kembali.', textAlign: TextAlign.center),
            const SizedBox(height: 8),
            Text('Tanggal: ${DateFormat('dd/MM/yyyy').format(returnDate)}', style: const TextStyle(fontWeight: FontWeight.bold)),
            if (fine != null && fine > 0) ...[
              const SizedBox(height: 8),
              Text('Denda: Rp ${NumberFormat('#,##0').format(fine)}', style: const TextStyle(color: Colors.red, fontWeight: FontWeight.bold)),
            ],
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Tutup')),
          ElevatedButton.icon(
            onPressed: () {
              Navigator.pop(context);
              // Cetak bukti PDF via PdfService
              PdfService.generateReturnReceipt(
                context,
                bookTitle: bookTitle,
                memberName: memberName,
                memberNis: memberNis,
                returnDate: returnDate,
                fine: fine,
              );
            },
            icon: const Icon(Icons.print),
            label: const Text('Cetak Bukti'),
            style: ElevatedButton.styleFrom(backgroundColor: Colors.green, foregroundColor: Colors.white),
          ),
        ],
      ),
    );
  }

  // LOGIKA WARNA - Menentukan warna status berdasarkan sisa waktu pinjam
  Color _getDueDateColor(DateTime dueDate) {
    final now = DateTime.now();
    final daysUntilDue = dueDate.difference(now).inDays;
    if (daysUntilDue < 0) return Colors.red;        // Terlambat (Warning)
    if (daysUntilDue <= 2) return Colors.orange;    // Hampir habis (Caution)
    return Colors.green;                            // Aman
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Kembalikan Buku'),
        backgroundColor: Colors.green,
        foregroundColor: Colors.white,
        elevation: 0,
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _borrowedBooks.isEmpty
          ? Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.assignment_turned_in_rounded, size: 72, color: Colors.grey.shade300),
                  const SizedBox(height: 16),
                  const Text('Hebat! Kamu tidak punya tanggungan buku.', style: TextStyle(fontSize: 16, color: Colors.grey, fontWeight: FontWeight.w500)),
                ],
              ),
            )
          : ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: _borrowedBooks.length,
              itemBuilder: (context, index) {
                final t = _borrowedBooks[index];
                final tglPinjam = DateTime.parse(t['tanggal_pinjam'] as String);
                final tglTempo = DateTime.parse(t['tanggal_jatuh_tempo'] as String);
                final slisihHari = tglTempo.difference(DateTime.now()).inDays;

                return Card(
                  margin: const EdgeInsets.only(bottom: 16),
                  elevation: 3,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        // INFO BUKU & LABEL TERLAMBAT
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Expanded(
                              child: Text(t['book_judul'] as String, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 17)),
                            ),
                            if (slisihHari < 0)
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                                decoration: BoxDecoration(color: Colors.red.shade100, borderRadius: BorderRadius.circular(20)),
                                child: const Text('TERLAMBAT', style: TextStyle(color: Colors.red, fontWeight: FontWeight.bold, fontSize: 11)),
                              ),
                          ],
                        ),
                        Text('Penulis: ${t['book_pengarang']}', style: TextStyle(color: Colors.grey.shade600, fontSize: 13)),
                        const Divider(height: 24),
                        
                        // INFO TANGGAL
                        _buildDateInfo(Icons.calendar_today, 'Pinjam', tglPinjam, Colors.grey),
                        const SizedBox(height: 8),
                        _buildDateInfo(Icons.event, 'Batas Kembali', tglTempo, _getDueDateColor(tglTempo), isBold: true),
                        
                        // INFO KETERLAMBATAN
                        if (slisihHari < 0) ...[
                          const SizedBox(height: 8),
                          Row(
                            children: [
                              const Icon(Icons.warning_amber_rounded, size: 16, color: Colors.red),
                              const SizedBox(width: 8),
                              Text('Telat ${slisihHari.abs()} hari (Denda berjalan)', style: const TextStyle(color: Colors.red, fontWeight: FontWeight.bold, fontSize: 13)),
                            ],
                          ),
                        ],
                        
                        const SizedBox(height: 16),
                        // TOMBOL KEMBALIKAN
                        SizedBox(
                          width: double.infinity,
                          child: ElevatedButton.icon(
                            onPressed: () => _returnBook(t),
                            icon: const Icon(Icons.keyboard_return_rounded),
                            label: const Text('Kembalikan Sekarang'),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.green,
                              foregroundColor: Colors.white,
                              padding: const EdgeInsets.symmetric(vertical: 14),
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
    );
  }

  // HELPER WIDGET - Baris Info Tanggal
  Widget _buildDateInfo(IconData icon, String label, DateTime date, Color color, {bool isBold = false}) {
    return Row(
      children: [
        Icon(icon, size: 16, color: color),
        const SizedBox(width: 8),
        Text('$label: ', style: const TextStyle(fontSize: 13)),
        Text(DateFormat('dd MMMM yyyy').format(date), style: TextStyle(fontSize: 13, color: color, fontWeight: isBold ? FontWeight.bold : FontWeight.normal)),
      ],
    );
  }
}

