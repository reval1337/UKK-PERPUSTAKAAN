
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'dart:ui';
import '../../services/auth_service.dart';
import '../../services/firestore_service.dart';
import '../../widgets/custom_snackbar.dart';
import '../login_screen.dart';
import 'user_borrow_screen.dart';
import 'user_return_screen.dart';
import 'user_history_screen.dart';
import 'user_profile_screen.dart';

class UserDashboard extends StatefulWidget {
  const UserDashboard({super.key});

  @override
  State<UserDashboard> createState() => _UserDashboardState();
}

class _UserDashboardState extends State<UserDashboard> with SingleTickerProviderStateMixin {
  final _fs = FirestoreService.instance;
  final _auth = AuthService.instance;
  
  // Data State
  Map<String, dynamic>? _memberInfo;
  int _activeBorrows = 0;
  bool _isLoading = true;
  var _currentUser;

  // Animation
  late AnimationController _animationController;
  late Animation<double> _fadeAnimation;
  late Animation<Offset> _slideAnimation;

  @override
  void initState() {
    super.initState();
    // Animation Setup
    _animationController = AnimationController(
      duration: const Duration(milliseconds: 800),
      vsync: this,
    );
    
    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _animationController, curve: Curves.easeOut),
    );
    
    _slideAnimation = Tween<Offset>(begin: const Offset(0, 0.1), end: Offset.zero).animate(
      CurvedAnimation(parent: _animationController, curve: Curves.easeOutCubic),
    );
    
    _animationController.forward();
    
    _loadUserData();
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  Future<void> _loadUserData() async {
    final user = await _auth.getCurrentUser();
    if (user != null) {
      if (!mounted) return;
      setState(() => _currentUser = user);
      
      // Default info if not linked to a member
      if (user.memberId == null || user.memberId!.isEmpty) {
        if (!mounted) return;
        setState(() {
          _isLoading = false;
          _memberInfo = {
            'nama': user.username,
            'nis': 'Belum Terdaftar',
            'kelas': '-',
          };
          _activeBorrows = 0;
        });
        return;
      }

      // Fetch member data
      Map<String, dynamic>? member;
      try {
        member = await _fs.getMemberByDocId(user.memberId!);
      } catch (e) {
        member = null;
      }
      
      // Calculate active borrows
      int activeCount = 0;
      try {
        final transactions = await _fs.getTransactionsByMember(user.memberId!);
        activeCount = transactions.where((t) => t['status'] == 'dipinjam').length;
      } catch (e) {
        activeCount = 0;
      }

      if (!mounted) return;
      setState(() {
        _isLoading = false;
        _activeBorrows = activeCount;
        if (member != null) {
          _memberInfo = {
            'id': member['docId'],
            'nama': member['nama'],
            'nis': member['nis'],
            'kelas': member['kelas'],
          };
        } else {
          _memberInfo = {
            'nama': user.username,
            'nis': '-',
            'kelas': '-',
          };
        }
      });
    }
  }

  // --- Main Build ---
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF2F2F7), // iOS Light Background
      body: Stack(
        children: [
          // Background Decor (Gradient Blooms)
          Positioned(
            top: -100,
            right: -100,
            child: Container(
              width: 300,
              height: 300,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: RadialGradient(
                  colors: [
                    const Color(0xFF00C7BE).withOpacity(0.2), // Teal
                    const Color(0xFF00C7BE).withOpacity(0.0),
                  ],
                ),
              ),
            ),
          ),
          Positioned(
            top: 200,
            left: -150,
            child: Container(
              width: 350,
              height: 350,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: RadialGradient(
                  colors: [
                    const Color(0xFF007AFF).withOpacity(0.15), // Blue
                    const Color(0xFF007AFF).withOpacity(0.0),
                  ],
                ),
              ),
            ),
          ),

          SafeArea(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                const SizedBox(height: 10),
                // Header
                _buildHeader(context),
                
                const SizedBox(height: 10),
                
                // Content
                Expanded(
                  child: _isLoading 
                    ? const Center(child: CircularProgressIndicator())
                    : FadeTransition(
                        opacity: _fadeAnimation,
                        child: SlideTransition(
                          position: _slideAnimation,
                          child: ListView(
                            padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 10),
                            physics: const BouncingScrollPhysics(),
                            children: [
                              _buildHeroCard(),
                              const SizedBox(height: 30),
                              
                              // Section Title
                              Padding(
                                padding: const EdgeInsets.only(left: 4, bottom: 16),
                                child: Text(
                                  "AKTIVITAS PUSTAKA",
                                  style: GoogleFonts.poppins(
                                    fontSize: 13,
                                    fontWeight: FontWeight.w600,
                                    letterSpacing: 1.2,
                                    color: const Color(0xFF8E8E93),
                                  ),
                                ),
                              ),
                              
                              // Menu Grid (iOS Widget Style)
                              GridView.count(
                                shrinkWrap: true,
                                physics: const NeverScrollableScrollPhysics(),
                                crossAxisCount: 2,
                                crossAxisSpacing: 16,
                                mainAxisSpacing: 16,
                                childAspectRatio: 1.0,
                                children: [
                                  _buildMenuTile(
                                    context,
                                    title: 'Pinjam',
                                    subtitle: 'Katalog Buku',
                                    icon: Icons.search_rounded, // Changed to Search to imply finding books
                                    color: const Color(0xFF007AFF), // iOS Blue
                                    onTap: () async {
                                      await Navigator.push(context, MaterialPageRoute(builder: (_) => const UserBorrowScreen()));
                                      _loadUserData();
                                    },
                                  ),
                                  _buildMenuTile(
                                    context,
                                    title: 'Kembali',
                                    subtitle: 'Scan QRCode',
                                    icon: Icons.qr_code_scanner_rounded,
                                    color: const Color(0xFF34C759), // iOS Green
                                    onTap: () async {
                                      await Navigator.push(context, MaterialPageRoute(builder: (_) => const UserReturnScreen()));
                                      _loadUserData();
                                    },
                                  ),
                                  _buildMenuTile(
                                    context,
                                    title: 'Riwayat',
                                    subtitle: 'Log Aktivitas',
                                    icon: Icons.history_edu_rounded,
                                    color: const Color(0xFFFF9500), // iOS Orange
                                    onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const UserHistoryScreen())),
                                  ),
                                  _buildMenuTile(
                                    context,
                                    title: 'Profil',
                                    subtitle: 'Data Diri',
                                    icon: Icons.person_rounded,
                                    color: const Color(0xFFFF2D55), // iOS Pink
                                    onTap: () async {
                                      await Navigator.push(context, MaterialPageRoute(builder: (_) => const UserProfileScreen()));
                                      _loadUserData();
                                    },
                                  ),
                                ],
                              ),
                              
                              const SizedBox(height: 40),
                              
                              Center(
                                child: Text(
                                  "Perpustakaan Digital v1.0",
                                  style: GoogleFonts.poppins(
                                    fontSize: 12,
                                    color: Colors.grey.shade400,
                                  ),
                                ),
                              ),
                              const SizedBox(height: 20),
                            ],
                          ),
                        ),
                      ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // --- Header ---
  Widget _buildHeader(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 8),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            children: [
              // Profile Picture Placeholder with Border
              Container(
                height: 44,
                width: 44,
                decoration: BoxDecoration(
                  color: Colors.white,
                  shape: BoxShape.circle,
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.05),
                      blurRadius: 10,
                      offset: const Offset(0, 2),
                    ),
                  ],
                  border: Border.all(color: Colors.white, width: 2),
                ),
                child: ClipOval(
                  child: _currentUser?.photoUrl != null
                      ? Image.network(_currentUser!.photoUrl!, fit: BoxFit.cover)
                      : Container(
                          color: const Color(0xFF007AFF).withOpacity(0.1),
                          child: Center(
                            child: Text(
                              _memberInfo?['nama']?.substring(0, 1).toUpperCase() ?? 'S',
                              style: GoogleFonts.poppins(
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                                color: const Color(0xFF007AFF),
                              ),
                            ),
                          ),
                        ),
                ),
              ),
              const SizedBox(width: 12),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                   Text(
                    'Selamat Datang,',
                    style: GoogleFonts.poppins(
                      fontSize: 12,
                      color: const Color(0xFF8E8E93), // iOS Gray
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  Text(
                    (_memberInfo?['nama'] ?? 'Siswa').split(' ')[0], // First name only
                    style: GoogleFonts.poppins(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      color: const Color(0xFF1C1C1E),
                    ),
                  ),
                ],
              ),
            ],
          ),
          
          // Logout Button (Small)
          Material(
            color: Colors.transparent,
            child: InkWell(
              onTap: () => _handleLogout(context),
              borderRadius: BorderRadius.circular(50),
              child: Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: Colors.white,
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.05),
                      blurRadius: 10,
                      offset: const Offset(0, 2),
                    ),
                  ],
                ),
                child: const Icon(
                  Icons.logout_rounded,
                  color: Color(0xFFFF3B30), // iOS Red
                  size: 20,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // --- Hero Card (Status Info) ---
  Widget _buildHeroCard() {
    return Container(
      width: double.infinity,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(28),
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            Color(0xFF007AFF), // Blue
            Color(0xFF5AC8FA), // Light Blue
          ],
        ),
        boxShadow: [
          BoxShadow(
            color: const Color(0xFF007AFF).withOpacity(0.3),
            blurRadius: 24,
            offset: const Offset(0, 12),
          ),
        ],
      ),
      child: Stack(
        children: [
          // Background Icon
          Positioned(
            right: -20,
            top: -20,
            child: Icon(
              Icons.auto_stories_rounded,
              size: 160,
              color: Colors.white.withOpacity(0.15),
            ),
          ),
          
          Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Top Badge (Class & NIS)
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.25),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Text(
                        _memberInfo?['kelas'] ?? 'Kelas -',
                        style: GoogleFonts.poppins(
                          color: Colors.white,
                          fontSize: 12,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                    Text(
                      _memberInfo?['nis'] ?? '',
                      style: GoogleFonts.poppins(
                        color: Colors.white.withOpacity(0.9),
                        fontSize: 14,
                        fontWeight: FontWeight.w600,
                        letterSpacing: 1,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 28),
                Text(
                  'Buku Dipinjam',
                  style: GoogleFonts.poppins(
                    color: Colors.white.withOpacity(0.9),
                    fontSize: 14,
                    fontWeight: FontWeight.w500,
                  ),
                ),
                
                // Big Number
                Row(
                  crossAxisAlignment: CrossAxisAlignment.baseline,
                  textBaseline: TextBaseline.alphabetic,
                  children: [
                    Text(
                      '$_activeBorrows',
                      style: GoogleFonts.poppins(
                        color: Colors.white,
                        fontSize: 56,
                        fontWeight: FontWeight.bold,
                        height: 1.0,
                      ),
                    ),
                    const SizedBox(width: 8),
                    Text(
                      'buku',
                      style: GoogleFonts.poppins(
                        color: Colors.white.withOpacity(0.8),
                        fontSize: 18,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                
                // Progress Bar Visual
                LayoutBuilder(
                  builder: (context, constraints) {
                    return Stack(
                      children: [
                        Container(
                          width: double.infinity,
                          height: 6,
                          decoration: BoxDecoration(
                            color: Colors.black.withOpacity(0.1),
                            borderRadius: BorderRadius.circular(3),
                          ),
                        ),
                        FractionallySizedBox(
                          widthFactor: (_activeBorrows > 3 ? 3 : _activeBorrows) / 3, // Logic: 3 is max "visual" limit
                          child: Container(
                            height: 6,
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(3),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.white.withOpacity(0.5),
                                  blurRadius: 6,
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    );
                  }
                ),
                
                const SizedBox(height: 12),
                Text(
                  _activeBorrows > 0 
                      ? 'Jangan lupa kembalikan tepat waktu ya!' 
                      : 'Ayo mulai membaca hari ini!',
                  style: GoogleFonts.poppins(
                    color: Colors.white.withOpacity(0.95),
                    fontSize: 12,
                    fontStyle: FontStyle.italic,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // --- Menu Tile ---
  Widget _buildMenuTile(
    BuildContext context, {
    required String title,
    required String subtitle,
    required IconData icon,
    required Color color,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(24),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.04), // Subtle shadow
              blurRadius: 16,
              offset: const Offset(0, 8),
            ),
          ],
        ),
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              // Icon Container
              Container(
                width: 44,
                height: 44,
                decoration: BoxDecoration(
                  color: color.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(14),
                ),
                child: Icon(icon, color: color, size: 22),
              ),
              
              // Text Info
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: GoogleFonts.poppins(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      color: const Color(0xFF1C1C1E),
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    subtitle,
                    style: GoogleFonts.poppins(
                      fontSize: 11,
                      color: const Color(0xFF8E8E93),
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  // --- Logout Logic with New Notification ---
  Future<void> _handleLogout(BuildContext context) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
        backgroundColor: Colors.white,
        title: Text('Konfirmasi', style: GoogleFonts.poppins(fontWeight: FontWeight.bold)),
        content: Text('Apakah Anda yakin ingin keluar dari aplikasi?', style: GoogleFonts.poppins()),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: Text('Batal', style: GoogleFonts.poppins(color: Colors.grey)),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(context, true),
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFFFF3B30),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              elevation: 0,
            ),
            child: Text('Keluar', style: GoogleFonts.poppins(color: Colors.white, fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );

    if (confirm == true) {
      await AuthService.instance.logout();
      if (mounted) {
        // Use the new CustomSnackBar
        CustomSnackBar.show(
          context,
          message: 'Sampai jumpa lagi!',
          isSuccess: true,
        );
        Navigator.of(context).pushAndRemoveUntil(
          MaterialPageRoute(builder: (_) => const LoginScreen()),
          (route) => false,
        );
      }
    }
  }
}
