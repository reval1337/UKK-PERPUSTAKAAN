// ============================================================================
// SCREEN - User Profile Modern UI (Premium)
// ============================================================================
// Halaman profil profesional untuk siswa dengan desain modern.
// Menggunakan efek bayangan lembut, gradasi, dan animasi sederhana.

import 'dart:io' as io;
import 'package:flutter/foundation.dart'; // Support Web
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:image_picker/image_picker.dart';
import 'package:firebase_storage/firebase_storage.dart';
import '../../services/auth_service.dart';
import '../../services/firestore_service.dart';
import '../../models/user.dart';

class UserProfileScreen extends StatefulWidget {
  const UserProfileScreen({super.key});

  @override
  State<UserProfileScreen> createState() => _UserProfileScreenState();
}

class _UserProfileScreenState extends State<UserProfileScreen> with SingleTickerProviderStateMixin {
  final _fs = FirestoreService.instance;
  final _auth = AuthService.instance;

  User? _currentUser;
  Map<String, dynamic>? _memberInfo;
  bool _isLoading = true;
  bool _isUploading = false;

  final _nameController = TextEditingController();
  final _bioController = TextEditingController();
  
  // Animation Controller for staggered entrance
  late AnimationController _animController;
  late Animation<double> _fadeAnim;
  late Animation<Offset> _slideAnim;

  @override
  void initState() {
    super.initState();
    
    // Setup Animations
    _animController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    );
    _fadeAnim = CurvedAnimation(parent: _animController, curve: Curves.easeOut);
    _slideAnim = Tween<Offset>(begin: const Offset(0, 0.1), end: Offset.zero).animate(
      CurvedAnimation(parent: _animController, curve: Curves.easeOutCubic),
    );

    _loadUserData();
  }

  @override
  void dispose() {
    _nameController.dispose();
    _bioController.dispose();
    _animController.dispose();
    super.dispose();
  }

  Future<void> _loadUserData() async {
    // setState(() => _isLoading = true); // Optional: avoid full spinner for simple refresh

    final user = await _auth.getCurrentUser();
    if (user != null) {
      _currentUser = user;
      _nameController.text = user.username;
      _bioController.text = user.bio ?? '';

      if (user.memberId != null) {
        final member = await _fs.getMemberByDocId(user.memberId!);
        if (member != null) {
          setState(() => _memberInfo = member);
        }
      }
    }
    
    setState(() => _isLoading = false);
    _animController.forward(); // Trigger animation
  }

  // --- UPLOAD PHOTO LOGIC ---
  Future<void> _pickAndUploadImage() async {
    final ImagePicker picker = ImagePicker();
    
    try {
      print('🔍 DEBUG: Starting image pick process...');
      
      // Tampilkan source selection dialog untuk web
      final ImageSource? source = await showDialog<ImageSource>(
        context: context,
        builder: (context) => AlertDialog(
          title: const Text('Pilih Sumber Foto'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              ListTile(
                leading: const Icon(Icons.photo_library),
                title: const Text('Galeri'),
                onTap: () => Navigator.pop(context, ImageSource.gallery),
              ),
              ListTile(
                leading: const Icon(Icons.camera_alt),
                title: const Text('Kamera'),
                onTap: () => Navigator.pop(context, ImageSource.camera),
              ),
            ],
          ),
        ),
      );

      if (source == null) {
        print('🔍 DEBUG: No source selected');
        return;
      }

      print('🔍 DEBUG: Picking image from $source...');
      final XFile? image = await picker.pickImage(
        source: source,
        maxWidth: 512,
        maxHeight: 512,
        imageQuality: 80,
      );

      if (image == null) {
        print('🔍 DEBUG: Image is null, cancelled by user');
        return;
      }

      print('🔍 DEBUG: Image picked: ${image.name}');
      setState(() => _isUploading = true);

      // Create unique filename
      final fileName = '${_currentUser?.id ?? 'user'}_${DateTime.now().millisecondsSinceEpoch}.jpg';
      print('🔍 DEBUG: Uploading as: $fileName');

      final storageRef = FirebaseStorage.instance
          .ref()
          .child('profile_photos')
          .child(fileName);

      // Handle both web and native
      if (kIsWeb) {
        print('🔍 DEBUG: Uploading via web (putData)...');
        final bytes = await image.readAsBytes();
        print('🔍 DEBUG: Image size: ${bytes.length} bytes');
        await storageRef.putData(
          bytes,
          SettableMetadata(contentType: 'image/jpeg'),
        );
      } else {
        print('🔍 DEBUG: Uploading via native (putFile)...');
        await storageRef.putFile(io.File(image.path));
      }

      print('🔍 DEBUG: Upload complete, getting download URL...');
      final downloadUrl = await storageRef.getDownloadURL();
      print('🔍 DEBUG: Got download URL: $downloadUrl');

      // Update Firestore
      print('🔍 DEBUG: Updating Firestore user document...');
      await _fs.updateUser(
        _currentUser?.id ?? '',
        {'photo_url': downloadUrl},
      );
      
      await _loadUserData();
      
      print('✅ DEBUG: Profile photo updated successfully!');
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: const Text('Foto profil berhasil di-update!'),
            backgroundColor: const Color(0xFF10B981),
            behavior: SnackBarBehavior.floating,
          ),
        );
      }
    } catch (e, stack) {
      print('❌ DEBUG: Error uploading photo: $e');
      print('❌ DEBUG: Stack trace: $stack');
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Gagal upload: $e'), backgroundColor: Colors.red),
        );
      }
    } finally {
      if (mounted) {
        setState(() => _isUploading = false);
      }
    }
  }

  // --- EDIT DIALOG ---
  Future<void> _showEditDialog({
    required String title,
    required TextEditingController controller,
    required String field,
    int maxLines = 1,
    int? maxLength,
    IconData? icon,
  }) async {
    final result = await showDialog<bool>(
      context: context,
      builder: (context) => Dialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24.r)),
        elevation: 0,
        backgroundColor: Colors.transparent,
        child: Container(
          padding: EdgeInsets.all(24.w),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(24.r),
            boxShadow: [
              BoxShadow(color: Colors.black.withOpacity(0.1), blurRadius: 20, offset: const Offset(0, 10)),
            ],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                   Container(
                     padding: EdgeInsets.all(10.w),
                     decoration: BoxDecoration(color: const Color(0xFFEEF2FF), borderRadius: BorderRadius.circular(12.r)),
                     child: Icon(icon ?? Icons.edit, color: const Color(0xFF6366F1), size: 24.sp),
                   ),
                   SizedBox(width: 14.w),
                   Text('Edit $title', style: GoogleFonts.poppins(fontSize: 18.sp, fontWeight: FontWeight.bold, color: const Color(0xFF1F2937))),
                ],
              ),
              SizedBox(height: 24.h),
              TextField(
                controller: controller,
                maxLines: maxLines,
                maxLength: maxLength,
                autofocus: true,
                style: GoogleFonts.poppins(fontSize: 15.sp, color: Colors.black87),
                decoration: InputDecoration(
                  hintText: 'Masukkan $title baru...',
                  hintStyle: GoogleFonts.poppins(color: Colors.grey.shade400),
                  contentPadding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 16.h),
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(16.r), borderSide: BorderSide.none),
                  filled: true,
                  fillColor: Colors.grey.shade50,
                  enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(16.r), borderSide: BorderSide(color: Colors.grey.shade200)),
                  focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(16.r), borderSide: const BorderSide(color: Color(0xFF6366F1), width: 1.5)),
                ),
              ),
              SizedBox(height: 24.h),
              Row(
                children: [
                  Expanded(
                    child: TextButton(
                      onPressed: () => Navigator.pop(context, false),
                      style: TextButton.styleFrom(padding: EdgeInsets.symmetric(vertical: 14.h), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14.r))),
                      child: Text('Batal', style: GoogleFonts.poppins(color: Colors.grey.shade600, fontWeight: FontWeight.w600)),
                    ),
                  ),
                  SizedBox(width: 12.w),
                  Expanded(
                    child: ElevatedButton(
                      onPressed: () => Navigator.pop(context, true),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFF6366F1),
                        padding: EdgeInsets.symmetric(vertical: 14.h),
                        elevation: 0,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14.r)),
                      ),
                      child: Text('Simpan', style: GoogleFonts.poppins(color: Colors.white, fontWeight: FontWeight.bold)),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );

    if (result == true && _currentUser != null && mounted) {
      try {
        Map<String, dynamic> updates = {};
        if (field == 'username') updates = _currentUser!.copyWith(username: controller.text).toMap();
        else if (field == 'bio') updates = _currentUser!.copyWith(bio: controller.text).toMap();
        
        await _fs.updateUser(_currentUser!.id!, updates);
        await _loadUserData();
        
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('Profil berhasil diperbarui!'), 
              backgroundColor: Color(0xFF10B981),
              behavior: SnackBarBehavior.floating,
            ),
          );
        }
      } catch (e) {
        if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Error: $e'), backgroundColor: Colors.red));
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    // Theme Colors
    const primaryColor = Color(0xFF6366F1); // Indigo
    const cardColor = Colors.white;
    
    return Scaffold(
      backgroundColor: const Color(0xFFF9FAFB), // Very light gray background
      body: _isLoading
          ? const Center(child: CircularProgressIndicator(color: primaryColor))
          : Stack(
              children: [
                // 1. CURVED HEADER BACKGROUND
                ClipPath(
                  clipper: _HeaderClipper(),
                  child: Container(
                    height: 280.h,
                    decoration: const BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                        colors: [Color(0xFF8B5CF6), Color(0xFF6366F1)], // Violet to Indigo
                      ),
                    ),
                  ),
                ),
                
                // 2. MAIN CONTENT SCROLLABLE
                SingleChildScrollView(
                  physics: const BouncingScrollPhysics(),
                  child: Padding(
                    padding: EdgeInsets.symmetric(horizontal: 24.w),
                    child: Column(
                      children: [
                        SizedBox(height: 60.h), // Top padding for status bar/back button
                        
                        // --- TITLE & BACK BUTTON ---
                        Row(
                          children: [
                            Container(
                              decoration: BoxDecoration(color: Colors.white.withOpacity(0.2), borderRadius: BorderRadius.circular(12.r)),
                              child: IconButton(
                                icon: const Icon(Icons.arrow_back_ios_new_rounded, color: Colors.white, size: 20),
                                onPressed: () => Navigator.pop(context),
                              ),
                            ),
                            SizedBox(width: 16.w),
                            Text(
                              'Profil Saya',
                              style: GoogleFonts.poppins(fontSize: 24.sp, fontWeight: FontWeight.bold, color: Colors.white),
                            ),
                          ],
                        ),

                        SizedBox(height: 32.h),

                        // --- PROFILE PICTURE SECTION ---
                        Center(
                          child: Stack(
                            alignment: Alignment.center,
                            children: [
                              // Avatar Container with White Border & Shadow
                              Container(
                                width: 140.w, height: 140.w,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  border: Border.all(color: Colors.white, width: 6),
                                  boxShadow: [
                                    BoxShadow(color: const Color(0xFF6366F1).withOpacity(0.4), blurRadius: 20, offset: const Offset(0, 10)),
                                  ],
                                  color: Colors.white,
                                ),
                                child: _currentUser?.photoUrl != null
                                    ? ClipOval(child: Image.network(_currentUser!.photoUrl!, fit: BoxFit.cover))
                                    : Center(
                                        child: Text(
                                          _currentUser?.username.substring(0, 1).toUpperCase() ?? 'U',
                                          style: GoogleFonts.poppins(fontSize: 56.sp, fontWeight: FontWeight.bold, color: primaryColor),
                                        ),
                                      ),
                              ),
                              // Edit Badge
                              Positioned(
                                bottom: 4,
                                right: 4,
                                child: GestureDetector(
                                  onTap: _isUploading ? null : _pickAndUploadImage,
                                  child: Container(
                                    padding: EdgeInsets.all(10.w),
                                    decoration: BoxDecoration(
                                      gradient: const LinearGradient(colors: [Color(0xFF2DD4BF), Color(0xFF14B8A6)]), // Teal Gradient
                                      shape: BoxShape.circle,
                                      border: Border.all(color: Colors.white, width: 3),
                                      boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.1), blurRadius: 8)],
                                    ),
                                    child: _isUploading
                                        ? SizedBox(width: 16.w, height: 16.w, child: const CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                                        : Icon(Icons.camera_alt_rounded, color: Colors.white, size: 18.sp),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),

                        SizedBox(height: 16.h),
                        
                        // User Name & Role Text (Below Photo)
                        Text(
                          _currentUser?.username ?? 'User',
                          style: GoogleFonts.poppins(fontSize: 22.sp, fontWeight: FontWeight.bold, color: const Color(0xFF1F2937)),
                          textAlign: TextAlign.center,
                        ),
                        SizedBox(height: 4.h),
                        UserRoleChip(role: _currentUser?.role ?? 'User'),

                        SizedBox(height: 32.h),

                        // --- INFO CARDS SECTION ---
                        FadeTransition(
                          opacity: _fadeAnim,
                          child: SlideTransition(
                            position: _slideAnim,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                _SectionTitle(title: 'Informasi Pribadi'),
                                SizedBox(height: 12.h),
                                _ProfileCard(
                                  title: 'Bio (Status)',
                                  value: _currentUser?.bio ?? 'Belum ada bio...',
                                  icon: Icons.format_quote_rounded,
                                  color: Colors.orange,
                                  onTap: () => _showEditDialog(title: 'Bio', controller: _bioController, field: 'bio', maxLines: 3, maxLength: 150, icon: Icons.format_quote_rounded),
                                ),
                                SizedBox(height: 12.h),
                                _ProfileCard(
                                  title: 'Nama Lengkap',
                                  value: _currentUser?.username ?? '-',
                                  icon: Icons.person_rounded,
                                  color: Colors.blue,
                                  onTap: () => _showEditDialog(title: 'Nama', controller: _nameController, field: 'username', maxLength: 50, icon: Icons.person_rounded),
                                ),

                                SizedBox(height: 32.h),
                                
                                _SectionTitle(title: 'Data Akademik'),
                                SizedBox(height: 12.h),
                                Row(
                                  children: [
                                    Expanded(
                                      child: _StatCard(
                                        title: 'NIS',
                                        value: _memberInfo?['nis'] ?? '-',
                                        icon: Icons.badge_rounded,
                                        color: const Color(0xFFEC4899), // Pink
                                      ),
                                    ),
                                    SizedBox(width: 12.w),
                                    Expanded(
                                      child: _StatCard(
                                        title: 'Kelas',
                                        value: _memberInfo?['kelas'] ?? '-',
                                        icon: Icons.class_rounded,
                                        color: const Color(0xFF8B5CF6), // Purple
                                      ),
                                    ),
                                  ],
                                ),
                                
                                SizedBox(height: 40.h), // Bottom padding
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
    );
  }
}

// ============================================================================
// WIDGET HELPER UI
// ============================================================================

class _HeaderClipper extends CustomClipper<Path> {
  @override
  Path getClip(Size size) {
    Path path = Path();
    path.lineTo(0, size.height - 60);
    // Membuat kurva yang halus di bagian bawah header
    path.quadraticBezierTo(
      size.width / 2, 
      size.height, 
      size.width, 
      size.height - 60
    );
    path.lineTo(size.width, 0);
    path.close();
    return path;
  }

  @override
  bool shouldReclip(CustomClipper<Path> oldClipper) => false;
}

class UserRoleChip extends StatelessWidget {
  final String role;
  const UserRoleChip({super.key, required this.role});

  @override
  Widget build(BuildContext context) {
    bool isAdmin = role == 'admin';
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 12.w, vertical: 4.h),
      decoration: BoxDecoration(
        color: isAdmin ? const Color(0xFFDC2626).withOpacity(0.1) : const Color(0xFF10B981).withOpacity(0.1),
        borderRadius: BorderRadius.circular(20.r),
        border: Border.all(color: isAdmin ? const Color(0xFFDC2626).withOpacity(0.2) : const Color(0xFF10B981).withOpacity(0.2)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(isAdmin ? Icons.admin_panel_settings_rounded : Icons.verified_user_rounded, 
               size: 14.sp, 
               color: isAdmin ? const Color(0xFFDC2626) : const Color(0xFF10B981)),
          SizedBox(width: 6.w),
          Text(
            isAdmin ? 'Administrator' : 'Verified Student',
            style: GoogleFonts.poppins(
              fontSize: 12.sp, 
              fontWeight: FontWeight.w600, 
              color: isAdmin ? const Color(0xFFDC2626) : const Color(0xFF10B981)
            ),
          ),
        ],
      ),
    );
  }
}

class _SectionTitle extends StatelessWidget {
  final String title;
  const _SectionTitle({required this.title});

  @override
  Widget build(BuildContext context) {
    return Text(
      title.toUpperCase(),
      style: GoogleFonts.poppins(
        fontSize: 12.sp,
        fontWeight: FontWeight.w700,
        letterSpacing: 1.2,
        color: Colors.grey.shade500,
      ),
    );
  }
}

class _ProfileCard extends StatelessWidget {
  final String title;
  final String value;
  final IconData icon;
  final Color color;
  final VoidCallback? onTap;

  const _ProfileCard({
    required this.title,
    required this.value,
    required this.icon,
    required this.color,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(20.r),
        child: Container(
          padding: EdgeInsets.all(16.w),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(20.r),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.02),
                blurRadius: 15,
                offset: const Offset(0, 5),
              ),
            ],
            border: Border.all(color: Colors.grey.shade100),
          ),
          child: Row(
            children: [
              Container(
                padding: EdgeInsets.all(12.w),
                decoration: BoxDecoration(
                  color: color.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(16.r),
                ),
                child: Icon(icon, color: color, size: 24.sp),
              ),
              SizedBox(width: 16.w),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(title, style: GoogleFonts.poppins(fontSize: 12.sp, color: Colors.grey.shade500)),
                    SizedBox(height: 2.h),
                    Text(value, style: GoogleFonts.poppins(fontSize: 15.sp, fontWeight: FontWeight.w600, color: const Color(0xFF1F2937))),
                  ],
                ),
              ),
              if (onTap != null)
                Container(
                  padding: EdgeInsets.all(8.w),
                  decoration: BoxDecoration(color: Colors.grey.shade50, borderRadius: BorderRadius.circular(10.r)),
                  child: Icon(Icons.edit_rounded, size: 18.sp, color: Colors.grey.shade400),
                ),
            ],
          ),
        ),
      ),
    );
  }
}

class _StatCard extends StatelessWidget {
  final String title;
  final String value;
  final IconData icon;
  final Color color;

  const _StatCard({
    required this.title,
    required this.value,
    required this.icon,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(16.w),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20.r),
        boxShadow: [
          BoxShadow(
            color: color.withOpacity(0.05),
            blurRadius: 15,
            offset: const Offset(0, 5),
          ),
        ],
        border: Border.all(color: color.withOpacity(0.1), width: 1.5),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: EdgeInsets.all(8.w),
            decoration: BoxDecoration(color: color.withOpacity(0.1), shape: BoxShape.circle),
            child: Icon(icon, color: color, size: 18.sp),
          ),
          SizedBox(height: 12.h),
          Text(value, style: GoogleFonts.poppins(fontSize: 18.sp, fontWeight: FontWeight.bold, color: const Color(0xFF1F2937))),
          Text(title, style: GoogleFonts.poppins(fontSize: 12.sp, color: Colors.grey.shade500)),
        ],
      ),
    );
  }
}
