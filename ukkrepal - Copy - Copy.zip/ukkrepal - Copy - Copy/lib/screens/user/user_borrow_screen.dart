// ============================================================================
// SCREEN - User Borrow (Siswa Pinjam Buku)
// ============================================================================
// Halaman bagi siswa untuk mencari buku dan meminjamnya secara mandiri.
// Mendukung fitur pencarian, pilihan durasi pinjam, dan cetak struk pinjam.

import 'package:flutter/material.dart';
import '../../services/firestore_service.dart';
import '../../services/auth_service.dart';
import '../../services/pdf_service.dart';

class UserBorrowScreen extends StatefulWidget {
  // Flag jika halaman ini hanya digunakan untuk mode pencarian saja (tanpa tombol pinjam)
  final bool showSearchOnly;

  const UserBorrowScreen({super.key, this.showSearchOnly = false});

  @override
  State<UserBorrowScreen> createState() => _UserBorrowScreenState();
}

class _UserBorrowScreenState extends State<UserBorrowScreen> {
  final _fs = FirestoreService.instance;
  
  // Koleksi buku
  List<FirestoreBook> _books = [];
  List<FirestoreBook> _filteredBooks = [];
  
  final _searchController = TextEditingController();
  bool _isLoading = false;

  @override
  void initState() {
    super.initState();
    _loadBooks();
    _searchController.addListener(_filterBooks);
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  // Mengunduh daftar seluruh koleksi buku dari Firestore
  Future<void> _loadBooks() async {
    setState(() => _isLoading = true);
    try {
      final fbBooks = await _fs.getAllBooks();
      setState(() {
        _books = fbBooks;
        _filteredBooks = fbBooks;
        _isLoading = false;
      });
    } catch (e) {
      setState(() => _isLoading = false);
    }
  }

  // Logika pencarian buku berdasarkan judul, pengarang, atau kategori
  void _filterBooks() {
    final query = _searchController.text.toLowerCase();
    setState(() {
      if (_books.isEmpty) {
        _filteredBooks = [];
      } else if (query.isEmpty) {
        _filteredBooks = _books;
      } else {
        _filteredBooks = _books.where((fb) {
          final book = fb.book;
          return book.judul.toLowerCase().contains(query) ||
              book.pengarang.toLowerCase().contains(query) ||
              (book.kategori ?? '').toLowerCase().contains(query);
        }).toList();
      }
    });
  }

  // --------------------------------------------------------------------------
  // DURATION DIALOG - Memilih jangka waktu peminjaman
  // --------------------------------------------------------------------------
  Future<int?> _showDurationDialog() async {
    return showDialog<int>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Pilih Durasi Pinjam'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text('Berapa lama Anda ingin meminjam buku ini?'),
            const SizedBox(height: 16),
            RadioListTile<int>(
              title: const Text('3 Hari'),
              subtitle: const Text('Cocok untuk bacaan singkat'),
              value: 3,
              groupValue: 7, // Default value (visual)
              onChanged: (value) => Navigator.pop(context, 3),
            ),
            RadioListTile<int>(
              title: const Text('7 Hari (Standar)'),
              subtitle: const Text('Waktu peminjaman umum'),
              value: 7,
              groupValue: 7,
              onChanged: (value) => Navigator.pop(context, 7),
            ),
            RadioListTile<int>(
              title: const Text('30 Hari (1 Bulan)'),
              subtitle: const Text('Untuk buku tebal/referensi'),
              value: 30,
              groupValue: 7,
              onChanged: (value) => Navigator.pop(context, 30),
            ),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Batal')),
        ],
      ),
    );
  }

  // --------------------------------------------------------------------------
  // BORROW ACTION - Eksekusi peminjaman ke database
  // --------------------------------------------------------------------------
  Future<void> _borrowBook(FirestoreBook fb) async {
    final book = fb.book;
    
    // 1. Cek ketersediaan stok
    if (book.stok <= 0) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Maaf, stok buku ini habis.')));
      return;
    }

    // 2. Cek session user
    final user = await AuthService.instance.getCurrentUser();
    if (user == null || user.memberId == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Gagal mengenali profil Anda.')));
      return;
    }

    // 3. Tampilkan dialog pilihan durasi
    final selectedDuration = await _showDurationDialog();
    if (selectedDuration == null) return;

    // Tampilkan loading spinner
    showDialog(context: context, barrierDismissible: false, builder: (_) => const Center(child: CircularProgressIndicator()));

    try {
      // 4. Validasi apakah user sudah meminjam buku yang sama sebelumnya
      final transactions = await _fs.getTransactionsByMember(user.memberId!);
      final isAlreadyBorrowed = transactions.any((t) => t['book_id'] == fb.docId && t['status'] == 'dipinjam');

      if (isAlreadyBorrowed) {
        Navigator.pop(context); // Tutup loading
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Anda masih meminjam buku ini.')));
        return;
      }

      final now = DateTime.now();
      final dueDate = now.add(Duration(days: selectedDuration));

      // 5. Simpan transaksi ke Firestore (Atomic transaction dlm service)
      await _fs.borrowBook(
        memberDocId: user.memberId!,
        bookDocId: fb.docId,
        tanggalPinjam: now,
        tanggalJatuhTempo: dueDate,
        durationDays: selectedDuration,
      );

      if (mounted) {
        Navigator.pop(context); // Tutup loading
        
        // 6. Tampilkan notifikasi dan dialog cetak bukti
        _showBorrowReceiptDialog(
          bookTitle: book.judul,
          bookAuthor: book.pengarang,
          memberName: user.username,
          borrowDate: now,
          dueDate: dueDate,
        );
        
        _loadBooks(); // Segarkan daftar stok
      }
    } catch (e) {
      if (mounted) {
        Navigator.pop(context);
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Error: $e')));
      }
    }
  }

  // DIALOG - Sukses Pinjam & Opsi Cetak PDF
  void _showBorrowReceiptDialog({
    required String bookTitle,
    required String bookAuthor,
    required String memberName,
    required DateTime borrowDate,
    required DateTime dueDate,
  }) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Transaksi Berhasil!'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.check_circle, color: Colors.green, size: 64),
            const SizedBox(height: 16),
            Text('Buku "$bookTitle" telah dipinjam.'),
            const SizedBox(height: 8),
            Text('Wajib dikembalikan sebelum:', style: TextStyle(color: Colors.grey.shade600)),
            Text('${dueDate.day}/${dueDate.month}/${dueDate.year}', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Tutup')),
          ElevatedButton.icon(
            onPressed: () {
              Navigator.pop(context);
              // Panggil PdfService untuk membuat bukti pinjam PDF
              PdfService.generateBorrowReceipt(
                context,
                bookTitle: bookTitle,
                bookAuthor: bookAuthor,
                memberName: memberName,
                memberNis: '-', // NIS akan diambil otomatis dlm service (opsional)
                memberClass: '-',
                borrowDate: borrowDate,
                dueDate: dueDate,
              );
            },
            icon: const Icon(Icons.print),
            label: const Text('Cetak Bukti'),
            style: ElevatedButton.styleFrom(backgroundColor: Colors.blue, foregroundColor: Colors.white),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.showSearchOnly ? 'Cari Buku' : 'Pinjam Buku'),
        backgroundColor: Colors.blue,
        foregroundColor: Colors.white,
        elevation: 0,
      ),
      body: Column(
        children: [
          // --- KOTAK PENCARIAN ---
          Container(
            padding: const EdgeInsets.all(16),
            color: Colors.blue.withOpacity(0.05),
            child: TextField(
              controller: _searchController,
              decoration: InputDecoration(
                hintText: 'Ketik judul, pengarang, atau kategori...',
                prefixIcon: const Icon(Icons.search),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                filled: true,
                fillColor: Colors.white,
              ),
            ),
          ),

          // --- DAFTAR HASIL PENCARIAN ---
          Expanded(
            child: _isLoading
                ? const Center(child: CircularProgressIndicator())
                : _filteredBooks.isEmpty
                ? Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.search_off_rounded, size: 64, color: Colors.grey.shade400),
                        const SizedBox(height: 16),
                        Text(_searchController.text.isEmpty ? 'Belum ada koleksi buku' : 'Buku tidak ditemukan', style: TextStyle(color: Colors.grey.shade600)),
                      ],
                    ),
                  )
                : ListView.builder(
                    padding: const EdgeInsets.all(16),
                    itemCount: _filteredBooks.length,
                    itemBuilder: (context, index) {
                      final fb = _filteredBooks[index];
                      final book = fb.book;
                      final isAvailable = book.stok > 0;

                      return Card(
                        margin: const EdgeInsets.only(bottom: 12),
                        elevation: 2,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                        child: ListTile(
                          contentPadding: const EdgeInsets.all(16),
                          leading: CircleAvatar(
                            backgroundColor: isAvailable ? Colors.green.shade50 : Colors.red.shade50,
                            radius: 30,
                            child: Icon(Icons.book, color: isAvailable ? Colors.green : Colors.red),
                          ),
                          title: Text(book.judul, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                          subtitle: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const SizedBox(height: 4),
                              Text('Pengarang: ${book.pengarang}'),
                              Text('Penerbit: ${book.penerbit}, ${book.tahunTerbit}'),
                              Text(
                                isAvailable ? 'Tersedia: ${book.stok} Eks.' : 'Stok Habis',
                                style: TextStyle(color: isAvailable ? Colors.green : Colors.red, fontWeight: FontWeight.bold),
                              ),
                            ],
                          ),
                          // Tombol Pinjam (Hanya jika stok ada dan bukan mode search only)
                          trailing: isAvailable && !widget.showSearchOnly
                              ? ElevatedButton(
                                  onPressed: () => _borrowBook(fb),
                                  style: ElevatedButton.styleFrom(backgroundColor: Colors.blue, foregroundColor: Colors.white),
                                  child: const Text('Pinjam'),
                                )
                              : (!isAvailable ? const Text('HABIS', style: TextStyle(color: Colors.red, fontWeight: FontWeight.bold)) : null),
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }
}

