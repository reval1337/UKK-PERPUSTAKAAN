// ============================================================================
// SCREEN - Admin Transactions (Kelola Riwayat Transaksi)
// ============================================================================
// Halaman untuk memantau aktivitas peminjaman dan pengembalian buku.
// Dilengkapi dengan statistik ringkas, filter status, dan proses pengembalian.

import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../../services/firestore_service.dart';

class AdminTransactionsScreen extends StatefulWidget {
  const AdminTransactionsScreen({super.key});

  @override
  State<AdminTransactionsScreen> createState() => _AdminTransactionsScreenState();
}

class _AdminTransactionsScreenState extends State<AdminTransactionsScreen> {
  final _fs = FirestoreService.instance;
  
  // Koleksi data transaksi
  List<Map<String, dynamic>> _transactions = [];           // Data asli dari database
  List<Map<String, dynamic>> _filteredTransactions = [];     // Data yang ditampilkan setelah difilter
  
  // State UI
  bool _isLoading = true;
  String _selectedFilter = 'all';                          // Status filter aktif
  final TextEditingController _searchController = TextEditingController();

  // --------------------------------------------------------------------------
  // GETTERS - Perhitungan statistik secara instan
  // --------------------------------------------------------------------------
  int get _totalDipinjam => _transactions.where((t) => t['status'] == 'dipinjam').length;
  int get _totalDikembalikan => _transactions.where((t) => t['status'] == 'dikembalikan').length;
  int get _totalTerlambat => _transactions.where((t) => t['status'] == 'terlambat').length;
  int get _totalDenda => _transactions.fold(0, (sum, t) => sum + ((t['denda'] as int?) ?? 0));

  @override
  void initState() {
    super.initState();
    _loadTransactions();
    _searchController.addListener(_filterTransactions);
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  // memuat data dari Firestore Service
  Future<void> _loadTransactions() async {
    setState(() => _isLoading = true);
    try {
      final transactions = await _fs.getTransactionsWithDetails();
      setState(() {
        _transactions = transactions;
        _applyFilter();
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _transactions = [];
        _filteredTransactions = [];
        _isLoading = false;
      });
    }
  }

  // Menerapkan filter status (Dipinjam/Kembali/Terlambat)
  void _applyFilter() {
    setState(() {
      if (_selectedFilter == 'all') {
        _filteredTransactions = _transactions;
      } else {
        _filteredTransactions = _transactions.where((t) => t['status'] == _selectedFilter).toList();
      }
    });
  }

  // Mengubah kategori filter aktif
  void _setFilter(String filter) {
    setState(() {
      _selectedFilter = filter;
      _applyFilter();
    });
  }

  // Mencari transaksi berdasarkan nama anggota atau judul buku
  void _filterTransactions() {
    final query = _searchController.text.toLowerCase();
    setState(() {
      if (query.isEmpty) {
        _applyFilter();
      } else {
        _filteredTransactions = _transactions.where((t) {
          final memberNama = (t['member_nama']?.toString() ?? '').toLowerCase();
          final memberNis = (t['member_nis']?.toString() ?? '').toLowerCase();
          final bookJudul = (t['book_judul']?.toString() ?? '').toLowerCase();
          final bookPengarang = (t['book_pengarang']?.toString() ?? '').toLowerCase();
          return memberNama.contains(query) ||
              memberNis.contains(query) ||
              bookJudul.contains(query) ||
              bookPengarang.contains(query);
        }).toList();
      }
    });
  }

  // --------------------------------------------------------------------------
  // RETURN BOOK - Proses pengembalian buku terpilih
  // --------------------------------------------------------------------------
  Future<void> _returnBook(Map<String, dynamic> transaction) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Kembalikan Buku'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Buku: ${transaction['book_judul'] ?? 'Unknown'}'),
            const SizedBox(height: 8),
            Text('Peminjam: ${transaction['member_nama'] ?? 'Unknown'}'),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Batal'),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(context, true),
            style: ElevatedButton.styleFrom(backgroundColor: Colors.green),
            child: const Text('Konfirmasi Kembali', style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );

    if (confirm == true) {
      try {
        // Update status di database dan tambah stok buku
        await _fs.returnBook(
          transactionDocId: transaction['docId'],
          tanggalKembali: DateTime.now(),
        );
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Buku berhasil dikembalikan!')),
          );
          _loadTransactions(); // Muat ulang data
        }
      } catch (e) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('Error: $e')),
          );
        }
      }
    }
  }

  // Warna indikator status
  Color _getStatusColor(String status) {
    switch (status) {
      case 'dipinjam': return Colors.orange;
      case 'dikembalikan': return Colors.green;
      case 'terlambat': return Colors.red;
      default: return Colors.grey;
    }
  }

  String _formatCurrency(int amount) {
    return NumberFormat.currency(locale: 'id_ID', symbol: 'Rp ', decimalDigits: 0).format(amount);
  }

  String _getDurationText(int days) {
    if (days == 3) return '3 Hari (Singkat)';
    if (days == 7) return '7 Hari (Standar)';
    if (days == 30) return '1 Bulan (Panjang)';
    return '$days Hari';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Kelola Transaksi'),
        backgroundColor: Colors.orange,
        foregroundColor: Colors.white,
        elevation: 0,
        actions: [
          IconButton(icon: const Icon(Icons.refresh), onPressed: _loadTransactions),
        ],
      ),
      body: Column(
        children: [
          // --- RINGKASAN STATISTIK ---
          Container(
            padding: const EdgeInsets.all(16),
            color: Colors.orange.shade50,
            child: Column(
              children: [
                Row(
                  children: [
                    Expanded(child: _buildStatCard('Dipinjam', _totalDipinjam.toString(), Colors.orange, Icons.book)),
                    const SizedBox(width: 12),
                    Expanded(child: _buildStatCard('Kembali', _totalDikembalikan.toString(), Colors.green, Icons.check_circle)),
                    const SizedBox(width: 12),
                    Expanded(child: _buildStatCard('Terlambat', _totalTerlambat.toString(), Colors.red, Icons.warning)),
                  ],
                ),
                const SizedBox(height: 12),
                SizedBox(
                  width: double.infinity,
                  child: _buildStatCard('Total Denda Terkumpul', _formatCurrency(_totalDenda), Colors.purple, Icons.money, isLarge: true),
                ),
              ],
            ),
          ),
          
          // --- FILTER CHIPS ---
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            color: Colors.white,
            child: SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: [
                  _buildFilterChip('Semua', 'all', _selectedFilter == 'all', Colors.blue),
                  const SizedBox(width: 8),
                  _buildFilterChip('Sedang Dipinjam', 'dipinjam', _selectedFilter == 'dipinjam', Colors.orange),
                  const SizedBox(width: 8),
                  _buildFilterChip('Sudah Kembali', 'dikembalikan', _selectedFilter == 'dikembalikan', Colors.green),
                  const SizedBox(width: 8),
                  _buildFilterChip('Terlambat', 'terlambat', _selectedFilter == 'terlambat', Colors.red),
                ],
              ),
            ),
          ),
          
          // --- BAR PENCARIAN ---
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: TextField(
              controller: _searchController,
              decoration: InputDecoration(
                hintText: 'Cari Nama Anggota atau Judul Buku...',
                prefixIcon: const Icon(Icons.search),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                filled: true,
                fillColor: Colors.grey.shade50,
              ),
            ),
          ),
          
          // --- DAFTAR TRANSAKSI ---
          Expanded(
            child: _isLoading
                ? const Center(child: CircularProgressIndicator())
                : _filteredTransactions.isEmpty
                    ? Center(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(Icons.swap_horiz_outlined, size: 64, color: Colors.grey.shade400),
                            const SizedBox(height: 16),
                            Text(
                              _searchController.text.isEmpty && _selectedFilter == 'all'
                                  ? 'Belum ada transaksi'
                                  : 'Data tidak ditemukan',
                              style: TextStyle(color: Colors.grey.shade600),
                            ),
                          ],
                        ),
                      )
                    : ListView.builder(
                        padding: const EdgeInsets.all(16),
                        itemCount: _filteredTransactions.length,
                        itemBuilder: (context, index) {
                          final t = _filteredTransactions[index];
                          final status = t['status'] as String? ?? 'unknown';
                          final tanggalPinjam = t['tanggal_pinjam'] != null ? DateTime.tryParse(t['tanggal_pinjam'] as String) : null;
                          final tanggalKembali = t['tanggal_kembali'] != null ? DateTime.tryParse(t['tanggal_kembali'] as String) : null;
                          final tanggalJatuhTempo = t['tanggal_jatuh_tempo'] != null ? DateTime.tryParse(t['tanggal_jatuh_tempo'] as String) : null;
                          final denda = (t['denda'] is int) ? t['denda'] as int : int.tryParse('${t['denda']}') ?? 0;
                          
                          return Card(
                            margin: const EdgeInsets.only(bottom: 16),
                            elevation: 2,
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                // HEADER KARTU (Judul Buku & Status)
                                Container(
                                  padding: const EdgeInsets.all(16),
                                  decoration: BoxDecoration(
                                    color: _getStatusColor(status).withOpacity(0.1),
                                    borderRadius: const BorderRadius.vertical(top: Radius.circular(12)),
                                  ),
                                  child: Row(
                                    children: [
                                      const Icon(Icons.book, color: Colors.blue),
                                      const SizedBox(width: 12),
                                      Expanded(
                                        child: Text(
                                          t['book_judul'] ?? 'Unknown Book',
                                          style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                                        ),
                                      ),
                                      Container(
                                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                                        decoration: BoxDecoration(
                                          color: _getStatusColor(status),
                                          borderRadius: BorderRadius.circular(12),
                                        ),
                                        child: Text(
                                          status.toUpperCase(),
                                          style: const TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.bold),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                // ISI KARTU (Detail Peminjam & Tanggal)
                                Padding(
                                  padding: const EdgeInsets.all(16),
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      // Nama Peminjam
                                      Row(
                                        children: [
                                          const Icon(Icons.person, size: 16, color: Colors.black54),
                                          const SizedBox(width: 8),
                                          Text(
                                            t['member_nama'] ?? 'Unknown Member',
                                            style: const TextStyle(fontWeight: FontWeight.w600),
                                          ),
                                        ],
                                      ),
                                      const SizedBox(height: 12),
                                      // Info Tanggal
                                      Row(
                                        children: [
                                          const Icon(Icons.calendar_month, size: 16, color: Colors.black54),
                                          const SizedBox(width: 8),
                                          if (tanggalPinjam != null)
                                            Text('Pinjam: ${DateFormat('dd/MM/yyyy').format(tanggalPinjam)}'),
                                          const Spacer(),
                                          if (tanggalJatuhTempo != null)
                                            Text(
                                              'Jatuh Tempo: ${DateFormat('dd/MM/yyyy').format(tanggalJatuhTempo)}',
                                              style: TextStyle(
                                                color: status == 'dipinjam' && DateTime.now().isAfter(tanggalJatuhTempo)
                                                    ? Colors.red : Colors.black54,
                                                fontWeight: FontWeight.w500,
                                              ),
                                            ),
                                        ],
                                      ),
                                      
                                      // TANDA TERLAMBAT / SISA HARI
                                      if (status == 'dipinjam' && tanggalJatuhTempo != null) ...[
                                        const SizedBox(height: 12),
                                        _buildLateInfo(tanggalJatuhTempo, denda),
                                      ],

                                      // INFO PENGEMBALIAN & DENDA
                                      if (tanggalKembali != null) ...[
                                        const SizedBox(height: 12),
                                        Row(
                                          children: [
                                            const Icon(Icons.check_circle_rounded, size: 16, color: Colors.green),
                                            const SizedBox(width: 8),
                                            Text(
                                              'Dikembalikan: ${DateFormat('dd/MM/yyyy').format(tanggalKembali)}',
                                              style: const TextStyle(color: Colors.green, fontWeight: FontWeight.w500),
                                            ),
                                          ],
                                        ),
                                      ],

                                      if (denda > 0) ...[
                                        const SizedBox(height: 12),
                                        Container(
                                          padding: const EdgeInsets.all(8),
                                          decoration: BoxDecoration(
                                            color: Colors.red.shade50,
                                            borderRadius: BorderRadius.circular(8),
                                            border: Border.all(color: Colors.red.shade100),
                                          ),
                                          child: Row(
                                            mainAxisSize: MainAxisSize.min,
                                            children: [
                                              const Icon(Icons.payments_rounded, size: 16, color: Colors.red),
                                              const SizedBox(width: 8),
                                              Text(
                                                'Denda: ${_formatCurrency(denda)}',
                                                style: const TextStyle(color: Colors.red, fontWeight: FontWeight.bold),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                      
                                      // TOMBOL AKSI KEMBALI
                                      if (status == 'dipinjam') ...[
                                        const SizedBox(height: 16),
                                        SizedBox(
                                          width: double.infinity,
                                          child: ElevatedButton.icon(
                                            onPressed: () => _returnBook(t),
                                            icon: const Icon(Icons.keyboard_return_rounded),
                                            label: const Text('TERIMA PENGEMBALIAN'),
                                            style: ElevatedButton.styleFrom(
                                              backgroundColor: Colors.green,
                                              foregroundColor: Colors.white,
                                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          );
                        },
                      ),
          ),
        ],
      ),
    );
  }

  // Widget untuk menampilkan status keterlambatan atau sisa waktu
  Widget _buildLateInfo(DateTime jatuhTempo, int denda) {
    final now = DateTime.now();
    final isLate = now.isAfter(jatuhTempo);
    
    if (isLate) {
      final daysLate = now.difference(jatuhTempo).inDays + 1;
      return Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        decoration: BoxDecoration(
          color: Colors.red.shade50,
          borderRadius: BorderRadius.circular(8),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.warning_amber_rounded, size: 16, color: Colors.red),
            const SizedBox(width: 8),
            Text(
              'Terlambat $daysLate Hari',
              style: const TextStyle(color: Colors.red, fontWeight: FontWeight.bold, fontSize: 12),
            ),
          ],
        ),
      );
    } else {
      final daysRemaining = jatuhTempo.difference(now).inDays;
      return Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        decoration: BoxDecoration(
          color: Colors.blue.shade50,
          borderRadius: BorderRadius.circular(8),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.timer_outlined, size: 16, color: Colors.blue),
            const SizedBox(width: 8),
            Text(
              'Sisa $daysRemaining Hari Peminjaman',
              style: const TextStyle(color: Colors.blue, fontWeight: FontWeight.bold, fontSize: 12),
            ),
          ],
        ),
      );
    }
  }

  // Widget kartu statistik di bagian atas
  Widget _buildStatCard(String title, String value, Color color, IconData icon, {bool isLarge = false}) {
    return Container(
      padding: EdgeInsets.all(isLarge ? 16 : 12),
      decoration: BoxDecoration(
        color: color,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(color: color.withOpacity(0.3), blurRadius: 8, offset: const Offset(0, 4)),
        ],
      ),
      child: Column(
        children: [
          Icon(icon, color: Colors.white, size: isLarge ? 32 : 24),
          const SizedBox(height: 8),
          Text(
            value,
            style: TextStyle(
              fontSize: isLarge ? 20 : 18,
              fontWeight: FontWeight.bold,
              color: Colors.white,
            ),
          ),
          Text(
            title,
            style: TextStyle(
              fontSize: 10,
              color: Colors.white.withOpacity(0.9),
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  // Widget tombol filter status
  Widget _buildFilterChip(String label, String value, bool isSelected, Color color) {
    return FilterChip(
      label: Text(label),
      selected: isSelected,
      onSelected: (_) => _setFilter(value),
      selectedColor: color.withOpacity(0.2),
      checkmarkColor: color,
      backgroundColor: Colors.white,
      side: BorderSide(color: isSelected ? color : Colors.grey.shade300),
      labelStyle: TextStyle(
        color: isSelected ? color : Colors.grey.shade700,
        fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
        fontSize: 12,
      ),
    );
  }
}

