import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../../services/firestore_service.dart';
import '../../database/database_helper.dart';
import '../../services/auth_service.dart';
import '../../models/member.dart';

class AdminMemberFormScreen extends StatefulWidget {
  final Member? member;

  const AdminMemberFormScreen({super.key, this.member});

  @override
  State<AdminMemberFormScreen> createState() => _AdminMemberFormScreenState();
}

class _AdminMemberFormScreenState extends State<AdminMemberFormScreen> {
  final _formKey = GlobalKey<FormState>();
  final _dbHelper = FirestoreService.instance;

  final _namaController = TextEditingController();
  final _nisController = TextEditingController();
  final _kelasController = TextEditingController();
  final _alamatController = TextEditingController();
  final _noTelpController = TextEditingController();
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();
  DateTime _tanggalDaftar = DateTime.now();

  @override
  void initState() {
    super.initState();
    if (widget.member != null) {
      _namaController.text = widget.member!.nama;
      _nisController.text = widget.member!.nis;
      _kelasController.text = widget.member!.kelas;
      _alamatController.text = widget.member!.alamat;
      _noTelpController.text = widget.member!.noTelp;
      // existing member: email/password not editable here
      _tanggalDaftar = widget.member!.tanggalDaftar;
    }
  }

  @override
  void dispose() {
    _namaController.dispose();
    _nisController.dispose();
    _kelasController.dispose();
    _alamatController.dispose();
    _noTelpController.dispose();
    _emailController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  Future<void> _selectDate() async {
    final picked = await showDatePicker(
      context: context,
      initialDate: _tanggalDaftar,
      firstDate: DateTime(2000),
      lastDate: DateTime.now(),
    );
    if (picked != null) {
      setState(() => _tanggalDaftar = picked);
    }
  }

  Future<void> _saveMember() async {
    if (_formKey.currentState!.validate()) {
      final member = Member(
        id: widget.member?.id,
        nama: _namaController.text.trim(),
        nis: _nisController.text.trim(),
        kelas: _kelasController.text.trim(),
        alamat: _alamatController.text.trim(),
        noTelp: _noTelpController.text.trim(),
        tanggalDaftar: _tanggalDaftar,
      );
      if (widget.member == null) {
        // insert member into Firestore then register Firebase user
        final docId = await _dbHelper.addMember(member);
        bool registered = false;
        final email = _emailController.text.trim();
        final password = _passwordController.text;
        if (email.isNotEmpty && password.isNotEmpty) {
          registered = await AuthService.instance.registerUser(
            email: email,
            password: password,
            role: 'user',
            memberId: docId,
          );
        }

        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text(
                registered
                    ? 'Anggota dan akun berhasil dibuat'
                    : 'Anggota berhasil ditambahkan',
              ),
            ),
          );
        }
      } else {
        // Editing existing local member not yet migrated; fallback to local DB update
        await DatabaseHelper.instance.updateMember(member);
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Anggota berhasil diupdate')),
          );
        }
      }

      if (mounted) {
        Navigator.pop(context);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.member == null ? 'Tambah Anggota' : 'Edit Anggota'),
        backgroundColor: Colors.green,
        foregroundColor: Colors.white,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              TextFormField(
                controller: _namaController,
                decoration: InputDecoration(
                  labelText: 'Nama Lengkap *',
                  prefixIcon: const Icon(Icons.person),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                  filled: true,
                  fillColor: Colors.grey.shade50,
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Nama tidak boleh kosong';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _nisController,
                decoration: InputDecoration(
                  labelText: 'NIS *',
                  prefixIcon: const Icon(Icons.badge),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                  filled: true,
                  fillColor: Colors.grey.shade50,
                  counterText: "", // BARU: Sembunyikan angka penghitung karakter di bawah kolom
                ),
                keyboardType: TextInputType.number, // BARU: Munculkan keyboard angka
                maxLength: 4, // BARU: Batasi input maksimal 4 digit
                inputFormatters: [
                  FilteringTextInputFormatter.digitsOnly, // BARU: Hanya terima input angka (huruf otomatis diblok)
                ],
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'NIS tidak boleh kosong';
                  }
                  if (value.length > 4) {
                    return 'NIS maksimal 4 angka'; // BARU: Pesan error jika lebih dari 4 angka
                  }
                  return null;
                },
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _kelasController,
                decoration: InputDecoration(
                  labelText: 'Kelas *',
                  prefixIcon: const Icon(Icons.class_),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                  filled: true,
                  fillColor: Colors.grey.shade50,
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Kelas tidak boleh kosong';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _alamatController,
                decoration: InputDecoration(
                  labelText: 'Alamat *',
                  prefixIcon: const Icon(Icons.home),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                  filled: true,
                  fillColor: Colors.grey.shade50,
                ),
                maxLines: 2,
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Alamat tidak boleh kosong';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _noTelpController,
                decoration: InputDecoration(
                  labelText: 'No. Telepon *',
                  prefixIcon: const Icon(Icons.phone),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                  filled: true,
                  fillColor: Colors.grey.shade50,
                ),
                keyboardType: TextInputType.phone,
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'No. Telepon tidak boleh kosong';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _emailController,
                decoration: InputDecoration(
                  labelText: 'Email (untuk akun siswa)',
                  prefixIcon: const Icon(Icons.email),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                  filled: true,
                  fillColor: Colors.grey.shade50,
                ),
                keyboardType: TextInputType.emailAddress,
                validator: (value) {
                  if (widget.member == null) {
                    if (value == null || value.isEmpty) {
                      return 'Email tidak boleh kosong';
                    }
                    if (!value.contains('@')) return 'Email tidak valid';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _passwordController,
                decoration: InputDecoration(
                  labelText: 'Password (untuk akun siswa)',
                  prefixIcon: const Icon(Icons.lock),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                  filled: true,
                  fillColor: Colors.grey.shade50,
                ),
                obscureText: true,
                validator: (value) {
                  if (widget.member == null) {
                    if (value == null || value.isEmpty) {
                      return 'Password tidak boleh kosong';
                    }
                    if (value.length < 6) return 'Password minimal 6 karakter';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 16),
              InkWell(
                onTap: _selectDate,
                child: InputDecorator(
                  decoration: InputDecoration(
                    labelText: 'Tanggal Daftar *',
                    prefixIcon: const Icon(Icons.calendar_today),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    filled: true,
                    fillColor: Colors.grey.shade50,
                  ),
                  child: Text(
                    '${_tanggalDaftar.day}/${_tanggalDaftar.month}/${_tanggalDaftar.year}',
                    style: const TextStyle(fontSize: 16),
                  ),
                ),
              ),
              const SizedBox(height: 24),
              SizedBox(
                height: 50,
                child: ElevatedButton(
                  onPressed: _saveMember,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.green,
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                  child: const Text(
                    'SIMPAN',
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
