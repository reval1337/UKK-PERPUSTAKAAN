// ============================================================================
// SCREEN - Admin Members (Kelola Data Anggota)
// ============================================================================
// Halaman untuk menampilkan daftar seluruh Siswa/Anggota perpustakaan.
// Memungkinkan petugas untuk menambah, mengedit, atau menghapus anggota.

import 'package:flutter/material.dart';
import '../../services/firestore_service.dart';
import 'admin_member_form_screen.dart';

class AdminMembersScreen extends StatefulWidget {
  const AdminMembersScreen({super.key});

  @override
  State<AdminMembersScreen> createState() => _AdminMembersScreenState();
}

class _AdminMembersScreenState extends State<AdminMembersScreen> {
  // Controller untuk kolom pencarian
  final TextEditingController _searchController = TextEditingController();

  @override
  void initState() {
    super.initState();
    // Listener untuk mendeteksi perubahan ketikan user
    _searchController.addListener(_filterMembers);
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  // Fungsi sederhana untuk memicu render ulang saat teks cari berubah
  void _filterMembers() => setState(() {});

  // --------------------------------------------------------------------------
  // DELETE MEMBER - Menghapus data anggota dari database
  // --------------------------------------------------------------------------
  Future<void> _deleteMember(String docId, String name) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Hapus Anggota'),
        content: Text('Apakah Anda yakin ingin menghapus anggota "$name"?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false), // Batal
            child: const Text('Batal'),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(context, true), // Ya, hapus
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
            child: const Text('Hapus', style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );

    if (confirm == true) {
      // Panggil service untuk hapus dokumen di Firestore
      await FirestoreService.instance.deleteMember(docId);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Anggota berhasil dihapus')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Kelola Anggota'),
        backgroundColor: Colors.green, // Warna hijau identik dengan Member/User
        foregroundColor: Colors.white,
        elevation: 0,
      ),
      body: Column(
        children: [
          // --- KOTAK PENCARIAN ---
          Container(
            padding: const EdgeInsets.all(16),
            color: Colors.green.withOpacity(0.05),
            child: TextField(
              controller: _searchController,
              decoration: InputDecoration(
                hintText: 'Cari Nama, NIS, atau Kelas...',
                prefixIcon: const Icon(Icons.search),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                filled: true,
                fillColor: Colors.white,
              ),
            ),
          ),

          // --- DAFTAR ANGGOTA (Aliran Data Langsung) ---
          Expanded(
            child: StreamBuilder<List<Map<String, dynamic>>>(
              stream: FirestoreService.instance.streamMembers(),
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Center(child: CircularProgressIndicator());
                }
                
                final items = snapshot.data ?? [];
                final query = _searchController.text.toLowerCase();
                
                // Filter data berdasarkan input user
                final filtered = query.isEmpty
                    ? items
                    : items.where((m) {
                        final nama = (m['nama'] ?? '').toString().toLowerCase();
                        final nis = (m['nis'] ?? '').toString().toLowerCase(); // PERBAIKAN: Ganti .toInteger() ke .toString() agar tidak error
                        final kelas = (m['kelas'] ?? '').toString().toLowerCase();
                        return nama.contains(query) || nis.contains(query) || kelas.contains(query);
                      }).toList();

                if (filtered.isEmpty) {
                  return Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.people_outline, size: 64, color: Colors.grey.shade400),
                        const SizedBox(height: 16),
                        Text(
                          query.isEmpty ? 'Belum ada anggota' : 'Anggota tidak ditemukan',
                          style: TextStyle(color: Colors.grey.shade600),
                        ),
                      ],
                    ),
                  );
                }

                // Tampilkan dalam bentuk List Card
                return ListView.builder(
                  padding: const EdgeInsets.all(16),
                  itemCount: filtered.length,
                  itemBuilder: (context, index) {
                    final m = filtered[index];
                    return Card(
                      margin: const EdgeInsets.only(bottom: 12),
                      elevation: 2,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: ListTile(
                        contentPadding: const EdgeInsets.all(16),
                        leading: CircleAvatar(
                          backgroundColor: Colors.green.shade100,
                          radius: 30,
                          child: const Icon(Icons.person, color: Colors.green),
                        ),
                        title: Text(
                          m['nama']?.toString() ?? '-',
                          style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                        ),
                        subtitle: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const SizedBox(height: 4),
                            Text('NIS: ${m['nis'] ?? '-'} | Kelas: ${m['kelas'] ?? '-'}'),
                            Text('Telepon: ${m['no_telp'] ?? '-'}'),
                            Text('Alamat: ${m['alamat'] ?? '-'}', maxLines: 1, overflow: TextOverflow.ellipsis),
                          ],
                        ),
                        // Tombol Edit dan Hapus
                        trailing: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            IconButton(
                              icon: const Icon(Icons.edit, color: Colors.blue),
                              onPressed: () async {
                                // Navigator ke form edit (jika data model sudah lengkap)
                                // Catatan: Masih menggunakan form penambahan untuk demo
                                await Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (_) => const AdminMemberFormScreen(),
                                  ),
                                );
                              },
                            ),
                            IconButton(
                              icon: const Icon(Icons.delete, color: Colors.red),
                                onPressed: () => _deleteMember(
                                  m['docId']?.toString() ?? '',
                                  m['nama']?.toString() ?? '',
                                ),
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
      // --- TOMBOL TAMBAH ANGGOTA ---
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () async {
          await Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => const AdminMemberFormScreen()),
          );
        },
        backgroundColor: Colors.green,
        icon: const Icon(Icons.person_add_alt_1_rounded),
        label: const Text('Tambah Anggota'),
      ),
    );
  }
}

