// ============================================================================
// SCREEN - Admin Books (Kelola Koleksi Buku)
// ============================================================================
// Halaman untuk menampilkan daftar seluruh buku yang tersedia di perpustakaan.
// Mendukung fitur pencarian real-time dan operasi Hapus/Edit.

import 'package:flutter/material.dart';
import '../../services/firestore_service.dart';
import 'admin_book_form_screen.dart';

class AdminBooksScreen extends StatefulWidget {
  const AdminBooksScreen({super.key});

  @override
  State<AdminBooksScreen> createState() => _AdminBooksScreenState();
}

class _AdminBooksScreenState extends State<AdminBooksScreen> {
  // Controller untuk fitur pencarian
  final TextEditingController _searchController = TextEditingController();

  @override
  void initState() {
    super.initState();
    // Tambahkan listener agar UI mengupdate saat user mengetik di pencarian
    _searchController.addListener(_filterBooks);
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  // Merender ulang UI saat pencarian berubah
  void _filterBooks() {
    setState(() {});
  }

  // --------------------------------------------------------------------------
  // DELETE BOOK - Fungsi menghapus buku dengan konfirmasi
  // --------------------------------------------------------------------------
  Future<void> _deleteBook(String docId, String title) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Hapus Buku'),
        content: Text('Apakah Anda yakin ingin menghapus buku "$title"?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false), // Batal
            child: const Text('Batal'),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(context, true), // Ya, hapus
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
            child: const Text('Hapus', style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );

    if (confirm == true) {
      // Eksekusi hapus di Firestore
      await FirestoreService.instance.deleteBook(docId);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Buku berhasil dihapus')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Kelola Buku'),
        backgroundColor: Colors.blue,
        foregroundColor: Colors.white,
        elevation: 0,
      ),
      body: Column(
        children: [
          // --- BAR PENCARIAN ---
          Container(
            padding: const EdgeInsets.all(16),
            color: Colors.blue.withOpacity(0.05),
            child: TextField(
              controller: _searchController,
              decoration: InputDecoration(
                hintText: 'Cari judul, pengarang, atau kategori...',
                prefixIcon: const Icon(Icons.search),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                filled: true,
                fillColor: Colors.white,
              ),
              onChanged: (_) => _filterBooks(),
            ),
          ),

          // --- DAFTAR BUKU (Real-time Stream) ---
          Expanded(
            child: StreamBuilder<List<FirestoreBook>>(
              stream: FirestoreService.instance.streamBooks(), // Pantau data Firestore
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Center(child: CircularProgressIndicator());
                }
                
                final items = snapshot.data ?? [];
                final query = _searchController.text.toLowerCase();
                
                // Filter data berdasarkan teks pencarian
                final filtered = query.isEmpty
                    ? items
                    : items.where((fb) {
                        final book = fb.book;
                        return book.judul.toLowerCase().contains(query) ||
                            book.pengarang.toLowerCase().contains(query) ||
                            book.kategori.toLowerCase().contains(query);
                      }).toList();

                // Tampilan jika data kosong
                if (filtered.isEmpty) {
                  return Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.book_outlined, size: 64, color: Colors.grey.shade400),
                        const SizedBox(height: 16),
                        Text(
                          query.isEmpty ? 'Belum ada buku' : 'Buku tidak ditemukan',
                          style: TextStyle(color: Colors.grey.shade600),
                        ),
                      ],
                    ),
                  );
                }

                // Render List Buku
                return ListView.builder(
                  padding: const EdgeInsets.all(16),
                  itemCount: filtered.length,
                  itemBuilder: (context, index) {
                    final fbBook = filtered[index];
                    final book = fbBook.book;
                    
                    return Card(
                      margin: const EdgeInsets.only(bottom: 12),
                      elevation: 2,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: ListTile(
                        contentPadding: const EdgeInsets.all(16),
                        leading: CircleAvatar(
                          backgroundColor: Colors.blue.shade100,
                          radius: 30,
                          child: const Icon(Icons.book, color: Colors.blue),
                        ),
                        title: Text(
                          book.judul,
                          style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                        ),
                        subtitle: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const SizedBox(height: 4),
                            Text('Pengarang: ${book.pengarang}'),
                            Text('Tahun: ${book.tahunTerbit} | Stok: ${book.stok}'),
                            Text('Kategori: ${book.kategori}', style: const TextStyle(fontStyle: FontStyle.italic)),
                          ],
                        ),
                        // Tombol Aksi (Edit & Hapus)
                        trailing: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            IconButton(
                              icon: const Icon(Icons.edit, color: Colors.blue),
                              onPressed: () async {
                                await Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (_) => AdminBookFormScreen(
                                      book: book,
                                      docId: fbBook.docId,
                                    ),
                                  ),
                                );
                              },
                            ),
                            IconButton(
                              icon: const Icon(Icons.delete, color: Colors.red),
                              onPressed: () => _deleteBook(fbBook.docId, book.judul),
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
      // --- TOMBOL TAMBAH BUKU ---
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () async {
          await Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => const AdminBookFormScreen()),
          );
        },
        backgroundColor: Colors.blue,
        icon: const Icon(Icons.add),
        label: const Text('Tambah Buku'),
      ),
    );
  }
}

