import 'package:sqflite/sqflite.dart' hide Transaction;
import 'package:path/path.dart';
import '../models/book.dart';
import '../models/member.dart';
import '../models/transaction.dart';
import '../models/user.dart';

class DatabaseHelper {
  static final DatabaseHelper instance = DatabaseHelper._init();
  static Database? _database;

  DatabaseHelper._init();

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDB('perpustakaan.db');
    return _database!;
  }

  Future<Database> _initDB(String filePath) async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, filePath);

    return await openDatabase(path, version: 1, onCreate: _createDB);
  }

  Future<void> _createDB(Database db, int version) async {
    // Create users table
    await db.execute('''
      CREATE TABLE users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL,
        role TEXT NOT NULL,
        member_id INTEGER,
        FOREIGN KEY (member_id) REFERENCES members(id)
      )
    ''');

    // Create members table
    await db.execute('''
      CREATE TABLE members (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nama TEXT NOT NULL,
        nis TEXT UNIQUE NOT NULL,
        kelas TEXT NOT NULL,
        alamat TEXT NOT NULL,
        no_telp TEXT NOT NULL,
        tanggal_daftar TEXT NOT NULL
      )
    ''');

    // Create books table
    await db.execute('''
      CREATE TABLE books (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        judul TEXT NOT NULL,
        pengarang TEXT NOT NULL,
        penerbit TEXT NOT NULL,
        tahun_terbit INTEGER NOT NULL,
        stok INTEGER NOT NULL,
        kategori TEXT NOT NULL,
        deskripsi TEXT
      )
    ''');

    // Create transactions table
    await db.execute('''
      CREATE TABLE transactions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        member_id INTEGER NOT NULL,
        book_id INTEGER NOT NULL,
        tanggal_pinjam TEXT NOT NULL,
        tanggal_kembali TEXT,
        tanggal_jatuh_tempo TEXT NOT NULL,
        status TEXT NOT NULL,
        denda INTEGER,
        FOREIGN KEY (member_id) REFERENCES members(id),
        FOREIGN KEY (book_id) REFERENCES books(id)
      )
    ''');

    // Insert default admin user
    await db.insert('users', {
      'username': 'admin',
      'password': 'admin123',
      'role': 'admin',
      'member_id': null,
    });

    // Insert sample data
    await _insertSampleData(db);
  }

  Future<void> _insertSampleData(Database db) async {
    // Sample books
    await db.insert('books', {
      'judul': 'Belajar Flutter untuk Pemula',
      'pengarang': 'John Doe',
      'penerbit': 'Penerbit Teknologi',
      'tahun_terbit': 2024,
      'stok': 10,
      'kategori': 'Teknologi',
      'deskripsi': 'Buku panduan lengkap belajar Flutter',
    });

    await db.insert('books', {
      'judul': 'Matematika Dasar',
      'pengarang': 'Jane Smith',
      'penerbit': 'Penerbit Pendidikan',
      'tahun_terbit': 2023,
      'stok': 15,
      'kategori': 'Pendidikan',
      'deskripsi': 'Buku matematika untuk siswa',
    });
  }

  // ============ USER OPERATIONS ============
  Future<int> insertUser(User user) async {
    final db = await database;
    return await db.insert('users', user.toMap());
  }

  Future<User?> getUserByUsername(String username) async {
    final db = await database;
    final maps = await db.query(
      'users',
      where: 'username = ?',
      whereArgs: [username],
    );

    if (maps.isNotEmpty) {
      return User.fromMap(maps.first);
    }
    return null;
  }

  Future<User?> authenticateUser(String username, String password) async {
    final db = await database;
    final maps = await db.query(
      'users',
      where: 'username = ? AND password = ?',
      whereArgs: [username, password],
    );

    if (maps.isNotEmpty) {
      return User.fromMap(maps.first);
    }
    return null;
  }

  Future<List<User>> getAllUsers() async {
    final db = await database;
    final maps = await db.query('users');
    return maps.map((map) => User.fromMap(map)).toList();
  }

  Future<int> updateUser(User user) async {
    final db = await database;
    return await db.update(
      'users',
      user.toMap(),
      where: 'id = ?',
      whereArgs: [user.id],
    );
  }

  Future<int> deleteUser(int id) async {
    final db = await database;
    return await db.delete('users', where: 'id = ?', whereArgs: [id]);
  }

  // ============ MEMBER OPERATIONS ============
  Future<int> insertMember(Member member) async {
    final db = await database;
    return await db.insert('members', member.toMap());
  }

  Future<List<Member>> getAllMembers() async {
    final db = await database;
    final maps = await db.query('members', orderBy: 'nama');
    return maps.map((map) => Member.fromMap(map)).toList();
  }

  Future<Member?> getMemberById(int id) async {
    final db = await database;
    final maps = await db.query('members', where: 'id = ?', whereArgs: [id]);
    if (maps.isNotEmpty) {
      return Member.fromMap(maps.first);
    }
    return null;
  }

  Future<List<Member>> searchMembers(String query) async {
    final db = await database;
    final maps = await db.query(
      'members',
      where: 'nama LIKE ? OR nis LIKE ? OR kelas LIKE ?',
      whereArgs: ['%$query%', '%$query%', '%$query%'],
    );
    return maps.map((map) => Member.fromMap(map)).toList();
  }

  Future<int> updateMember(Member member) async {
    final db = await database;
    return await db.update(
      'members',
      member.toMap(),
      where: 'id = ?',
      whereArgs: [member.id],
    );
  }

  Future<int> deleteMember(int id) async {
    final db = await database;
    return await db.delete('members', where: 'id = ?', whereArgs: [id]);
  }

  // ============ BOOK OPERATIONS ============
  Future<int> insertBook(Book book) async {
    final db = await database;
    return await db.insert('books', book.toMap());
  }

  Future<List<Book>> getAllBooks() async {
    final db = await database;
    final maps = await db.query('books', orderBy: 'judul');
    return maps.map((map) => Book.fromMap(map)).toList();
  }

  Future<Book?> getBookById(int id) async {
    final db = await database;
    final maps = await db.query('books', where: 'id = ?', whereArgs: [id]);
    if (maps.isNotEmpty) {
      return Book.fromMap(maps.first);
    }
    return null;
  }

  Future<List<Book>> searchBooks(String query) async {
    final db = await database;
    final maps = await db.query(
      'books',
      where: 'judul LIKE ? OR pengarang LIKE ? OR kategori LIKE ?',
      whereArgs: ['%$query%', '%$query%', '%$query%'],
    );
    return maps.map((map) => Book.fromMap(map)).toList();
  }

  Future<int> updateBook(Book book) async {
    final db = await database;
    return await db.update(
      'books',
      book.toMap(),
      where: 'id = ?',
      whereArgs: [book.id],
    );
  }

  Future<int> deleteBook(int id) async {
    final db = await database;
    return await db.delete('books', where: 'id = ?', whereArgs: [id]);
  }

  // ============ TRANSACTION OPERATIONS ============
  Future<int> insertTransaction(Transaction transaction) async {
    final db = await database;
    // Decrease book stock
    final book = await getBookById(transaction.bookId);
    if (book != null && book.stok > 0) {
      await updateBook(book.copyWith(stok: book.stok - 1));
    }
    return await db.insert('transactions', transaction.toMap());
  }

  Future<List<Transaction>> getAllTransactions() async {
    final db = await database;
    final maps = await db.query('transactions', orderBy: 'tanggal_pinjam DESC');
    return maps.map((map) => Transaction.fromMap(map)).toList();
  }

  Future<List<Transaction>> getTransactionsByMember(int memberId) async {
    final db = await database;
    final maps = await db.query(
      'transactions',
      where: 'member_id = ?',
      whereArgs: [memberId],
      orderBy: 'tanggal_pinjam DESC',
    );
    return maps.map((map) => Transaction.fromMap(map)).toList();
  }

  Future<List<Transaction>> getTransactionsByBook(int bookId) async {
    final db = await database;
    final maps = await db.query(
      'transactions',
      where: 'book_id = ?',
      whereArgs: [bookId],
      orderBy: 'tanggal_pinjam DESC',
    );
    return maps.map((map) => Transaction.fromMap(map)).toList();
  }

  Future<Transaction?> getTransactionById(int id) async {
    final db = await database;
    final maps = await db.query(
      'transactions',
      where: 'id = ?',
      whereArgs: [id],
    );
    if (maps.isNotEmpty) {
      return Transaction.fromMap(maps.first);
    }
    return null;
  }

  Future<List<Transaction>> searchTransactions(String query) async {
    final db = await database;
    final maps = await db.rawQuery(
      '''
      SELECT t.* FROM transactions t
      INNER JOIN members m ON t.member_id = m.id
      INNER JOIN books b ON t.book_id = b.id
      WHERE m.nama LIKE ? OR m.nis LIKE ? OR b.judul LIKE ?
      ORDER BY t.tanggal_pinjam DESC
    ''',
      ['%$query%', '%$query%', '%$query%'],
    );
    return maps.map((map) => Transaction.fromMap(map)).toList();
  }

  Future<int> updateTransaction(Transaction transaction) async {
    final db = await database;

    // If returning book, increase stock
    if (transaction.status == 'dikembalikan' &&
        transaction.tanggalKembali != null) {
      final oldTransaction = await getTransactionById(transaction.id!);
      if (oldTransaction != null && oldTransaction.status == 'dipinjam') {
        final book = await getBookById(transaction.bookId);
        if (book != null) {
          await updateBook(book.copyWith(stok: book.stok + 1));
        }
      }
    }

    return await db.update(
      'transactions',
      transaction.toMap(),
      where: 'id = ?',
      whereArgs: [transaction.id],
    );
  }

  Future<int> deleteTransaction(int id) async {
    final db = await database;
    final transaction = await getTransactionById(id);
    if (transaction != null && transaction.status == 'dipinjam') {
      // Increase book stock if transaction is deleted
      final book = await getBookById(transaction.bookId);
      if (book != null) {
        await updateBook(book.copyWith(stok: book.stok + 1));
      }
    }
    return await db.delete('transactions', where: 'id = ?', whereArgs: [id]);
  }

  // Get transaction with member and book details
  Future<List<Map<String, dynamic>>> getTransactionsWithDetails() async {
    final db = await database;
    return await db.rawQuery('''
      SELECT 
        t.*,
        m.nama as member_nama,
        m.nis as member_nis,
        m.kelas as member_kelas,
        b.judul as book_judul,
        b.pengarang as book_pengarang
      FROM transactions t
      INNER JOIN members m ON t.member_id = m.id
      INNER JOIN books b ON t.book_id = b.id
      ORDER BY t.tanggal_pinjam DESC
    ''');
  }

  Future<List<Map<String, dynamic>>> getTransactionsWithDetailsByMember(
    int memberId,
  ) async {
    final db = await database;
    return await db.rawQuery(
      '''
      SELECT 
        t.*,
        m.nama as member_nama,
        m.nis as member_nis,
        m.kelas as member_kelas,
        b.judul as book_judul,
        b.pengarang as book_pengarang
      FROM transactions t
      INNER JOIN members m ON t.member_id = m.id
      INNER JOIN books b ON t.book_id = b.id
      WHERE t.member_id = ?
      ORDER BY t.tanggal_pinjam DESC
    ''',
      [memberId],
    );
  }
}
