// ============================================================================
// MODEL - Book (Buku)
// ============================================================================
// Model ini merepresentasikan data Buku dalam sistem perpustakaan.
// Digunakan untuk pertukaran data antara Firestore dan UI.

class Book {
  final int? id;             // ID unik buku (opsional, digunakan untuk SQLite/Firestore)
  final String judul;        // Judul buku
  final String pengarang;    // Nama penulis/pengarang
  final String penerbit;     // Nama perusahaan penerbit
  final int tahunTerbit;     // Tahun buku diterbitkan
  final int stok;            // Jumlah buku yang tersedia di perpustakaan
  final String kategori;     // Kategori buku (misal: Novel, Sains, Sejarah)
  final String? deskripsi;   // Ringkasan atau sinopsis buku (opsional)

  Book({
    this.id,
    required this.judul,
    required this.pengarang,
    required this.penerbit,
    required this.tahunTerbit,
    required this.stok,
    required this.kategori,
    this.deskripsi,
  });

  // --------------------------------------------------------------------------
  // TO MAP - Mengubah objek Book menjadi Map (JSON-like)
  // --------------------------------------------------------------------------
  // Digunakan saat akan menyimpan data ke database (SQLite/Firestore)
  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'judul': judul,
      'pengarang': pengarang,
      'penerbit': penerbit,
      'tahun_terbit': tahunTerbit,
      'stok': stok,
      'kategori': kategori,
      'deskripsi': deskripsi,
    };
  }

  // --------------------------------------------------------------------------
  // FROM MAP - Mengubah Map menjadi objek Book
  // --------------------------------------------------------------------------
  // Digunakan saat mengambil data dari database
  factory Book.fromMap(Map<String, dynamic> map) {
    return Book(
      id: map['id'] as int?,
      judul: map['judul'] as String,
      pengarang: map['pengarang'] as String,
      penerbit: map['penerbit'] as String,
      tahunTerbit: map['tahun_terbit'] as int,
      stok: map['stok'] as int,
      kategori: map['kategori'] as String,
      deskripsi: map['deskripsi'] as String?,
    );
  }

  // --------------------------------------------------------------------------
  // COPY WITH - Membuat salinan objek dengan beberapa perubahan
  // --------------------------------------------------------------------------
  // Sangat berguna untuk mengupdate state tanpa merusak objek asli (Immutability)
  Book copyWith({
    int? id,
    String? judul,
    String? pengarang,
    String? penerbit,
    int? tahunTerbit,
    int? stok,
    String? kategori,
    String? deskripsi,
  }) {
    return Book(
      id: id ?? this.id,
      judul: judul ?? this.judul,
      pengarang: pengarang ?? this.pengarang,
      penerbit: penerbit ?? this.penerbit,
      tahunTerbit: tahunTerbit ?? this.tahunTerbit,
      stok: stok ?? this.stok,
      kategori: kategori ?? this.kategori,
      deskripsi: deskripsi ?? this.deskripsi,
    );
  }
}

