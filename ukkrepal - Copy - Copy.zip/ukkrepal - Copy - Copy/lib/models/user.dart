// ============================================================================
// MODEL - User (Pengguna Aplikasi)
// ============================================================================
// Model ini merepresentasikan akun pengguna yang bisa login.
// Bisa berupa 'admin' (petugas) atau 'user' (siswa/anggota).

class User {
  final String? id;         // ID dokumen Firebase Auth (UID)
  final String username;    // Username atau Email untuk login
  final String password;    // Password (biasanya terenkripsi di Auth)
  final String role;        // Peran: 'admin' atau 'user'
  final String? memberId;   // Hubungan ke dokumen Anggota (null jika admin)
  final String? bio;        // Bio singkat pengguna
  final String? photoUrl;   // Link foto profil dari Storage

  User({
    this.id,
    required this.username,
    required this.password,
    required this.role,
    this.memberId,
    this.bio,
    this.photoUrl,
  });

  // --------------------------------------------------------------------------
  // TO MAP - Serialisasi untuk Firestore
  // --------------------------------------------------------------------------
  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'username': username,
      'password': password,
      'role': role,
      'member_id': memberId,
      'bio': bio,
      'photo_url': photoUrl,
    };
  }

  // --------------------------------------------------------------------------
  // FROM MAP - Deserialisasi dari Firestore
  // --------------------------------------------------------------------------
  factory User.fromMap(Map<String, dynamic> map) {
    return User(
      id: map['id'] as String?,
      username: map['username'] as String,
      password: map['password'] as String,
      role: map['role'] as String,
      memberId: map['member_id'] as String?,
      bio: map['bio'] as String?,
      photoUrl: map['photo_url'] as String?,
    );
  }

  // --------------------------------------------------------------------------
  // COPY WITH - Update data user secara aman
  // --------------------------------------------------------------------------
  User copyWith({
    String? id,
    String? username,
    String? password,
    String? role,
    String? memberId,
    String? bio,
    String? photoUrl,
  }) {
    return User(
      id: id ?? this.id,
      username: username ?? this.username,
      password: password ?? this.password,
      role: role ?? this.role,
      memberId: memberId ?? this.memberId,
      bio: bio ?? this.bio,
      photoUrl: photoUrl ?? this.photoUrl,
    );
  }
}

