// ============================================================================
// MODEL - Member (Anggota)
// ============================================================================
// Model ini merepresentasikan data Siswa/Anggota perpustakaan SMKN12.

class Member {
  final int? id;               // ID unik anggota (opsional)
  final String nama;           // Nama lengkap siswa
  final String nis;            // Nomor Induk Siswa (ID utama di sekolah)
  final String kelas;          // Kelas siswa (misal: XII RPL 1)
  final String alamat;         // Alamat rumah siswa
  final String noTelp;         // Nomor telepon/WhatsApp
  final DateTime tanggalDaftar; // Tanggal mulai bergabung jadi anggota

  Member({
    this.id,
    required this.nama,
    required this.nis,
    required this.kelas,
    required this.alamat,
    required this.noTelp,
    required this.tanggalDaftar,
  });

  // --------------------------------------------------------------------------
  // TO MAP - Serialisasi ke Map
  // --------------------------------------------------------------------------
  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'nama': nama,
      'nis': nis,
      'kelas': kelas,
      'alamat': alamat,
      'no_telp': noTelp,
      'tanggal_daftar': tanggalDaftar.toIso8601String(),
    };
  }

  // --------------------------------------------------------------------------
  // FROM MAP - Deserialisasi dari Map/Firestore
  // --------------------------------------------------------------------------
  factory Member.fromMap(Map<String, dynamic> map) {
    return Member(
      id: map['id'] as int?,
      nama: map['nama'] as String,
      nis: map['nis'] as String,
      kelas: map['kelas'] as String,
      alamat: map['alamat'] as String,
      noTelp: map['no_telp'] as String,
      tanggalDaftar: DateTime.parse(map['tanggal_daftar'] as String),
    );
  }

  // --------------------------------------------------------------------------
  // COPY WITH - Mengupdate properti secara aman
  // --------------------------------------------------------------------------
  Member copyWith({
    int? id,
    String? nama,
    String? nis,
    String? kelas,
    String? alamat,
    String? noTelp,
    DateTime? tanggalDaftar,
  }) {
    return Member(
      id: id ?? this.id,
      nama: nama ?? this.nama,
      nis: nis ?? this.nis,
      kelas: kelas ?? this.kelas,
      alamat: alamat ?? this.alamat,
      noTelp: noTelp ?? this.noTelp,
      tanggalDaftar: tanggalDaftar ?? this.tanggalDaftar,
    );
  }
}

