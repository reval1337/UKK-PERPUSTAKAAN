// ============================================================================
// MODEL - Transaction (Transaksi)
// ============================================================================
// Model ini mencatat aktivitas peminjaman dan pengembalian buku.

class Transaction {
  final int? id;                  // ID unik transaksi (opsional)
  final int memberId;             // ID anggota yang meminjam
  final int bookId;               // ID buku yang dipinjam
  final DateTime tanggalPinjam;    // Tanggal buku mulai dipinjam
  final DateTime? tanggalKembali;   // Tanggal buku dikembalikan (null jika belum kembali)
  final DateTime tanggalJatuhTempo; // Batas waktu pengembalian
  final String status;             // Status: 'dipinjam', 'dikembalikan', 'terlambat'
  final int? denda;                // Jumlah denda jika terlambat

  Transaction({
    this.id,
    required this.memberId,
    required this.bookId,
    required this.tanggalPinjam,
    this.tanggalKembali,
    required this.tanggalJatuhTempo,
    required this.status,
    this.denda,
  });

  // --------------------------------------------------------------------------
  // TO MAP - Serialisasi ke Map
  // --------------------------------------------------------------------------
  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'member_id': memberId,
      'book_id': bookId,
      'tanggal_pinjam': tanggalPinjam.toIso8601String(),
      'tanggal_kembali': tanggalKembali?.toIso8601String(),
      'tanggal_jatuh_tempo': tanggalJatuhTempo.toIso8601String(),
      'status': status,
      'denda': denda,
    };
  }

  // --------------------------------------------------------------------------
  // FROM MAP - Deserialisasi dari Map
  // --------------------------------------------------------------------------
  factory Transaction.fromMap(Map<String, dynamic> map) {
    return Transaction(
      id: map['id'] as int?,
      memberId: map['member_id'] as int,
      bookId: map['book_id'] as int,
      tanggalPinjam: DateTime.parse(map['tanggal_pinjam'] as String),
      tanggalKembali: map['tanggal_kembali'] != null
          ? DateTime.parse(map['tanggal_kembali'] as String)
          : null,
      tanggalJatuhTempo: DateTime.parse(map['tanggal_jatuh_tempo'] as String),
      status: map['status'] as String,
      denda: map['denda'] as int?,
    );
  }

  // --------------------------------------------------------------------------
  // COPY WITH - Update data transaksi secara aman
  // --------------------------------------------------------------------------
  Transaction copyWith({
    int? id,
    int? memberId,
    int? bookId,
    DateTime? tanggalPinjam,
    DateTime? tanggalKembali,
    DateTime? tanggalJatuhTempo,
    String? status,
    int? denda,
  }) {
    return Transaction(
      id: id ?? this.id,
      memberId: memberId ?? this.memberId,
      bookId: bookId ?? this.bookId,
      tanggalPinjam: tanggalPinjam ?? this.tanggalPinjam,
      tanggalKembali: tanggalKembali ?? this.tanggalKembali,
      tanggalJatuhTempo: tanggalJatuhTempo ?? this.tanggalJatuhTempo,
      status: status ?? this.status,
      denda: denda ?? this.denda,
    );
  }
}

