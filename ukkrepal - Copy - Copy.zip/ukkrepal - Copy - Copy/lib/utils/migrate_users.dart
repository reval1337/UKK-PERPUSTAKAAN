import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_core/firebase_core.dart';
import '../firebase_options.dart';

/// Migration Script: Menambahkan field bio dan photo_url ke semua user yang sudah ada
/// 
/// Cara menjalankan:
/// 1. Buat file baru: lib/utils/migrate_users.dart
/// 2. Copy script ini ke file tersebut
/// 3. Di main.dart, import dan panggil migrateExistingUsers() setelah Firebase.initializeApp()
/// 4. Run aplikasi sekali
/// 5. Hapus pemanggilan migrateExistingUsers() setelah selesai

Future<void> migrateExistingUsers() async {
  // CATATAN: Migration ini membutuhkan user yang sudah login
  // karena Firestore rules memerlukan request.auth != null
  //
  // Jika belum ada user yang login, migration akan di-skip
  // dan bisa dijalankan manual nanti setelah login sebagai admin
  
  print('🔄 Checking migration status...');
  print('⚠️  Migration membutuhkan akses terautentikasi.');
  print('⚠️  Jika gagal, jalankan manual setelah login sebagai admin.');
  print('');
  
  // Skip migration untuk sekarang - akan dijalankan manual jika diperlukan
  // Uncomment kode di bawah jika ingin menjalankan migration
  /*
  try {
    final db = FirebaseFirestore.instance;
    final usersCollection = db.collection('users');
    
    // Get all users
    final snapshot = await usersCollection.get();
    print('📊 Found ${snapshot.docs.length} users to migrate');
    
    int updated = 0;
    int skipped = 0;
    
    for (var doc in snapshot.docs) {
      final data = doc.data();
      
      // Check if user already has the new fields
      if (data.containsKey('bio') && data.containsKey('photo_url')) {
        print('⏭️  Skipping ${doc.id} - already migrated');
        skipped++;
        continue;
      }
      
      // Add new fields
      await doc.reference.update({
        'bio': null,
        'photo_url': null,
        'updated_at': FieldValue.serverTimestamp(),
      });
      
      print('✅ Updated user: ${doc.id} (${data['username']})');
      updated++;
    }
    
    print('');
    print('🎉 Migration completed!');
    print('   ✅ Updated: $updated users');
    print('   ⏭️  Skipped: $skipped users');
    print('');
    
  } catch (e) {
    print('❌ Migration failed: $e');
    print('💡 Tip: Pastikan sudah login terlebih dahulu, atau update Firestore rules sementara.');
  }
  */
}

/// Alternative: Manual migration via Firebase Console
/// 
/// Jika tidak ingin menggunakan script, bisa manual di Firebase Console:
/// 
/// 1. Buka Firebase Console → Firestore Database
/// 2. Pilih collection "users"
/// 3. Untuk setiap user document:
///    - Klik document
///    - Klik "Add field"
///    - Field name: bio, Type: string, Value: (kosongkan)
///    - Klik "Add field" lagi
///    - Field name: photo_url, Type: string, Value: (kosongkan)
///    - Klik "Save"
/// 
/// Atau gunakan Firebase CLI:
/// 
/// ```bash
/// # Install Firebase CLI jika belum
/// npm install -g firebase-tools
/// 
/// # Login
/// firebase login
/// 
/// # Jalankan script migration (buat file migrate.js)
/// node migrate.js
/// ```
/// 
/// File migrate.js:
/// ```javascript
/// const admin = require('firebase-admin');
/// const serviceAccount = require('./serviceAccountKey.json');
/// 
/// admin.initializeApp({
///   credential: admin.credential.cert(serviceAccount)
/// });
/// 
/// const db = admin.firestore();
/// 
/// async function migrateUsers() {
///   const usersRef = db.collection('users');
///   const snapshot = await usersRef.get();
///   
///   const batch = db.batch();
///   
///   snapshot.forEach(doc => {
///     batch.update(doc.ref, {
///       bio: null,
///       photo_url: null,
///       updated_at: admin.firestore.FieldValue.serverTimestamp()
///     });
///   });
///   
///   await batch.commit();
///   console.log(`Updated ${snapshot.size} users`);
/// }
/// 
/// migrateUsers().then(() => process.exit(0));
/// ```
