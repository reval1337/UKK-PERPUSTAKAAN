import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';

/// Responsive helper untuk mendukung iOS, Android, dan Desktop
class ResponsiveHelper {
  /// Check if running on mobile (iOS or Android)
  static bool get isMobile {
    if (kIsWeb) return false;
    return Platform.isIOS || Platform.isAndroid;
  }

  /// Check if running on desktop (Windows, macOS, Linux)
  static bool get isDesktop {
    if (kIsWeb) return false;
    return Platform.isWindows || Platform.isMacOS || Platform.isLinux;
  }

  /// Check if running on web
  static bool get isWeb => kIsWeb;

  /// Check if running on iOS
  static bool get isIOS {
    if (kIsWeb) return false;
    return Platform.isIOS;
  }

  /// Check if running on Android
  static bool get isAndroid {
    if (kIsWeb) return false;
    return Platform.isAndroid;
  }

  /// Get responsive padding based on screen size
  static EdgeInsets getResponsivePadding(BuildContext context) {
    final width = MediaQuery.of(context).size.width;
    
    if (width < 600) {
      // Mobile
      return const EdgeInsets.all(16);
    } else if (width < 1200) {
      // Tablet
      return const EdgeInsets.all(24);
    } else {
      // Desktop
      return const EdgeInsets.all(32);
    }
  }

  /// Get responsive grid count based on screen size
  static int getGridCount(BuildContext context) {
    final width = MediaQuery.of(context).size.width;
    
    if (width < 600) {
      // Mobile: 2 columns
      return 2;
    } else if (width < 900) {
      // Tablet: 3 columns
      return 3;
    } else if (width < 1200) {
      // Small desktop: 4 columns
      return 4;
    } else {
      // Large desktop: 4-6 columns
      return 4;
    }
  }

  /// Get responsive font size
  static double getResponsiveFontSize(BuildContext context, double baseFontSize) {
    final width = MediaQuery.of(context).size.width;
    
    if (width < 600) {
      // Mobile
      return baseFontSize;
    } else if (width < 1200) {
      // Tablet
      return baseFontSize * 1.1;
    } else {
      // Desktop
      return baseFontSize * 1.2;
    }
  }

  /// Get max content width for desktop
  static double getMaxContentWidth(BuildContext context) {
    final width = MediaQuery.of(context).size.width;
    
    if (isDesktop && width > 1200) {
      return 1200; // Max width for desktop
    }
    return width;
  }

  /// Get responsive card elevation
  static double getCardElevation() {
    if (isMobile) {
      return 2;
    } else {
      return 4;
    }
  }

  /// Get responsive border radius
  static double getBorderRadius() {
    if (isMobile) {
      return 16;
    } else {
      return 20;
    }
  }

  /// Get responsive spacing
  static double getSpacing(BuildContext context) {
    final width = MediaQuery.of(context).size.width;
    
    if (width < 600) {
      return 16;
    } else if (width < 1200) {
      return 20;
    } else {
      return 24;
    }
  }

  /// Get responsive icon size
  static double getIconSize(BuildContext context, double baseSize) {
    final width = MediaQuery.of(context).size.width;
    
    if (width < 600) {
      return baseSize;
    } else if (width < 1200) {
      return baseSize * 1.2;
    } else {
      return baseSize * 1.3;
    }
  }

  /// Check if screen is small (mobile)
  static bool isSmallScreen(BuildContext context) {
    return MediaQuery.of(context).size.width < 600;
  }

  /// Check if screen is medium (tablet)
  static bool isMediumScreen(BuildContext context) {
    final width = MediaQuery.of(context).size.width;
    return width >= 600 && width < 1200;
  }

  /// Check if screen is large (desktop)
  static bool isLargeScreen(BuildContext context) {
    return MediaQuery.of(context).size.width >= 1200;
  }

  /// Get platform-specific scroll physics
  static ScrollPhysics getPlatformScrollPhysics() {
    if (isIOS) {
      return const BouncingScrollPhysics();
    } else {
      return const ClampingScrollPhysics();
    }
  }

  /// Get safe area padding
  static EdgeInsets getSafeAreaPadding(BuildContext context) {
    return MediaQuery.of(context).padding;
  }

  /// Responsive value based on screen size
  static T responsiveValue<T>(
    BuildContext context, {
    required T mobile,
    T? tablet,
    T? desktop,
  }) {
    final width = MediaQuery.of(context).size.width;
    
    if (width < 600) {
      return mobile;
    } else if (width < 1200) {
      return tablet ?? mobile;
    } else {
      return desktop ?? tablet ?? mobile;
    }
  }
}

/// Extension for responsive sizing
extension ResponsiveExtension on num {
  /// Convert to responsive width
  double get w => toDouble();
  
  /// Convert to responsive height
  double get h => toDouble();
  
  /// Convert to responsive font size
  double get sp => toDouble();
}
