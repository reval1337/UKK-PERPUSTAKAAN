// ============================================================================
// IMPORTS - Package yang dibutuhkan aplikasi
// ============================================================================

// Flutter Core - Framework utama untuk membangun UI
import 'package:flutter/material.dart';

// Firebase Core - Package utama untuk koneksi ke Firebase
// Digunakan untuk inisialisasi Firebase di aplikasi
import 'package:firebase_core/firebase_core.dart';

// Google Fonts - Package untuk menggunakan font dari Google Fonts
// Aplikasi ini menggunakan font "Poppins" untuk tampilan modern
import 'package:google_fonts/google_fonts.dart';

// Flutter ScreenUtil - Package untuk responsive design
// Membuat UI otomatis menyesuaikan dengan ukuran layar berbeda
import 'package:flutter_screenutil/flutter_screenutil.dart';

// Firebase Options - File konfigurasi Firebase (auto-generated)
// Berisi API keys dan konfigurasi untuk koneksi ke Firebase project
import 'firebase_options.dart';

// Screens - Import semua halaman/screen yang digunakan
import 'screens/login_screen.dart';           // Halaman login
import 'screens/admin/admin_dashboard.dart';  // Dashboard untuk admin
import 'screens/user/user_dashboard.dart';    // Dashboard untuk user/anggota

// Services - Import service layer untuk business logic
import 'services/auth_service.dart';          // Service untuk autentikasi (login/logout)

// ============================================================================
// MAIN FUNCTION - Entry Point Aplikasi
// ============================================================================
// Function ini adalah yang PERTAMA KALI dijalankan saat aplikasi dibuka
// Semua inisialisasi penting dilakukan di sini sebelum aplikasi berjalan

void main() async {
  // async: Karena ada proses yang membutuhkan waktu (Firebase init)
  
  // 1. INISIALISASI FLUTTER WIDGETS
  // Memastikan Flutter framework sudah siap sebelum menjalankan kode async
  // Wajib dipanggil sebelum menggunakan async di main()
  WidgetsFlutterBinding.ensureInitialized();
  
  // 2. INISIALISASI FIREBASE
  // Menghubungkan aplikasi ke Firebase project
  // await: Menunggu sampai koneksi Firebase selesai
  // DefaultFirebaseOptions.currentPlatform: Konfigurasi otomatis sesuai platform (Android/iOS/Web)
  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
  
  // 3. JALANKAN APLIKASI
  // runApp() memulai aplikasi Flutter dengan widget MyApp sebagai root
  runApp(const MyApp());
}


// ============================================================================
// CLASS MYAPP - Root Widget Aplikasi
// ============================================================================
// MyApp adalah widget utama yang membungkus seluruh aplikasi
// Di sini kita setup:
// - Responsive design (ScreenUtil)
// - Tema aplikasi (warna, font, style)
// - Routing/navigasi
// - Material Design 3

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    // ========================================================================
    // SCREENUTIL INIT - Setup Responsive Design
    // ========================================================================
    // ScreenUtilInit membuat UI otomatis menyesuaikan ukuran layar
    // Semua ukuran (width, height, font) akan otomatis scale
    
    return ScreenUtilInit(
      // Design size: Ukuran layar referensi untuk design
      // 375x812 adalah ukuran iPhone X (standar mobile design)
      // Semua ukuran akan di-scale relatif terhadap ukuran ini
      designSize: const Size(375, 812), // iPhone X size as base
      
      // minTextAdapt: true - Font size akan menyesuaikan dengan ukuran layar
      minTextAdapt: true,
      
      // splitScreenMode: true - Support untuk split screen mode
      splitScreenMode: true,
      
      // builder: Function yang membangun UI setelah ScreenUtil ready
      builder: (context, child) {
        return MaterialApp(
          // ====================================================================
          // KONFIGURASI APLIKASI
          // ====================================================================
          
          // Title aplikasi (muncul di task manager/app switcher)
          title: 'Perpustakaan SMKN12',
          
          // debugShowCheckedModeBanner: false - Hilangkan banner "DEBUG" di pojok kanan atas
          debugShowCheckedModeBanner: false,
          
          // ====================================================================
          // THEME - Konfigurasi Tema Aplikasi
          // ====================================================================
          theme: ThemeData(
            // ------------------------------------------------------------------
            // COLOR SCHEME - Palet Warna Aplikasi
            // ------------------------------------------------------------------
            colorScheme: ColorScheme.fromSeed(
              // seedColor: Warna utama yang digunakan untuk generate palet warna
              seedColor: const Color(0xFF6366F1), // Modern indigo (ungu kebiruan)
              
              // primary: Warna utama aplikasi (tombol, AppBar, dll)
              primary: const Color(0xFF6366F1),
              
              // secondary: Warna aksen/pelengkap
              secondary: const Color(0xFF14B8A6), // Teal accent (hijau kebiruan)
              
              // brightness: Mode terang/gelap
              brightness: Brightness.light,
            ),
            
            // useMaterial3: true - Gunakan Material Design 3 (design terbaru dari Google)
            useMaterial3: true,
            
            // ------------------------------------------------------------------
            // TEXT THEME - Font untuk seluruh aplikasi
            // ------------------------------------------------------------------
            // GoogleFonts.poppinsTextTheme() - Gunakan font Poppins dari Google Fonts
            // Poppins adalah font modern, clean, dan mudah dibaca
            textTheme: GoogleFonts.poppinsTextTheme(),
            
            // ------------------------------------------------------------------
            // CARD THEME - Style untuk widget Card
            // ------------------------------------------------------------------
            cardTheme: CardThemeData(
              elevation: 0, // Hilangkan shadow default
              shape: RoundedRectangleBorder(
                // borderRadius: Sudut card melengkung
                // .r dari ScreenUtil membuat radius responsive
                borderRadius: BorderRadius.circular(20.r), // Responsive radius
              ),
              color: Colors.white, // Warna background card
              shadowColor: Colors.black.withOpacity(0.1), // Warna shadow (transparan)
            ),
            
            // ------------------------------------------------------------------
            // ELEVATED BUTTON THEME - Style untuk tombol
            // ------------------------------------------------------------------
            elevatedButtonTheme: ElevatedButtonThemeData(
              style: ElevatedButton.styleFrom(
                // Padding tombol (jarak teks ke tepi tombol)
                // .w dan .h dari ScreenUtil membuat padding responsive
                padding: EdgeInsets.symmetric(
                  horizontal: 32.w, // Padding kiri-kanan
                  vertical: 16.h,   // Padding atas-bawah
                ), // Responsive padding
                
                elevation: 0, // Hilangkan shadow tombol (flat design)
                
                // Shape tombol dengan sudut melengkung
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16.r),
                ),
                
                // Style teks di dalam tombol
                textStyle: GoogleFonts.poppins(
                  fontSize: 16.sp, // Responsive font size (.sp dari ScreenUtil)
                  fontWeight: FontWeight.w600, // Semi-bold
                ),
              ),
            ),
            
            // ------------------------------------------------------------------
            // INPUT DECORATION THEME - Style untuk TextField/TextFormField
            // ------------------------------------------------------------------
            inputDecorationTheme: InputDecorationTheme(
              // Border default (saat tidak fokus dan tidak ada error)
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(16.r),
                borderSide: BorderSide(color: Colors.grey.shade300),
              ),
              
              // Border saat TextField enabled tapi tidak fokus
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(16.r),
                borderSide: BorderSide(color: Colors.grey.shade300),
              ),
              
              // Border saat TextField sedang fokus (user sedang mengetik)
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(16.r),
                borderSide: const BorderSide(
                  color: Color(0xFF6366F1), // Warna primary (indigo)
                  width: 2, // Border lebih tebal saat fokus
                ),
              ),
              
              // filled: true - TextField memiliki background color
              filled: true,
              
              // fillColor: Warna background TextField
              fillColor: Colors.grey.shade50, // Abu-abu sangat terang
              
              // contentPadding: Jarak teks ke border TextField
              contentPadding: EdgeInsets.symmetric(
                horizontal: 20.w,
                vertical: 16.h,
              ),
            ),
            
            // ------------------------------------------------------------------
            // APPBAR THEME - Style untuk AppBar
            // ------------------------------------------------------------------
            appBarTheme: AppBarTheme(
              elevation: 0, // Hilangkan shadow AppBar (flat design)
              centerTitle: true, // Title AppBar di tengah
              
              // Style untuk title text di AppBar
              titleTextStyle: GoogleFonts.poppins(
                fontSize: 20.sp, // Responsive font size
                fontWeight: FontWeight.w600, // Semi-bold
                color: Colors.white, // Warna putih
              ),
            ),
          ),
          
          // ====================================================================
          // HOME - Screen pertama yang ditampilkan
          // ====================================================================
          // SplashScreen akan muncul pertama kali saat aplikasi dibuka
          home: const SplashScreen(),
        );
      },
    );
  }
}


// ============================================================================
// CLASS SPLASHSCREEN - Loading Screen dengan Animasi
// ============================================================================
// SplashScreen adalah layar pertama yang muncul saat aplikasi dibuka
// Fungsi:
// 1. Menampilkan logo dan nama aplikasi dengan animasi
// 2. Mengecek apakah user sudah login sebelumnya (auto-login)
// 3. Redirect ke screen yang sesuai berdasarkan status login dan role user
//
// StatefulWidget: Karena ada state yang berubah (animasi)

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

// ============================================================================
// STATE CLASS - Logic dan State Management untuk SplashScreen
// ============================================================================
// SingleTickerProviderStateMixin: Diperlukan untuk AnimationController
// Mixin ini menyediakan Ticker untuk animasi

class _SplashScreenState extends State<SplashScreen> with SingleTickerProviderStateMixin {
  // ==========================================================================
  // PROPERTIES - Variable untuk animasi
  // ==========================================================================
  
  // late: Variable akan diinisialisasi di initState (bukan saat deklarasi)
  
  // AnimationController: Mengontrol durasi dan status animasi
  late AnimationController _controller;
  
  // Animation<double>: Animasi untuk scale (ukuran) logo
  late Animation<double> _scaleAnimation;
  
  // Animation<double>: Animasi untuk fade (opacity/transparansi)
  late Animation<double> _fadeAnimation;

  // ==========================================================================
  // INIT STATE - Dipanggil pertama kali saat widget dibuat
  // ==========================================================================
  @override
  void initState() {
    super.initState();
    
    // ------------------------------------------------------------------------
    // 1. SETUP ANIMATION CONTROLLER
    // ------------------------------------------------------------------------
    // AnimationController mengontrol animasi
    _controller = AnimationController(
      duration: const Duration(milliseconds: 1500), // Durasi animasi 1.5 detik
      vsync: this, // vsync dari SingleTickerProviderStateMixin
    );
    
    // ------------------------------------------------------------------------
    // 2. SETUP SCALE ANIMATION (Animasi Ukuran)
    // ------------------------------------------------------------------------
    // Tween: Mendefinisikan nilai awal dan akhir
    // begin: 0.5 (50% dari ukuran normal)
    // end: 1.0 (100% ukuran normal)
    // Curves.elasticOut: Efek bouncing/elastic saat animasi selesai
    _scaleAnimation = Tween<double>(begin: 0.5, end: 1.0).animate(
      CurvedAnimation(parent: _controller, curve: Curves.elasticOut),
    );
    
    // ------------------------------------------------------------------------
    // 3. SETUP FADE ANIMATION (Animasi Transparansi)
    // ------------------------------------------------------------------------
    // begin: 0.0 (transparan penuh/tidak terlihat)
    // end: 1.0 (opaque penuh/terlihat jelas)
    // Curves.easeIn: Animasi dimulai pelan lalu cepat
    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _controller, curve: Curves.easeIn),
    );
    
    // ------------------------------------------------------------------------
    // 4. JALANKAN ANIMASI
    // ------------------------------------------------------------------------
    _controller.forward(); // Mulai animasi dari awal ke akhir
    
    // ------------------------------------------------------------------------
    // 5. CEK STATUS LOGIN
    // ------------------------------------------------------------------------
    // Memanggil function untuk cek apakah user sudah login
    _checkLoginStatus();
  }

  // ==========================================================================
  // DISPOSE - Cleanup saat widget dihapus dari memory
  // ==========================================================================
  @override
  void dispose() {
    // Hentikan dan hapus AnimationController untuk mencegah memory leak
    _controller.dispose();
    super.dispose();
  }

  // ==========================================================================
  // CHECK LOGIN STATUS - Cek apakah user sudah login & redirect
  // ==========================================================================
  // Function ini dipanggil di initState
  // Fungsi:
  // 1. Tunggu 2 detik (biar user sempat lihat splash screen)
  // 2. Cek status login via AuthService
  // 3. Redirect ke screen yang sesuai
  
  Future<void> _checkLoginStatus() async {
    // Tunggu 2 detik (delay untuk splash screen)
    await Future.delayed(const Duration(seconds: 2));
    
    // Cek apakah user sudah login
    // AuthService.instance.isLoggedIn() mengecek di Firebase Auth
    final isLoggedIn = await AuthService.instance.isLoggedIn();

    // mounted: Cek apakah widget masih ada di widget tree
    // Penting untuk dicek sebelum Navigator, karena async operation
    if (mounted) {
      // ======================================================================
      // JIKA USER SUDAH LOGIN
      // ======================================================================
      if (isLoggedIn) {
        // Ambil data user dari Firestore
        final user = await AuthService.instance.getCurrentUser();
        
        if (user != null) {
          // ----------------------------------------------------------------
          // ROUTING BERDASARKAN ROLE
          // ----------------------------------------------------------------
          // Cek role user dan redirect ke dashboard yang sesuai
          
          if (user.role == 'admin') {
            // User adalah ADMIN → Redirect ke AdminDashboard
            Navigator.of(context).pushReplacement(
              MaterialPageRoute(builder: (_) => const AdminDashboard()),
            );
          } else {
            // User adalah MEMBER/USER → Redirect ke UserDashboard
            Navigator.of(context).pushReplacement(
              MaterialPageRoute(builder: (_) => const UserDashboard()),
            );
          }
        } else {
          // Data user null (error) → Redirect ke LoginScreen
          Navigator.of(context).pushReplacement(
            MaterialPageRoute(builder: (_) => const LoginScreen()),
          );
        }
      } 
      // ======================================================================
      // JIKA USER BELUM LOGIN
      // ======================================================================
      else {
        // Redirect ke LoginScreen
        Navigator.of(context).pushReplacement(
          MaterialPageRoute(builder: (_) => const LoginScreen()),
        );
      }
    }
  }

  // ==========================================================================
  // BUILD - Membangun UI SplashScreen
  // ==========================================================================
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // ======================================================================
      // BACKGROUND GRADIENT
      // ======================================================================
      body: Container(
        decoration: const BoxDecoration(
          // Gradient dari kiri-atas ke kanan-bawah
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              Color(0xFF6366F1), // Indigo (ungu kebiruan)
              Color(0xFF8B5CF6), // Purple (ungu)
              Color(0xFF14B8A6), // Teal (hijau kebiruan)
            ],
          ),
        ),
        
        // ====================================================================
        // CONTENT - Logo dan Text di tengah layar
        // ====================================================================
        child: Center(
          // AnimatedBuilder: Rebuild widget setiap kali animasi berubah
          child: AnimatedBuilder(
            animation: _controller, // Listen ke animation controller
            builder: (context, child) {
              return Opacity(
                // Opacity berubah sesuai _fadeAnimation (0.0 → 1.0)
                opacity: _fadeAnimation.value,
                
                child: Transform.scale(
                  // Scale berubah sesuai _scaleAnimation (0.5 → 1.0)
                  scale: _scaleAnimation.value,
                  
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center, // Tengah vertikal
                    children: [
                      // ===========================================================
                      // LOGO - Icon buku dalam lingkaran putih
                      // ===========================================================
                      Container(
                        width: 140.w, // Responsive width
                        height: 140.w, // Responsive height (square/persegi)
                        decoration: BoxDecoration(
                          color: Colors.white, // Background putih
                          shape: BoxShape.circle, // Bentuk lingkaran
                          boxShadow: [
                            // Shadow untuk efek depth
                            BoxShadow(
                              color: Colors.black.withOpacity(0.2), // Hitam 20% opacity
                              blurRadius: 30, // Blur shadow
                              spreadRadius: 5, // Spread shadow
                              offset: const Offset(0, 10), // Posisi shadow (x, y)
                            ),
                          ],
                        ),
                        child: Icon(
                          Icons.auto_stories_rounded, // Icon buku terbuka
                          size: 80.sp, // Responsive icon size
                          color: const Color(0xFF6366F1), // Warna indigo
                        ),
                      ),
                      
                      SizedBox(height: 32.h), // Spacing responsive
                      
                      // ===========================================================
                      // TITLE - Nama aplikasi
                      // ===========================================================
                      Text(
                        'Perpustakaan SMKN12',
                        style: GoogleFonts.poppins(
                          fontSize: 32.sp, // Responsive font size
                          fontWeight: FontWeight.bold, // Bold
                          color: Colors.white, // Putih
                          letterSpacing: -0.5, // Jarak antar huruf (sedikit rapat)
                        ),
                      ),
                      
                      SizedBox(height: 12.h), // Spacing
                      
                      // ===========================================================
                      // SUBTITLE - Deskripsi aplikasi
                      // ===========================================================
                      Padding(
                        padding: EdgeInsets.symmetric(horizontal: 40.w),
                        child: Text(
                          'Sistem Manajemen Perpustakaan Digital',
                          textAlign: TextAlign.center, // Text di tengah
                          style: GoogleFonts.poppins(
                            fontSize: 16.sp, // Responsive font
                            color: Colors.white.withOpacity(0.9), // Putih 90% opacity
                            fontWeight: FontWeight.w300, // Light weight
                          ),
                        ),
                      ),
                      
                      SizedBox(height: 48.h), // Spacing
                      
                      // ===========================================================
                      // LOADING INDICATOR - Circular progress
                      // ===========================================================
                      SizedBox(
                        width: 40.w, // Responsive width
                        height: 40.w, // Responsive height
                        child: CircularProgressIndicator(
                          // Warna loading indicator
                          valueColor: AlwaysStoppedAnimation<Color>(
                            Colors.white.withOpacity(0.8), // Putih 80% opacity
                          ),
                          strokeWidth: 3, // Ketebalan garis loading
                        ),
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
        ),
      ),
    );
  }
}
