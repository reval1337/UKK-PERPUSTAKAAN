// ============================================================================
// IMPORTS - Package untuk pembuatan dan pencetakan PDF
// ============================================================================
import 'package:flutter/material.dart';
import 'package:pdf/pdf.dart';                      // Core library PDF
import 'package:pdf/widgets.dart' as pw;            // Widget khusus PDF (pake prefix pw)
import 'package:printing/printing.dart';           // Package untuk cetak/preview PDF
import 'package:intl/intl.dart';                    // Untuk format tanggal dan angka
import '../services/firestore_service.dart';        // Service data Firestore

// ============================================================================
// CLASS PDFSERVICE - Service untuk membuat dokumen PDF
// ============================================================================
// Service ini menangani pembuatan:
// 1. Bukti Peminjaman (Receipt)
// 2. Bukti Pengembalian (Receipt)
// 3. Laporan Data Buku, Anggota, dan Transaksi (Report)

class PdfService {
  static final _fs = FirestoreService.instance;

  // ==========================================================================
  // 1. BUKTI PEMINJAMAN (BORROW RECEIPT)
  // ==========================================================================
  // Membuat struk kecil (A5) saat siswa meminjam buku
  static Future<void> generateBorrowReceipt(
    BuildContext context, {
    required String bookTitle,
    required String bookAuthor,
    required String memberName,
    required String memberNis,
    required String memberClass,
    required DateTime borrowDate,
    required DateTime dueDate,
  }) async {
    try {
      final pdf = pw.Document();

      pdf.addPage(
        pw.Page(
          pageFormat: PdfPageFormat.a5, // Ukuran kertas A5
          build: (pw.Context context) {
            return pw.Center(
              child: pw.Container(
                width: double.infinity,
                padding: const pw.EdgeInsets.all(20),
                decoration: pw.BoxDecoration(
                  border: pw.Border.all(color: PdfColors.black),
                ),
                child: pw.Column(
                  crossAxisAlignment: pw.CrossAxisAlignment.start,
                  children: [
                    // --- HEADER ---
                    pw.Center(
                      child: pw.Column(
                        children: [
                          pw.Text(
                            'BUKTI PEMINJAMAN BUKU',
                            style: pw.TextStyle(
                              fontSize: 18,
                              fontWeight: pw.FontWeight.bold,
                            ),
                          ),
                          pw.SizedBox(height: 5),
                          pw.Text(
                            'Perpustakaan SMKN12',
                            style: pw.TextStyle(fontSize: 12),
                          ),
                        ],
                      ),
                    ),
                    pw.Divider(),
                    pw.SizedBox(height: 10),

                    // --- DATA BUKU ---
                    pw.Text(
                      'DATA BUKU',
                      style: pw.TextStyle(
                        fontSize: 14,
                        fontWeight: pw.FontWeight.bold,
                      ),
                    ),
                    pw.SizedBox(height: 5),
                    pw.Text('Judul: $bookTitle'),
                    pw.Text('Pengarang: $bookAuthor'),
                    pw.SizedBox(height: 10),

                    // --- DATA ANGGOTA ---
                    pw.Text(
                      'DATA ANGGOTA',
                      style: pw.TextStyle(
                        fontSize: 14,
                        fontWeight: pw.FontWeight.bold,
                      ),
                    ),
                    pw.SizedBox(height: 5),
                    pw.Text('Nama: $memberName'),
                    pw.Text('NIS: $memberNis'),
                    pw.Text('Kelas: $memberClass'),
                    pw.SizedBox(height: 10),

                    // --- INFO TANGGAL ---
                    pw.Text(
                      'TANGGAL PINJAM',
                      style: pw.TextStyle(
                        fontSize: 14,
                        fontWeight: pw.FontWeight.bold,
                      ),
                    ),
                    pw.SizedBox(height: 5),
                    pw.Text(
                      'Tanggal Pinjam: ${DateFormat('dd/MM/yyyy').format(borrowDate)}',
                    ),
                    pw.Text(
                      'Jatuh Tempo: ${DateFormat('dd/MM/yyyy').format(dueDate)}',
                    ),
                    pw.SizedBox(height: 20),

                    // --- AREA TANDA TANGAN ---
                    pw.Row(
                      mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
                      children: [
                        pw.Column(
                          crossAxisAlignment: pw.CrossAxisAlignment.center,
                          children: [
                            pw.Text('Petugas'),
                            pw.SizedBox(height: 30),
                            pw.Text('(_________________)'),
                          ],
                        ),
                        pw.Column(
                          crossAxisAlignment: pw.CrossAxisAlignment.center,
                          children: [
                            pw.Text('Anggota'),
                            pw.SizedBox(height: 30),
                            pw.Text('(_________________)'),
                          ],
                        ),
                      ],
                    ),
                    pw.SizedBox(height: 10),
                    pw.Center(
                      child: pw.Text(
                        'Harap kembalikan buku tepat waktu!',
                        style: pw.TextStyle(
                          fontSize: 10,
                          fontStyle: pw.FontStyle.italic,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        ),
      );

      // Munculkan dialog cetak/layout
      await Printing.layoutPdf(
        onLayout: (PdfPageFormat format) async => pdf.save(),
      );
    } catch (e) {
      if (context.mounted) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text('Error membuat PDF: $e')));
      }
    }
  }

  // ==========================================================================
  // 2. BUKTI PENGEMBALIAN (RETURN RECEIPT)
  // ==========================================================================
  // Membuat struk saat buku dikembalikan, termasuk info denda jika ada
  static Future<void> generateReturnReceipt(
    BuildContext context, {
    required String bookTitle,
    required String memberName,
    required String memberNis,
    required DateTime returnDate,
    int? fine,
  }) async {
    try {
      final pdf = pw.Document();

      pdf.addPage(
        pw.Page(
          pageFormat: PdfPageFormat.a5,
          build: (pw.Context context) {
            return pw.Center(
              child: pw.Container(
                width: double.infinity,
                padding: const pw.EdgeInsets.all(20),
                decoration: pw.BoxDecoration(
                  border: pw.Border.all(color: PdfColors.black),
                ),
                child: pw.Column(
                  crossAxisAlignment: pw.CrossAxisAlignment.start,
                  children: [
                    // --- HEADER ---
                    pw.Center(
                      child: pw.Column(
                        children: [
                          pw.Text(
                            'BUKTI PENGEMBALIAN BUKU',
                            style: pw.TextStyle(
                              fontSize: 18,
                              fontWeight: pw.FontWeight.bold,
                            ),
                          ),
                          pw.SizedBox(height: 5),
                          pw.Text(
                            'Perpustakaan SMKN12',
                            style: pw.TextStyle(fontSize: 12),
                          ),
                        ],
                      ),
                    ),
                    pw.Divider(),
                    pw.SizedBox(height: 10),

                    // --- DATA BUKU ---
                    pw.Text(
                      'DATA BUKU',
                      style: pw.TextStyle(
                        fontSize: 14,
                        fontWeight: pw.FontWeight.bold,
                      ),
                    ),
                    pw.SizedBox(height: 5),
                    pw.Text('Judul: $bookTitle'),
                    pw.SizedBox(height: 10),

                    // --- DATA ANGGOTA ---
                    pw.Text(
                      'DATA ANGGOTA',
                      style: pw.TextStyle(
                        fontSize: 14,
                        fontWeight: pw.FontWeight.bold,
                      ),
                    ),
                    pw.SizedBox(height: 5),
                    pw.Text('Nama: $memberName'),
                    pw.Text('NIS: $memberNis'),
                    pw.SizedBox(height: 10),

                    // --- INFO KEMBALI ---
                    pw.Text(
                      'TANGGAL PENGEMBALIAN',
                      style: pw.TextStyle(
                        fontSize: 14,
                        fontWeight: pw.FontWeight.bold,
                      ),
                    ),
                    pw.SizedBox(height: 5),
                    pw.Text(
                      'Tanggal Kembali: ${DateFormat('dd/MM/yyyy').format(returnDate)}',
                    ),
                    
                    // Tampilkan denda jika ada
                    if (fine != null && fine > 0) ...[
                      pw.SizedBox(height: 5),
                      pw.Text(
                        'Denda: Rp ${NumberFormat('#,##0').format(fine)}',
                        style: pw.TextStyle(
                          fontWeight: pw.FontWeight.bold,
                          color: PdfColors.red,
                        ),
                      ),
                    ],
                    pw.SizedBox(height: 20),

                    // --- TANDA TANGAN ---
                    pw.Row(
                      mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
                      children: [
                        pw.Column(
                          crossAxisAlignment: pw.CrossAxisAlignment.center,
                          children: [
                            pw.Text('Petugas'),
                            pw.SizedBox(height: 30),
                            pw.Text('(_________________)'),
                          ],
                        ),
                        pw.Column(
                          crossAxisAlignment: pw.CrossAxisAlignment.center,
                          children: [
                            pw.Text('Anggota'),
                            pw.SizedBox(height: 30),
                            pw.Text('(_________________)'),
                          ],
                        ),
                      ],
                    ),
                    pw.SizedBox(height: 10),
                    pw.Center(
                      child: pw.Text(
                        'Terima kasih telah mengembalikan buku tepat waktu!',
                        style: pw.TextStyle(
                          fontSize: 10,
                          fontStyle: pw.FontStyle.italic,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        ),
      );

      await Printing.layoutPdf(
        onLayout: (PdfPageFormat format) async => pdf.save(),
      );
    } catch (e) {
      if (context.mounted) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text('Error membuat PDF: $e')));
      }
    }
  }

  // ==========================================================================
  // 3. LAPORAN DATA BUKU (BOOKS REPORT)
  // ==========================================================================
  // Membuat laporan tabel berisi seluruh koleksi buku
  static Future<void> generateBooksReport(BuildContext context) async {
    try {
      // Ambil data buku dari Firestore
      final fbBooks = await _fs.getAllBooks();
      final books = fbBooks.map((fb) => fb.book).toList();

      final pdf = pw.Document();
      pdf.addPage(
        pw.MultiPage(
          pageFormat: PdfPageFormat.a4, // Ukuran kertas A4
          build: (pw.Context context) {
            return [
              // Judul Laporan
              pw.Header(
                level: 0,
                child: pw.Text(
                  'LAPORAN DATA BUKU',
                  style: pw.TextStyle(
                    fontSize: 24,
                    fontWeight: pw.FontWeight.bold,
                  ),
                ),
              ),
              pw.SizedBox(height: 20),
              pw.Text('Perpustakaan SMKN12', style: pw.TextStyle(fontSize: 14)),
              pw.Text(
                'Tanggal: ${DateFormat('dd MMMM yyyy').format(DateTime.now())}',
                style: pw.TextStyle(fontSize: 12),
              ),
              pw.SizedBox(height: 20),

              // Tabel Data Buku
              pw.Table(
                border: pw.TableBorder.all(), // Garis tabel
                children: [
                  // --- TABLE HEADER ---
                  pw.TableRow(
                    decoration: const pw.BoxDecoration(
                      color: PdfColors.grey300, // Warna background header
                    ),
                    children: [
                      _buildTableCell('No', isHeader: true),
                      _buildTableCell('Judul', isHeader: true),
                      _buildTableCell('Pengarang', isHeader: true),
                      _buildTableCell('Penerbit', isHeader: true),
                      _buildTableCell('Tahun', isHeader: true),
                      _buildTableCell('Stok', isHeader: true),
                      _buildTableCell('Kategori', isHeader: true),
                    ],
                  ),
                  // --- TABLE DATA ---
                  ...books.asMap().entries.map((entry) {
                    final index = entry.key;
                    final book = entry.value;
                    return pw.TableRow(
                      children: [
                        _buildTableCell('${index + 1}'),
                        _buildTableCell(book.judul),
                        _buildTableCell(book.pengarang),
                        _buildTableCell(book.penerbit),
                        _buildTableCell('${book.tahunTerbit}'),
                        _buildTableCell('${book.stok}'),
                        _buildTableCell(book.kategori),
                      ],
                    );
                  }),
                ],
              ),
              pw.SizedBox(height: 20),
              pw.Text(
                'Total Buku: ${books.length}',
                style: pw.TextStyle(fontWeight: pw.FontWeight.bold),
              ),
            ];
          },
        ),
      );

      await Printing.layoutPdf(
        onLayout: (PdfPageFormat format) async => pdf.save(),
      );
    } catch (e) {
      if (context.mounted) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text('Error: $e')));
      }
    }
  }

  // ==========================================================================
  // 4. LAPORAN DATA ANGGOTA (MEMBERS REPORT)
  // ==========================================================================
  // Membuat laporan tabel berisi data seluruh siswa yang terdaftar
  static Future<void> generateMembersReport(BuildContext context) async {
    try {
      final members = await _fs.getAllMembers();

      final pdf = pw.Document();
      pdf.addPage(
        pw.MultiPage(
          pageFormat: PdfPageFormat.a4,
          build: (pw.Context context) {
            return [
              pw.Header(
                level: 0,
                child: pw.Text(
                  'LAPORAN DATA ANGGOTA',
                  style: pw.TextStyle(
                    fontSize: 24,
                    fontWeight: pw.FontWeight.bold,
                  ),
                ),
              ),
              pw.SizedBox(height: 20),
              pw.Text('Perpustakaan SMKN12', style: pw.TextStyle(fontSize: 14)),
              pw.Text(
                'Tanggal: ${DateFormat('dd MMMM yyyy').format(DateTime.now())}',
                style: pw.TextStyle(fontSize: 12),
              ),
              pw.SizedBox(height: 20),

              // Tabel Anggota
              pw.Table(
                border: pw.TableBorder.all(),
                children: [
                  pw.TableRow(
                    decoration: const pw.BoxDecoration(color: PdfColors.grey300),
                    children: [
                      _buildTableCell('No', isHeader: true),
                      _buildTableCell('Nama', isHeader: true),
                      _buildTableCell('NIS', isHeader: true),
                      _buildTableCell('Kelas', isHeader: true),
                      _buildTableCell('Alamat', isHeader: true),
                      _buildTableCell('No. Telp', isHeader: true),
                      _buildTableCell('Daftar', isHeader: true),
                    ],
                  ),
                  ...members.asMap().entries.map((entry) {
                    final index = entry.key;
                    final member = entry.value;
                    final tanggalStr = member['tanggal_daftar'] as String?;
                    DateTime tanggal = DateTime.now();
                    if (tanggalStr != null) {
                      tanggal = DateTime.tryParse(tanggalStr) ?? DateTime.now();
                    }
                    return pw.TableRow(
                      children: [
                        _buildTableCell('${index + 1}'),
                        _buildTableCell(member['nama'] ?? ''),
                        _buildTableCell(member['nis'] ?? ''),
                        _buildTableCell(member['kelas'] ?? ''),
                        _buildTableCell(member['alamat'] ?? ''),
                        _buildTableCell(member['no_telp'] ?? ''),
                        _buildTableCell(DateFormat('dd/MM/yy').format(tanggal)),
                      ],
                    );
                  }),
                ],
              ),
              pw.SizedBox(height: 20),
              pw.Text(
                'Total Anggota: ${members.length}',
                style: pw.TextStyle(fontWeight: pw.FontWeight.bold),
              ),
            ];
          },
        ),
      );

      await Printing.layoutPdf(
        onLayout: (PdfPageFormat format) async => pdf.save(),
      );
    } catch (e) {
      if (context.mounted) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text('Error: $e')));
      }
    }
  }

  // ==========================================================================
  // 5. LAPORAN TRANSAKSI (TRANSACTIONS REPORT)
  // ==========================================================================
  // Membuat laporan seluruh riwayat peminjaman dan pengembalian
  static Future<void> generateTransactionsReport(BuildContext context) async {
    try {
      final transactions = await _fs.getTransactionsWithDetails();

      final pdf = pw.Document();
      pdf.addPage(
        pw.MultiPage(
          pageFormat: PdfPageFormat.a4,
          build: (pw.Context context) {
            return [
              pw.Header(
                level: 0,
                child: pw.Text(
                  'LAPORAN TRANSAKSI',
                  style: pw.TextStyle(
                    fontSize: 24,
                    fontWeight: pw.FontWeight.bold,
                  ),
                ),
              ),
              pw.SizedBox(height: 20),
              pw.Text('Perpustakaan SMKN12', style: pw.TextStyle(fontSize: 14)),
              pw.Text(
                'Tanggal: ${DateFormat('dd MMMM yyyy').format(DateTime.now())}',
                style: pw.TextStyle(fontSize: 12),
              ),
              pw.SizedBox(height: 20),

              // Tabel Transaksi
              pw.Table(
                border: pw.TableBorder.all(),
                children: [
                  pw.TableRow(
                    decoration: const pw.BoxDecoration(color: PdfColors.grey300),
                    children: [
                      _buildTableCell('No', isHeader: true),
                      _buildTableCell('Anggota', isHeader: true),
                      _buildTableCell('Buku', isHeader: true),
                      _buildTableCell('Pinjam', isHeader: true),
                      _buildTableCell('Kembali', isHeader: true),
                      _buildTableCell('Status', isHeader: true),
                      _buildTableCell('Denda', isHeader: true),
                    ],
                  ),
                  ...transactions.asMap().entries.map((entry) {
                    final index = entry.key;
                    final t = entry.value;
                    final tanggalPinjam = DateTime.parse(t['tanggal_pinjam'] as String);
                    final tanggalKembali = t['tanggal_kembali'] != null
                        ? DateTime.parse(t['tanggal_kembali'] as String)
                        : null;
                    return pw.TableRow(
                      children: [
                        _buildTableCell('${index + 1}'),
                        _buildTableCell('${t['member_nama']}\n(${t['member_nis']})'),
                        _buildTableCell(t['book_judul'] as String),
                        _buildTableCell(DateFormat('dd/MM/yy').format(tanggalPinjam)),
                        _buildTableCell(tanggalKembali != null
                                ? DateFormat('dd/MM/yy').format(tanggalKembali) : '-'),
                        _buildTableCell(t['status'] as String),
                        _buildTableCell(t['denda'] != null && t['denda'] > 0
                                ? 'Rp ${t['denda']}' : '-'),
                      ],
                    );
                  }),
                ],
              ),
              pw.SizedBox(height: 20),
              pw.Text(
                'Total Transaksi: ${transactions.length}',
                style: pw.TextStyle(fontWeight: pw.FontWeight.bold),
              ),
            ];
          },
        ),
      );

      await Printing.layoutPdf(
        onLayout: (PdfPageFormat format) async => pdf.save(),
      );
    } catch (e) {
      if (context.mounted) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text('Error: $e')));
      }
    }
  }

  // --------------------------------------------------------------------------
  // HELPER - Build Table Cell
  // --------------------------------------------------------------------------
  // Fungsi pembantu agar kode tabel lebih rapi
  static pw.Widget _buildTableCell(String text, {bool isHeader = false}) {
    return pw.Padding(
      padding: const pw.EdgeInsets.all(6),
      child: pw.Text(
        text,
        style: pw.TextStyle(
          fontSize: 10,
          fontWeight: isHeader ? pw.FontWeight.bold : pw.FontWeight.normal,
        ),
      ),
    );
  }
}

