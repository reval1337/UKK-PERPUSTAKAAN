// ============================================================================
// IMPORTS - Package yang dibutuhkan untuk autentikasi
// ============================================================================
import 'package:firebase_auth/firebase_auth.dart' as fb_auth; // Firebase Auth untuk login/register
import 'package:cloud_firestore/cloud_firestore.dart';          // Firestore untuk simpan data user tambahan
import 'package:shared_preferences/shared_preferences.dart';     // SharedPreferences untuk simpan session lokal
import '../models/user.dart';                                   // Model User aplikasi

// ============================================================================
// CLASS AUTHSERVICE - Service untuk menangani Autentikasi
// ============================================================================
// Service ini menggunakan pola Singleton (hanya ada satu instance di aplikasi)
// Tanggung jawab: Login, Logout, Cek status login, dan Registrasi user baru.

class AuthService {
  // Singleton pattern: instance tunggal yang bisa diakses dari mana saja
  static final AuthService instance = AuthService._init();
  AuthService._init();

  // Instance Firebase Auth dan Firestore
  final fb_auth.FirebaseAuth _auth = fb_auth.FirebaseAuth.instance;
  final FirebaseFirestore _db = FirebaseFirestore.instance;
  
  // Variabel untuk menyimpan data user yang sedang login
  User? _currentUser;

  // Getter untuk mengambil data user saat ini
  User? get currentUser => _currentUser;

  // --------------------------------------------------------------------------
  // LOGIN - Fungsi untuk masuk ke aplikasi
  // --------------------------------------------------------------------------
  Future<bool> login(String username, String password) async {
    try {
      print('🔐 DEBUG: Attempting login with email: $username');

      // 1. Coba login ke Firebase Auth menggunakan email & password
      print('🔐 DEBUG: Step 1 - Firebase Auth signInWithEmailAndPassword...');
      final cred = await _auth.signInWithEmailAndPassword(
        email: username.trim(),
        password: password,
      );
      print('🔐 DEBUG: Step 1 SUCCESS - Firebase Auth done');

      final fb_auth.User? fbUser = cred.user;

      if (fbUser != null) {
        print('🔐 DEBUG: Step 2 - Getting Firestore user doc: users/${fbUser.uid}');
        
        // 2. Jika berhasil, ambil data detail user dari Firestore 'users' collection
        final userRef = _db.collection('users').doc(fbUser.uid);
        print('🔐 DEBUG: Step 2a - Calling userRef.get()...');
        final doc = await userRef.get();
        print('🔐 DEBUG: Step 2b - userRef.get() completed, exists: ${doc.exists}');

        if (doc.exists) {
          final data = doc.data()!;
          print('🔐 DEBUG: Step 2c - Document data keys: ${data.keys.toList()}');
          
          // Support kedua format field name: 'memberId' atau 'member_id'
          final memberIdFromDoc = data['memberId']?.toString() ?? data['member_id']?.toString();
          
          // 3. Masukkan data dari Firestore ke dalam Model User kita
          _currentUser = User(
            id: fbUser.uid,
            username: data['username'] ?? fbUser.email ?? username,
            password: '',
            role: data['role'] ?? 'user',
            memberId: memberIdFromDoc,
            bio: data['bio'] as String?,
            photoUrl: data['photo_url'] as String?,
          );

          // 4. Simpan session ke SharedPreferences agar user tetap login saat app ditutup
          final prefs = await SharedPreferences.getInstance();
          await prefs.setString('username', _currentUser!.username);
          await prefs.setString('role', _currentUser!.role);
          await prefs.setString('uid', fbUser.uid);
          if (_currentUser!.memberId != null) {
            await prefs.setString('memberId', _currentUser!.memberId!);
          }
           
          print('🔐 DEBUG: ✅ Login SUCCESS for user: ${_currentUser?.username}');
          return true; // Login Berhasil
        } else {
          print('❌ DEBUG: User document NOT found in Firestore');
          return false;
        }
      }
      return false;
    } on fb_auth.FirebaseAuthException catch (e) {
      // Tangani error spesifik dari Firebase Auth
      print('❌ DEBUG: Firebase Auth Error: ${e.code} - ${e.message}');
      return false;
    } catch (e, stack) {
      print('❌ DEBUG: Unexpected error: $e');
      print('❌ DEBUG: Stack trace: $stack');
      return false;
    }
  }

  // --------------------------------------------------------------------------
  // LOGOUT - Fungsi untuk keluar dari aplikasi
  // --------------------------------------------------------------------------
  Future<void> logout() async {
    _currentUser = null;
    // 1. Sign out dari Firebase Auth
    await _auth.signOut();
    // 2. Hapus semua data session di SharedPreferences
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('username');
    await prefs.remove('role');
    await prefs.remove('uid');
    await prefs.remove('memberId');
    
  }

  // --------------------------------------------------------------------------
  // IS LOGGED IN - Cek apakah user sudah login atau belum
  // --------------------------------------------------------------------------
  Future<bool> isLoggedIn() async {
    // 1. Cek currentUser di Firebase Auth
    final fb_auth.User? fbUser = _auth.currentUser;
    if (fbUser != null) {
      // 2. Jika ada, ambil datanya dari Firestore untuk inisialisasi state
      final doc = await _db.collection('users').doc(fbUser.uid).get();
      if (doc.exists) {
        final data = doc.data()!;
        _currentUser = User(
          id: fbUser.uid,
          username: data['username'] ?? fbUser.email ?? '',
          password: '',
          role: data['role'] ?? 'user',
          memberId: data['memberId']?.toString(),
          bio: data['bio'] as String?,
          photoUrl: data['photo_url'] as String?,
        );
        return true;
      }
    }
    
    // 3. Fallback: Cek SharedPreferences jika Firebase Auth session tidak tersedia
    final prefs = await SharedPreferences.getInstance();
    final username = prefs.getString('username');
    return username != null;
  }

  // --------------------------------------------------------------------------
  // GET CURRENT USER - Ambil data user yang sedang login
  // --------------------------------------------------------------------------
  Future<User?> getCurrentUser() async {
    // 1. Jika sudah ada di memory, langsung kembalikan
    if (_currentUser != null) return _currentUser;
    
    // 2. Jika tidak ada, coba ambil dari Firebase Auth + Firestore
    final fb_auth.User? fbUser = _auth.currentUser;
    if (fbUser != null) {
      final doc = await _db.collection('users').doc(fbUser.uid).get();
      if (doc.exists) {
        final data = doc.data()!;
        _currentUser = User(
          id: fbUser.uid,
          username: data['username'] ?? fbUser.email ?? '',
          password: '',
          role: data['role'] ?? 'user',
          memberId: data['memberId']?.toString(),
          bio: data['bio'] as String?,
          photoUrl: data['photo_url'] as String?,
        );
        return _currentUser;
      }
    }
    
    // 3. Jika gagal juga, coba ambil data dasar dari SharedPreferences
    final prefs = await SharedPreferences.getInstance();
    final username = prefs.getString('username');
    if (username != null) {
      final role = prefs.getString('role') ?? 'user';
      final memberId = prefs.getString('memberId');
      final uid = prefs.getString('uid');
      _currentUser = User(
        id: uid,
        username: username,
        password: '',
        role: role,
        memberId: memberId,
        bio: null,
        photoUrl: null,
      );
      return _currentUser;
    }
    return null;
  }

  // --------------------------------------------------------------------------
  // REGISTER USER - Admin mendaftarkan user baru
  // --------------------------------------------------------------------------
  // Fungsi ini dipanggil oleh Admin untuk membuat akun Siswa/Petugas baru
  Future<bool> registerUser({
    required String email,
    required String password,
    required String role,
    String? memberId,
  }) async {
    try {
      print('DEBUG: Registering user: $email with role: $role');

      // 1. Buat akun di Firebase Auth (Autentikasi)
      final cred = await _auth.createUserWithEmailAndPassword(
        email: email,
        password: password,
      );

      final fb_auth.User? fbUser = cred.user;
      if (fbUser != null) {
        // 2. Simpan profil tambahan user ke Firestore 'users' collection
        await _db.collection('users').doc(fbUser.uid).set({
          'username': email,
          'role': role,
          'memberId': memberId,
          'bio': null,
          'photo_url': null,
          'created_at': FieldValue.serverTimestamp(),
        });
        print('DEBUG: User registered successfully');
        return true;
      }
    } on fb_auth.FirebaseAuthException catch (e) {
      print('DEBUG: Firebase Auth Error - ${e.code}: ${e.message}');
      return false;
    } catch (e) {
      print('DEBUG: Unexpected error: $e');
      return false;
    }
    return false;
  }
}

