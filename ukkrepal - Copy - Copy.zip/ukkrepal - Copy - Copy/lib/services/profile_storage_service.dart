// ============================================================================
// IMPORTS - Package untuk pengelolaan file dan Firebase Storage
// ============================================================================
import 'dart:io';                                      // Library untuk menangani file sistem
import 'package:firebase_storage/firebase_storage.dart';  // Library untuk Firebase Storage
import 'package:image_picker/image_picker.dart';         // Library untuk mengambil foto dari galeri/kamera

// ============================================================================
// CLASS PROFILESTORAGESERVICE - Service untuk mengelola foto profil
// ============================================================================
// Service ini menangani:
// 1. Upload foto profil ke Cloud Storage
// 2. Update foto profil (hapus yang lama, upload yang baru)
// 3. Delete foto profil
// 4. Resize gambar otomatis sebelum upload

class ProfileStorageService {
  // Singleton pattern
  static final ProfileStorageService instance = ProfileStorageService._init();
  ProfileStorageService._init();

  // Instance Firebase Storage
  final FirebaseStorage _storage = FirebaseStorage.instance;

  // --------------------------------------------------------------------------
  // UPLOAD PROFILE PHOTO - Upload file foto mentah
  // --------------------------------------------------------------------------
  Future<String> uploadProfilePhoto({
    required String userId,
    required File imageFile,
  }) async {
    try {
      // 1. Buat reference folder di storage: profile_photos/
      final storageRef = _storage.ref().child('profile_photos');

      // 2. Buat nama file unik: [userId]_[timestamp].jpg
      final fileName = '${userId}_${DateTime.now().millisecondsSinceEpoch}.jpg';
      final profilePhotoRef = storageRef.child(fileName);

      // 3. Jalankan proses upload
      final uploadTask = await profilePhotoRef.putFile(
        imageFile,
        SettableMetadata(
          contentType: 'image/jpeg', // Format gambar
          customMetadata: {
            'uploadedBy': userId,
            'uploadedAt': DateTime.now().toIso8601String(),
          },
        ),
      );

      // 4. Jika berhasil, ambil URL publik gambar tersebut
      if (uploadTask.state == TaskState.success) {
        final downloadUrl = await profilePhotoRef.getDownloadURL();
        return downloadUrl;
      } else {
        throw Exception('Upload gagal: ${uploadTask.state}');
      }
    } on FirebaseException catch (e) {
      throw Exception('Firebase Storage Error: ${e.message}');
    } catch (e) {
      throw Exception('Upload gagal: $e');
    }
  }

  // --------------------------------------------------------------------------
  // UPLOAD WITH RESIZE - Ambil gambar dari galeri + Resize otomatis
  // --------------------------------------------------------------------------
  Future<String> uploadProfilePhotoWithResize({
    required String userId,
    required String imagePath,
    int maxWidth = 512,  // Lebar maksimal 512px (biar hemat storage)
    int maxHeight = 512, // Tinggi maksimal 512px
    int quality = 75,    // Kualitas JPEG 75%
  }) async {
    final picker = ImagePicker();
    
    // ImagePicker akan melakukan resize & compress secara otomatis sesuai parameter
    final image = await picker.pickImage(
      source: ImageSource.gallery,
      maxWidth: maxWidth.toDouble(),
      maxHeight: maxHeight.toDouble(),
      imageQuality: quality,
    );

    if (image == null) {
      throw Exception('Tidak ada gambar yang dipilih');
    }

    // Lanjutkan ke proses upload file hasil resize
    return uploadProfilePhoto(
      userId: userId,
      imageFile: File(image.path),
    );
  }

  // --------------------------------------------------------------------------
  // DELETE PROFILE PHOTO - Menghapus foto dari storage
  // --------------------------------------------------------------------------
  Future<bool> deleteProfilePhoto({required String photoUrl}) async {
    try {
      // Ambil reference berdasarkan URL url yang ada
      final storageRef = _storage.refFromURL(photoUrl);
      await storageRef.delete();
      return true;
    } catch (e) {
      return false; // Anggap gagal jika terjadi error (misal file sudah tidak ada)
    }
  }

  // --------------------------------------------------------------------------
  // UPDATE PROFILE PHOTO - Mengganti foto lama dengan yang baru
  // --------------------------------------------------------------------------
  Future<String> updateProfilePhoto({
    required String userId,
    required File newImageFile,
    String? oldPhotoUrl,
  }) async {
    try {
      // 1. Jika user sudah punya foto lama, hapus dulu biar storage tidak penuh
      if (oldPhotoUrl != null && oldPhotoUrl.isNotEmpty) {
        await deleteProfilePhoto(photoUrl: oldPhotoUrl);
      }

      // 2. Upload foto yang baru
      final newPhotoUrl = await uploadProfilePhoto(
        userId: userId,
        imageFile: newImageFile,
      );

      return newPhotoUrl;
    } catch (e) {
      throw Exception('Gagal update foto profil: $e');
    }
  }

  // --------------------------------------------------------------------------
  // GET PROFILE PHOTO URL - Mencari foto user berdasarkan Pola Nama
  // --------------------------------------------------------------------------
  Future<String?> getProfilePhotoUrl({
    required String userId,
    int? timestamp,
  }) async {
    try {
      final storageRef = _storage.ref().child('profile_photos');
      
      // List semua file di folder profile_photos
      final ListResult result = await storageRef.listAll();
      
      // Cari file yang depannya dimulai dengan userId
      for (final ref in result.items) {
        if (ref.name.startsWith('${userId}_')) {
          return await ref.getDownloadURL();
        }
      }
      
      return null; // Tidak ditemukan foto
    } catch (e) {
      return null;
    }
  }

  // --------------------------------------------------------------------------
  // HAS PROFILE PHOTO - Cek apakah user punya foto profil
  // --------------------------------------------------------------------------
  Future<bool> hasProfilePhoto({required String userId}) async {
    final url = await getProfilePhotoUrl(userId: userId);
    return url != null;
  }
}

