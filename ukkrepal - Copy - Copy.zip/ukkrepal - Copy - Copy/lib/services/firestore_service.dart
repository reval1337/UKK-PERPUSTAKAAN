// ============================================================================
// IMPORTS - Package dan Model yang dibutuhkan
// ============================================================================
import 'package:cloud_firestore/cloud_firestore.dart'; // Package utama Firestore
import '../models/book.dart';                          // Model data Buku
import '../models/member.dart';                        // Model data Anggota/Member

// ============================================================================
// CLASS FIRESTOREBOOK - Wrapper untuk Buku dari Firestore
// ============================================================================
// Digunakan karena Firestore memiliki ID Document yang terpisah dari data objeknya
class FirestoreBook {
  final String docId; // ID dokumen unik dari Firestore
  final Book book;    // Objek data Buku

  FirestoreBook({required this.docId, required this.book});
}

// ============================================================================
// CLASS FIRESTORESERVICE - Service untuk manajemen Database Firestore
// ============================================================================
// Service ini menangani semua operasi CRUD (Create, Read, Update, Delete)
// untuk Buku, Anggota, Transaksi, dan User.

class FirestoreService {
  // Instance Firestore
  final FirebaseFirestore _db = FirebaseFirestore.instance;

  // Singleton pattern
  static final FirestoreService instance = FirestoreService._init();
  FirestoreService._init();

  // --------------------------------------------------------------------------
  // GETTERS - Shortcut untuk akses koleksi Firestore
  // --------------------------------------------------------------------------
  CollectionReference get _booksCollection => _db.collection('books');
  CollectionReference get _membersCollection => _db.collection('members');
  CollectionReference get _transactionsCollection => _db.collection('transactions');

  // ==========================================================================
  // MANAJEMEN BUKU (BOOKS)
  // ==========================================================================

  // --------------------------------------------------------------------------
  // ADD BOOK - Menambah buku baru ke Firestore
  // --------------------------------------------------------------------------
  Future<String> addBook(Book book) async {
    final data = {
      'judul': book.judul,
      'pengarang': book.pengarang,
      'penerbit': book.penerbit,
      'tahun_terbit': book.tahunTerbit,
      'stok': book.stok,
      'kategori': book.kategori,
      'deskripsi': book.deskripsi,
      'created_at': FieldValue.serverTimestamp(), // Timestamp server
    };
    final docRef = await _booksCollection.add(data);
    return docRef.id;
  }

  // --------------------------------------------------------------------------
  // GET ALL BOOKS - Mengambil semua buku (Sekali ambil)
  // --------------------------------------------------------------------------
  Future<List<FirestoreBook>> getAllBooks() async {
    final snapshot = await _booksCollection.orderBy('judul').get();
    return snapshot.docs.map((doc) {
      final data = doc.data() as Map<String, dynamic>;
      final book = Book(
        id: null,
        judul: data['judul'] ?? '',
        pengarang: data['pengarang'] ?? '',
        penerbit: data['penerbit'] ?? '',
        tahunTerbit: (data['tahun_terbit'] is int)
            ? data['tahun_terbit'] as int
            : int.tryParse('${data['tahun_terbit']}') ?? 0,
        stok: (data['stok'] is int)
            ? data['stok'] as int
            : int.tryParse('${data['stok']}') ?? 0,
        kategori: data['kategori'] ?? '',
        deskripsi: data['deskripsi'] as String?,
      );
      return FirestoreBook(docId: doc.id, book: book);
    }).toList();
  }

  // --------------------------------------------------------------------------
  // STREAM BOOKS - Mengambil buku secara Real-time
  // --------------------------------------------------------------------------
  // UI akan otomatis update jika ada perubahan data di database
  Stream<List<FirestoreBook>> streamBooks() {
    return _booksCollection.orderBy('judul').snapshots().map((snapshot) {
      return snapshot.docs.map((doc) {
        final data = doc.data() as Map<String, dynamic>;
        final book = Book(
          id: null,
          judul: data['judul'] ?? '',
          pengarang: data['pengarang'] ?? '',
          penerbit: data['penerbit'] ?? '',
          tahunTerbit: (data['tahun_terbit'] is int)
              ? data['tahun_terbit'] as int
              : int.tryParse('${data['tahun_terbit']}') ?? 0,
          stok: (data['stok'] is int)
              ? data['stok'] as int
              : int.tryParse('${data['stok']}') ?? 0,
          kategori: data['kategori'] ?? '',
          deskripsi: data['deskripsi'] as String?,
        );
        return FirestoreBook(docId: doc.id, book: book);
      }).toList();
    });
  }

  // --------------------------------------------------------------------------
  // UPDATE BOOK - Mengupdate data buku berdasarkan Doc ID
  // --------------------------------------------------------------------------
  Future<void> updateBook(String docId, Book book) async {
    final data = {
      'judul': book.judul,
      'pengarang': book.pengarang,
      'penerbit': book.penerbit,
      'tahun_terbit': book.tahunTerbit,
      'stok': book.stok,
      'kategori': book.kategori,
      'deskripsi': book.deskripsi,
      'updated_at': FieldValue.serverTimestamp(),
    };
    await _booksCollection.doc(docId).update(data);
  }

  // --------------------------------------------------------------------------
  // DELETE BOOK - Menghapus buku
  // --------------------------------------------------------------------------
  Future<void> deleteBook(String docId) async {
    await _booksCollection.doc(docId).delete();
  }

  // ==========================================================================
  // MANAJEMEN ANGGOTA (MEMBERS)
  // ==========================================================================

  // --------------------------------------------------------------------------
  // ADD MEMBER - Menambah anggota baru
  // --------------------------------------------------------------------------
  Future<String> addMember(Member member) async {
    final data = {
      'nama': member.nama,
      'nis': member.nis,
      'kelas': member.kelas,
      'alamat': member.alamat,
      'no_telp': member.noTelp,
      'tanggal_daftar': member.tanggalDaftar.toIso8601String(),
      'created_at': FieldValue.serverTimestamp(),
    };
    final docRef = await _membersCollection.add(data);
    return docRef.id;
  }

  // --------------------------------------------------------------------------
  // STREAM MEMBERS - List anggota real-time
  // --------------------------------------------------------------------------
  Stream<List<Map<String, dynamic>>> streamMembers() {
    return _membersCollection.orderBy('nama').snapshots().map((snap) {
      return snap.docs.map((d) {
        final data = d.data() as Map<String, dynamic>;
        data['docId'] = d.id;
        return data;
      }).toList();
    });
  }

  // --------------------------------------------------------------------------
  // GET ALL MEMBERS - Ambil list anggota
  // --------------------------------------------------------------------------
  Future<List<Map<String, dynamic>>> getAllMembers() async {
    final snap = await _membersCollection.orderBy('nama').get();
    return snap.docs.map((d) {
      final data = d.data() as Map<String, dynamic>;
      data['docId'] = d.id;
      return data;
    }).toList();
  }

  // --------------------------------------------------------------------------
  // GET MEMBER BY DOC ID - Ambil data satu anggota
  // --------------------------------------------------------------------------
  Future<Map<String, dynamic>?> getMemberByDocId(String docId) async {
    final d = await _membersCollection.doc(docId).get();
    if (!d.exists) return null;
    final data = d.data() as Map<String, dynamic>;
    data['docId'] = d.id;
    return data;
  }

  // --------------------------------------------------------------------------
  // GET TRANSACTIONS BY MEMBER - Riwayat pinjam anggota tertentu
  // --------------------------------------------------------------------------
  Future<List<Map<String, dynamic>>> getTransactionsByMember(
    String memberDocId,
  ) async {
    if (memberDocId.isEmpty) return [];
    
    try {
      final snap = await _transactionsCollection
          .where('member_id', isEqualTo: memberDocId)
          .get();
      final results = <Map<String, dynamic>>[];
      for (final d in snap.docs) {
        final data = d.data() as Map<String, dynamic>;
        data['docId'] = d.id;
        
        // Ambil info pendukung: Nama Member & Judul Buku
        try {
          final memberDoc = await _membersCollection.doc(memberDocId).get();
          if (memberDoc.exists) {
            final memberData = memberDoc.data() as Map<String, dynamic>?;
            data['member_nama'] = memberData?['nama'] ?? '';
            data['member_nis'] = memberData?['nis'] ?? '';
          }
        } catch (e) {}
        
        try {
          final bookDoc = await _booksCollection
              .doc(data['book_id'] as String?)
              .get();
          if (bookDoc.exists) {
            final bookData = bookDoc.data() as Map<String, dynamic>?;
            data['book_judul'] = bookData?['judul'] ?? '';
            data['book_pengarang'] = bookData?['pengarang'] ?? '';
          }
        } catch (e) {}
        
        results.add(data);
      }
      return results;
    } catch (e) {
      return [];
    }
  }

  // --------------------------------------------------------------------------
  // UPDATE MEMBER - Update data anggota
  // --------------------------------------------------------------------------
  Future<void> updateMember(String docId, Member member) async {
    final data = {
      'nama': member.nama,
      'nis': member.nis,
      'kelas': member.kelas,
      'alamat': member.alamat,
      'no_telp': member.noTelp,
      'tanggal_daftar': member.tanggalDaftar.toIso8601String(),
      'updated_at': FieldValue.serverTimestamp(),
    };
    await _membersCollection.doc(docId).update(data);
  }

  // --------------------------------------------------------------------------
  // DELETE MEMBER - Hapus anggota
  // --------------------------------------------------------------------------
  Future<void> deleteMember(String docId) async {
    await _membersCollection.doc(docId).delete();
  }

  // ==========================================================================
  // MANAJEMEN TRANSAKSI (PINJAM/KEMBALI)
  // ==========================================================================

  // --------------------------------------------------------------------------
  // STREAM TRANSACTIONS - Riwayat transaksi real-time
  // --------------------------------------------------------------------------
  Stream<List<Map<String, dynamic>>> streamTransactions() {
    return _transactionsCollection
        .orderBy('tanggal_pinjam', descending: true)
        .snapshots()
        .map((snap) {
          return snap.docs.map((d) {
            final data = d.data() as Map<String, dynamic>;
            data['docId'] = d.id;
            return data;
          }).toList();
        });
  }

  // --------------------------------------------------------------------------
  // BORROW BOOK - Proses Peminjaman Buku
  // --------------------------------------------------------------------------
  // Menggunakan Firestore.runTransaction untuk memastikan:
  // 1. Stok buku dikurang 1
  // 2. Data transaksi dibuat
  // Semua terjadi sekaligus, jika salah satu gagal, semuanya batal (Atomic)
  Future<String> borrowBook({
    required String memberDocId,
    required String bookDocId,
    required DateTime tanggalPinjam,
    required DateTime tanggalJatuhTempo,
    required int durationDays,
  }) async {
    final bookRef = _booksCollection.doc(bookDocId);
    final txRef = _transactionsCollection.doc();

    await _db.runTransaction((transaction) async {
      // 1. Cek stok buku terbaru
      final bookSnap = await transaction.get(bookRef);
      if (!bookSnap.exists) throw Exception('Buku tidak ditemukan');
      final bookData = bookSnap.data() as Map<String, dynamic>;
      final stok = (bookData['stok'] is int)
          ? bookData['stok'] as int
          : int.tryParse('${bookData['stok']}') ?? 0;
      
      if (stok <= 0) throw Exception('Stok buku tidak mencukupi');
      
      // 2. Update stok buku (kurang 1)
      transaction.update(bookRef, {'stok': stok - 1});

      // 3. Simpan data transaksi
      final trxData = {
        'member_id': memberDocId,
        'book_id': bookDocId,
        'tanggal_pinjam': tanggalPinjam.toIso8601String(),
        'tanggal_jatuh_tempo': tanggalJatuhTempo.toIso8601String(),
        'tanggal_kembali': null,
        'status': 'dipinjam',
        'duration_days': durationDays,
        'denda': 0,
        'created_at': FieldValue.serverTimestamp(),
      };
      transaction.set(txRef, trxData);
    });
    return txRef.id;
  }

  // --------------------------------------------------------------------------
  // RETURN BOOK - Proses Pengembalian Buku
  // --------------------------------------------------------------------------
  // Menggunakan Transaction untuk:
  // 1. Stok buku ditambah 1
  // 2. Update status & hitung denda
  Future<void> returnBook({
    required String transactionDocId,
    required DateTime tanggalKembali,
  }) async {
    final trxRef = _transactionsCollection.doc(transactionDocId);
    await _db.runTransaction((transaction) async {
      // 1. Ambil data transaksi
      final trxSnap = await transaction.get(trxRef);
      if (!trxSnap.exists) throw Exception('Transaksi tidak ditemukan');
      final trxData = trxSnap.data() as Map<String, dynamic>;
      if (trxData['status'] != 'dipinjam') return;

      // 2. Tambah kembali stok buku
      final bookRef = _booksCollection.doc(trxData['book_id'] as String);
      final bookSnap = await transaction.get(bookRef);
      if (bookSnap.exists) {
        final bookData = bookSnap.data() as Map<String, dynamic>;
        final stok = (bookData['stok'] is int)
            ? bookData['stok'] as int
            : int.tryParse('${bookData['stok']}') ?? 0;
        transaction.update(bookRef, {'stok': stok + 1});
      }

      // 3. Hitung Denda (Aturan: Rp 1.000 per hari keterlambatan)
      final tanggalJatuhTempo = DateTime.parse(trxData['tanggal_jatuh_tempo'] as String);
      int denda = 0;
      if (tanggalKembali.isAfter(tanggalJatuhTempo)) {
        final daysLate = tanggalKembali.difference(tanggalJatuhTempo).inDays;
        if (daysLate > 0) denda = daysLate * 1000;
      }

      // 4. Update data transaksi
      transaction.update(trxRef, {
        'tanggal_kembali': tanggalKembali.toIso8601String(),
        'status': 'dikembalikan',
        'denda': denda,
        'updated_at': FieldValue.serverTimestamp(),
      });
    });
  }

  // --------------------------------------------------------------------------
  // GET TRANSACTIONS WITH DETAILS - Riwayat lengkap dengan info buku & member
  // --------------------------------------------------------------------------
  Future<List<Map<String, dynamic>>> getTransactionsWithDetails() async {
    try {
      final snap = await _transactionsCollection
          .orderBy('tanggal_pinjam', descending: true)
          .get();
      final results = <Map<String, dynamic>>[];
      for (final doc in snap.docs) {
        final data = doc.data() as Map<String, dynamic>;
        data['docId'] = doc.id;
        
        // Fetch info anggota
        try {
          final memberDoc = await _membersCollection
              .doc(data['member_id'] as String?)
              .get();
          if (memberDoc.exists) {
            final memberData = memberDoc.data() as Map<String, dynamic>?;
            data['member_nama'] = memberData?['nama'] ?? '';
            data['member_nis'] = memberData?['nis'] ?? '';
          }
        } catch (e) {}
        
        // Fetch info buku
        try {
          final bookDoc = await _booksCollection
              .doc(data['book_id'] as String?)
              .get();
          if (bookDoc.exists) {
            final bookData = bookDoc.data() as Map<String, dynamic>?;
            data['book_judul'] = bookData?['judul'] ?? '';
            data['book_pengarang'] = bookData?['pengarang'] ?? '';
          }
        } catch (e) {}
        
        results.add(data);
      }
      return results;
    } catch (e) {
      return [];
    }
  }

  // ====================================================================
  // MANAJEMEN USER (Auth Data)
  // ====================================================================

  // --------------------------------------------------------------------------
  // UPDATE USER - Update profil user (Bio, Foto, dll)
  // --------------------------------------------------------------------------
  Future<void> updateUser(String userId, Map<String, dynamic> data) async {
    data['updated_at'] = FieldValue.serverTimestamp();
    await _db.collection('users').doc(userId).update(data);
  }
}

