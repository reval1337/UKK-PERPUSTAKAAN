# Entity Relationship Diagram (ERD) - Firestore NoSQL

## Sistem Perpustakaan UKKREPAL (Firebase Cloud Firestore)

---

## 1. Firestore Collection Structure

Firestore menggunakan **Collections** dan **Documents** (bukan tabel SQL). Setiap document memiliki **unique ID** dan dapat berisi **sub-collections**.

```
Firestore Database
│
├── users/ (Collection)
│   └── {userId} (Document)
│       ├── email
│       ├── role
│       ├── memberId
│       ├── name
│       └── timestamps
│
├── members/ (Collection)
│   └── {memberId} (Document)
│       ├── nama
│       ├── nis
│       ├── kelas
│       ├── alamat
│       ├── noTelp
│       ├── tanggalDaftar
│       └── statusAktif
│
├── books/ (Collection)
│   └── {bookId} (Document)
│       ├── judul
│       ├── pengarang
│       ├── penerbit
│       ├── tahunTerbit
│       ├── isbn
│       ├── kategori
│       ├── deskripsi
│       ├── stok
│       ├── stokTersedia
│       ├── coverUrl
│       └── timestamps
│
└── transactions/ (Collection)
    └── {transactionId} (Document)
        ├── userId
        ├── memberId
        ├── memberName
        ├── bookId
        ├── bookTitle
        ├── borrowDate
        ├── dueDate
        ├── returnDate
        ├── status
        ├── durationDays
        ├── fine
        ├── daysLate
        └── timestamps
```

---

## 2. Document Relationships (References)

### users → members (One-to-One)
```
users/
  └── {userId}/
        └── memberId: "member_abc123" ────────┐
                                               │
members/                                        │
  └── {memberId}/ ◄────────────────────────────┘
        └── nama: "John Doe"
```

**Catatan:**
- Untuk Admin: `memberId` = **null**
- Untuk User: `memberId` = reference ke document di `members/`

### members → transactions (One-to-Many)
```
members/
  └── {memberId}/ ◄────────────────────────┐
        │                                 │
        │ transactions/                   │
        │   └── {transactionId}/         │
        │         ├── memberId: ref ─────┘
        │         └── ...
        │
transactions/
  └── {transactionId}/
        └── memberId: "member_abc123" ────────┐
                                               │
members/                                        │
  └── {memberId}/ ◄────────────────────────────┘
        └── nama: "John Doe"
```

### books → transactions (One-to-Many)
```
books/
  └── {bookId}/ ◄─────────────────────────┐
        │                                 │
        │ transactions/                   │
        │   └── {transactionId}/         │
        │         ├── bookId: ref ───────┘
        │         └── ...
        │
transactions/
  └── {transactionId}/
        └── bookId: "book_xyz789" ────────────┐
                                               │
books/                                         │
  └── {bookId}/ ◄─────────────────────────────┘
        └── judul: "Flutter Basics"
```

---

## 3. Complete Relationship Diagram

```
users ◄──────────────────┐
  │ (memberId)           │
  │                     │
  │                     ▼
members ◄──────────── transactions ──────► books
  │ (id)     (memberId)      (bookId)      (id)
  │    │                      │
  │    │                      │
  │    └──────────────────────┘
  │
  └── (One user can have one member record)
```

### Legend:
- `◄──` = Reference ke document lain
- `──►` = Document yang direference
- `(field)` = Field yang menyimpan reference

---

## 4. Field Details

### users Collection

| Field | Type | Description | Required |
|-------|------|-------------|----------|
| `id` | string | Firebase Auth UID (document ID) | Yes |
| `email` | string | Email address | Yes |
| `role` | string | "admin" atau "user" | Yes |
| `memberId` | string | Reference ke members.id (null untuk admin) | No |
| `name` | string | Nama lengkap user | Yes |
| `createdAt` | Timestamp | Waktu pembuatan | Yes |
| `updatedAt` | Timestamp | Waktu update terakhir | Yes |

**Primary Key:** `id` (sama dengan Firebase Auth UID)

### members Collection

| Field | Type | Description | Required |
|-------|------|-------------|----------|
| `id` | string | Unique member ID (format: "member_xxx") | Yes |
| `nama` | string | Nama lengkap anggota | Yes |
| `nis` | string | Nomor Induk Siswa (unique) | Yes |
| `kelas` | string | Kelas/Sekolah | Yes |
| `alamat` | string | Alamat tinggal | Yes |
| `noTelp` | string | Nomor telepon | Yes |
| `tanggalDaftar` | Timestamp | Tanggal pendaftaran | Yes |
| `statusAktif` | boolean | Status keanggotaan | Yes |

**Primary Key:** `id` (auto-generated)

### books Collection

| Field | Type | Description | Required |
|-------|------|-------------|----------|
| `id` | string | Unique book ID (format: "book_xxx") | Yes |
| `judul` | string | Judul buku | Yes |
| `pengarang` | string | Nama pengarang | Yes |
| `penerbit` | string | Nama penerbit | Yes |
| `tahunTerbit` | int | Tahun terbit | Yes |
| `isbn` | string | ISBN (opsional) | No |
| `kategori` | string | Kategori buku | Yes |
| `deskripsi` | string | Deskripsi buku | No |
| `stok` | int | Total stok | Yes |
| `stokTersedia` | int | Stok yang tersedia | Yes |
| `coverUrl` | string | URL cover buku | No |
| `createdAt` | Timestamp | Waktu pembuatan | Yes |
| `updatedAt` | Timestamp | Waktu update terakhir | Yes |

**Primary Key:** `id` (auto-generated)

### transactions Collection

| Field | Type | Description | Required |
|-------|------|-------------|----------|
| `id` | string | Unique transaction ID (format: "trans_xxx") | Yes |
| `userId` | string | Reference ke users.id | Yes |
| `memberId` | string | Reference ke members.id | Yes |
| `memberName` | string | Nama member (denormalized) | Yes |
| `bookId` | string | Reference ke books.id | Yes |
| `bookTitle` | string | Judul buku (denormalized) | Yes |
| `borrowDate` | Timestamp | Tanggal pinjam | Yes |
| `dueDate` | Timestamp | Tanggal jatuh tempo | Yes |
| `returnDate` | Timestamp | Tanggal kembali (null jika belum) | No |
| `status` | string | "dipinjam" / "dikembalikan" / "terlambat" | Yes |
| `durationDays` | int | Durasi peminjaman (3/7/30 hari) | Yes |
| `fine` | int | Total denda (Rp) | Yes |
| `daysLate` | int | Hari keterlambatan | Yes |
| `createdAt` | Timestamp | Waktu pembuatan | Yes |
| `updatedAt` | Timestamp | Waktu update terakhir | Yes |

**Primary Key:** `id` (auto-generated)

---

## 5. Data Flow Relationships

### Login Flow (menggunakan references)
```
1. User login dengan email/password
   ↓
2. Firebase Auth verifikasi credentials
   ↓
3. Ambil user document dari users/{userId}
   ↓
4. Cek role:
   ├─> Admin → Redirect ke Admin Dashboard
   │
   └─> User → Ambil member document dari members/{memberId}
            (jika memberId tidak null)
            ↓
            Redirect ke User Dashboard
```

### Borrow Flow (denormalization untuk performance)
```
1. User pilih buku
   ↓
2. Ambil book document dari books/{bookId}
   ↓
3. Buat transaction document dengan:
   - bookId: reference ke books.id
   - bookTitle: simpan dari books.judul (denormalized)
   ↓
4. Update book.stokTersedia -= 1
   ↓
5. Transaction selesai
```

**Mengapa Denormalization?**
- Mengurangi **read operations** (tidak perlu join)
- Data lebih konsisten untuk **reporting**
- Query lebih cepat untuk **transactions collection**

---

## 6. Indexes (firestore.indexes.json)

```json
{
  "indexes": [
    {
      "collectionGroup": "transactions",
      "queryScope": "COLLECTION",
      "fields": [
        { "fieldPath": "userId", "order": "ASCENDING" },
        { "fieldPath": "status", "order": "ASCENDING" }
      ]
    },
    {
      "collectionGroup": "transactions",
      "queryScope": "COLLECTION",
      "fields": [
        { "fieldPath": "memberId", "order": "ASCENDING" },
        { "fieldPath": "borrowDate", "order": "DESCENDING" }
      ]
    },
    {
      "collectionGroup": "transactions",
      "queryScope": "COLLECTION",
      "fields": [
        { "fieldPath": "status", "order": "ASCENDING" },
        { "fieldPath": "createdAt", "order": "DESCENDING" }
      ]
    },
    {
      "collectionGroup": "books",
      "queryScope": "COLLECTION",
      "fields": [
        { "fieldPath": "kategori", "order": "ASCENDING" },
        { "fieldPath": "judul", "order": "ASCENDING" }
      ]
    },
    {
      "collectionGroup": "books",
      "queryScope": "COLLECTION",
      "fields": [
        { "fieldPath": "stokTersedia", "order": "ASCENDING" },
        { "fieldPath": "kategori", "order": "ASCENDING" }
      ]
    }
  ]
}
```

### Contoh Query yang Memerlukan Index:

```dart
// Query: Ambil transaksi aktif user tertentu
FirebaseFirestore.instance
    .collection('transactions')
    .where('userId', isEqualTo: currentUserId)
    .where('status', isEqualTo: 'dipinjam')
    .get();

// Query: Ambil transaksi berdasarkan member dan tanggal
FirebaseFirestore.instance
    .collection('transactions')
    .where('memberId', isEqualTo: memberId)
    .orderBy('borrowDate', descending: true)
    .get();

// Query: Ambil buku berdasarkan kategori
FirebaseFirestore.instance
    .collection('books')
    .where('kategori', isEqualTo: 'Teknologi')
    .orderBy('judul')
    .get();
```

---

## 7. Sample Data

### users (Collection)
```javascript
// users/admin_user
{
  "id": "admin_user_001",
  "email": "admin@ukkrepal.sch.id",
  "role": "admin",
  "memberId": null,
  "name": "Petugas Perpustakaan",
  "createdAt": Timestamp(2024, 1, 1),
  "updatedAt": Timestamp(2024, 1, 1)
}

// users/student_001
{
  "id": "student_001_abc123",
  "email": "john.doe@student.sch.id",
  "role": "user",
  "memberId": "member_001",
  "name": "John Doe",
  "createdAt": Timestamp(2024, 1, 15),
  "updatedAt": Timestamp(2024, 1, 15)
}
```

### members (Collection)
```javascript
// members/member_001
{
  "id": "member_001",
  "nama": "John Doe",
  "nis": "2023001",
  "kelas": "XII RPL 1",
  "alamat": "Jl. Sekolah No. 123, Jakarta",
  "noTelp": "081234567890",
  "tanggalDaftar": Timestamp(2024, 1, 15),
  "statusAktif": true
}

// members/member_002
{
  "id": "member_002",
  "nama": "Jane Smith",
  "nis": "2023002",
  "kelas": "XI IPA 2",
  "alamat": "Jl. Raya No. 456, Bandung",
  "noTelp": "089876543210",
  "tanggalDaftar": Timestamp(2024, 1, 20),
  "statusAktif": true
}
```

### books (Collection)
```javascript
// books/book_001
{
  "id": "book_001",
  "judul": "Pemrograman Flutter untuk Pemula",
  "pengarang": "Budi Santoso",
  "penerbit": "Media Press",
  "tahunTerbit": 2024,
  "isbn": "978-1234567890",
  "kategori": "Teknologi",
  "deskripsi": "Buku panduan lengkap Flutter untuk pemula...",
  "stok": 10,
  "stokTersedia": 7,
  "coverUrl": "https://storage.googleapis.com/ukkrepal/books/flutter.jpg",
  "createdAt": Timestamp(2024, 1, 1),
  "updatedAt": Timestamp(2024, 1, 1)
}

// books/book_002
{
  "id": "book_002",
  "judul": "Matematika untuk SMA",
  "pengarang": "Dr. Ahmad Wijaya",
  "penerbit": "Edu Press",
  "tahunTerbit": 2023,
  "isbn": "978-0987654321",
  "kategori": "Pendidikan",
  "deskripsi": "Buku referensi matematika SMA...",
  "stok": 5,
  "stokTersedia": 3,
  "coverUrl": "https://storage.googleapis.com/ukkrepal/books/math.jpg",
  "createdAt": Timestamp(2024, 1, 5),
  "updatedAt": Timestamp(2024, 1, 10)
}
```

### transactions (Collection)
```javascript
// transactions/trans_001 (Aktif)
{
  "id": "trans_001",
  "userId": "student_001_abc123",
  "memberId": "member_001",
  "memberName": "John Doe",
  "bookId": "book_001",
  "bookTitle": "Pemrograman Flutter untuk Pemula",
  "borrowDate": Timestamp(2024, 2, 1),
  "dueDate": Timestamp(2024, 2, 8),
  "returnDate": null,
  "status": "dipinjam",
  "durationDays": 7,
  "fine": 0,
  "daysLate": 0,
  "createdAt": Timestamp(2024, 2, 1),
  "updatedAt": Timestamp(2024, 2, 1)
}

// transactions/trans_002 (Dikembalikan tepat waktu)
{
  "id": "trans_002",
  "userId": "student_002_def456",
  "memberId": "member_002",
  "memberName": "Jane Smith",
  "bookId": "book_003",
  "bookTitle": "Fisika Dasar",
  "borrowDate": Timestamp(2024, 1, 20),
  "dueDate": Timestamp(2024, 1, 27),
  "returnDate": Timestamp(2024, 1, 25),
  "status": "dikembalikan",
  "durationDays": 7,
  "fine": 0,
  "daysLate": 0,
  "createdAt": Timestamp(2024, 1, 20),
  "updatedAt": Timestamp(2024, 1, 25)
}

// transactions/trans_003 (Terlambat)
{
  "id": "trans_003",
  "userId": "student_001_abc123",
  "memberId": "member_001",
  "memberName": "John Doe",
  "bookId": "book_002",
  "bookTitle": "Matematika untuk SMA",
  "borrowDate": Timestamp(2024, 1, 10),
  "dueDate": Timestamp(2024, 1, 17),
  "returnDate": Timestamp(2024, 1, 22),
  "status": "terlambat",
  "durationDays": 7,
  "fine": 5000,
  "daysLate": 5,
  "createdAt": Timestamp(2024, 1, 10),
  "updatedAt": Timestamp(2024, 1, 22)
}
```

---

## 8. Constraints & Validation

### Field Validation (Client-side)

```dart
// users validation
Map<String, dynamic> validateUser(Map<String, dynamic> data) {
  final errors = <String, String>{};
  
  if (data['email'] == null || !data['email'].contains('@')) {
    errors['email'] = 'Email tidak valid';
  }
  
  if (data['role'] != 'admin' && data['role'] != 'user') {
    errors['role'] = 'Role harus admin atau user';
  }
  
  return errors;
}

// members validation
Map<String, dynamic> validateMember(Map<String, dynamic> data) {
  final errors = <String, String>{};
  
  if (data['nis'] == null || data['nis'].length < 4) {
    errors['nis'] = 'NIS harus minimal 4 karakter';
  }
  
  if (data['noTelp'] == null || data['noTelp'].length < 10) {
    errors['noTelp'] = 'Nomor telepon tidak valid';
  }
  
  return errors;
}
```

### Firestore Security Rules Validation

```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    
    // Validate member data
    function isValidMember(data) {
      return data.nama is string
          && data.nis is string
          && data.nis.size() >= 4
          && data.kelas is string
          && data.statusAktif is bool;
    }
    
    // Validate book data
    function isValidBook(data) {
      return data.judul is string
          && data.pengarang is string
          && data.stok is int
          && data.stok >= 0
          && data.stokTersedia is int
          && data.stokTersedia >= 0;
    }
    
    // Validate transaction data
    function isValidTransaction(data) {
      return data.userId is string
          && data.bookId is string
          && data.status in ['dipinjam', 'dikembalikan', 'terlambat']
          && data.fine is int
          && data.fine >= 0;
    }
    
    match /members/{memberId} {
      allow create: if isValidMember(request.resource.data);
      allow update: if isValidMember(request.resource.data);
    }
    
    match /books/{bookId} {
      allow create: if isValidBook(request.resource.data);
      allow update: if isValidBook(request.resource.data);
    }
    
    match /transactions/{transactionId} {
      allow create: if isValidTransaction(request.resource.data);
      allow update: if isValidTransaction(request.resource.data);
    }
  }
}
```

---

## 9. Migration from SQL to Firestore

### SQL → Firestore Mapping:

| SQL Concept | Firestore Equivalent |
|-------------|---------------------|
| Table | Collection |
| Row | Document |
| Column | Field |
| Primary Key | Document ID |
| Foreign Key | Reference (document ID) |
| JOIN | Multiple queries / Denormalization |
| INDEX | Index (auto/single-field/composite) |
| TRANSACTION | Transaction (atomic operations) |

### Before (SQL):
```
SELECT * FROM transactions 
JOIN members ON transactions.member_id = members.id
JOIN books ON transactions.book_id = books.id
WHERE transactions.status = 'dipinjam';
```

### After (Firestore):
```dart
// Query transactions dengan filtering
final transactions = await FirebaseFirestore.instance
    .collection('transactions')
    .where('status', isEqualTo: 'dipinjam')
    .get();

// Jika perlu detail member/book, lakukan query terpisah
for (var doc in transactions.docs) {
  final member = await FirebaseFirestore.instance
      .collection('members')
      .doc(doc['memberId'])
      .get();
  
  final book = await FirebaseFirestore.instance
      .collection('books')
      .doc(doc['bookId'])
      .get();
  
  // Gunakan data denormalized jika tersedia
  print('Member: ${doc['memberName']}');
  print('Book: ${doc['bookTitle']}');
}
```

---

## 10. Performance Considerations

### Read Operations Optimization:
1. **Denormalize** frequently accessed data
2. **Cache** data di client
3. Use **StreamBuilder** untuk real-time updates
4. Paginate **large datasets**

### Write Operations Optimization:
1. Use **batch writes** untuk multiple operations
2. Use **transactions** untuk atomic updates
3. Limit **document size** (< 1MB)

### Query Best Practices:
```dart
// ❌ Bad: Client-side filtering
final allBooks = await FirebaseFirestore.instance.collection('books').get();
final filtered = allBooks.docs.where((doc) => doc['stokTersedia'] > 0);

// ✅ Good: Server-side filtering
final availableBooks = await FirebaseFirestore.instance
    .collection('books')
    .where('stokTersedia', isGreaterThan: 0)
    .get();
```

---

## 📚 Referensi

- [Firestore Data Model](https://firebase.google.com/docs/firestore/data-model)
- [Firestore Queries](https://firebase.google.com/docs/firestore/query-data-queries)
- [Firestore Transactions](https://firebase.google.com/docs/firestore/transaction-data)
- [Firestore Security Rules](https://firebase.google.com/docs/firestore/security/rules)
