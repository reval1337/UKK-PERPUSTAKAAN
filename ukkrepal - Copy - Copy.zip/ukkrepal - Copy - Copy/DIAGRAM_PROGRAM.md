# Arsitektur Sistem - Aplikasi Perpustakaan UKKREPAL

## 1. Arsitektur Overview

```
┌─────────────────────────────────────────────────────────────┐
│                    FRONTEND (Flutter)                        │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐         │
│  │  Admin App  │  │  User App   │  │  Shared UI  │         │
│  └─────────────┘  └─────────────┘  └─────────────┘         │
│         │                │                  │                │
│  ┌──────┴─────────┐  ┌──┴────────┐  ┌─────┴────────┐       │
│  │ Admin Screens │  │User Screens│  │PDF/Printing  │       │
│  └───────────────┘  └────────────┘  └──────────────┘       │
└───────────────────────────┬─────────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────────┐
│                    BACKEND (Firebase)                         │
│  ┌─────────────────┐  ┌─────────────────┐                    │
│  │  Firebase Auth  │  │ Cloud Firestore │                    │
│  │  (Authentication)│ │   (Database)    │                    │
│  └─────────────────┘  └─────────────────┘                    │
└─────────────────────────────────────────────────────────────┘
```

## 2. Technology Stack

| Layer | Technology | Purpose |
|-------|------------|---------|
| **Frontend** | Flutter (Dart) | Cross-platform mobile app |
| **Backend** | Firebase | Serverless backend |
| **Database** | Cloud Firestore | NoSQL document database |
| **Authentication** | Firebase Auth | User authentication |
| **PDF Generation** | pdf + printing packages | Generate receipts/reports |
| **State Management** | Provider/SetState | Local state management |

## 3. Firebase Project Configuration

### Project: ukkrepal
- **Firebase Console:** https://console.firebase.google.com/project/ukkrepal
- **Auth:** Email/Password authentication enabled
- **Firestore:** Production mode with security rules

### Required Firebase Packages (pubspec.yaml):
```yaml
dependencies:
  flutter:
    sdk: flutter
  firebase_core: ^2.24.0
  firebase_auth: ^4.16.0
  cloud_firestore: ^4.14.0
  pdf: ^3.10.0
  printing: ^5.11.0
```

## 4. Firestore Collection Structure

### Collection: `users`
```javascript
users/
  └── {userId}/
        ├── email: "admin@ukkrepal.sch.id"
        ├── role: "admin" | "user"
        ├── memberId: null | "member_abc123"  // NULL untuk admin
        ├── name: "Nama User"
        ├── createdAt: Timestamp
        └── updatedAt: Timestamp
```

### Collection: `members`
```javascript
members/
  └── {memberId}/
        ├── id: "member_abc123"
        ├── nama: "John Doe"
        ├── nis: "2023001"
        ├── kelas: "XII RPL 1"
        ├── alamat: "Jl. Sekolah No. 1"
        ├── noTelp: "081234567890"
        ├── tanggalDaftar: Timestamp
        └── statusAktif: true
```

### Collection: `books`
```javascript
books/
  └── {bookId}/
        ├── id: "book_xyz789"
        ├── judul: "Pemrograman Flutter"
        ├── pengarang: "Budi Santoso"
        ├── penerbit: "Media Press"
        ├── tahunTerbit: 2024
        ├── isbn: "978-1234567890"
        ├── kategori: "Teknologi"
        ├── deskripsi: "Buku panduan Flutter..."
        ├── stok: 5
        ├── stokTersedia: 3
        ├── coverUrl: "https://..."
        ├── createdAt: Timestamp
        └── updatedAt: Timestamp
```

### Collection: `transactions`
```javascript
transactions/
  └── {transactionId}/
        ├── id: "trans_pqr456"
        ├── userId: "user_abc123"
        ├── memberId: "member_abc123"
        ├── memberName: "John Doe"
        ├── bookId: "book_xyz789"
        ├── bookTitle: "Pemrograman Flutter"
        ├── borrowDate: Timestamp
        ├── dueDate: Timestamp
        ├── returnDate: null | Timestamp
        ├── status: "dipinjam" | "dikembalikan" | "terlambat"
        ├── durationDays: 7
        ├── fine: 0
        ├── daysLate: 0
        ├── createdAt: Timestamp
        └── updatedAt: Timestamp
```

## 5. Entity Relationship (Firestore References)

```
users ─────────────────────────────┐
  │ (memberId)                     │
  │                                ▼
members ◄──────────────────── transactions
  │ (id)           (memberId)      │
  │                                │
  │                                ▼
  └──────────────────────────► books
                                 (id)
```

### Relasi Detail:

1. **users ↔ members** (One-to-One, Optional)
   - Satu user memiliki satu member (untuk role='user')
   - Admin memiliki memberId = null
   - Reference: `users.memberId` → `members.id`

2. **members ↔ transactions** (One-to-Many)
   - Satu member dapat memiliki banyak transaksi
   - Reference: `transactions.memberId` → `members.id`

3. **books ↔ transactions** (One-to-Many)
   - Satu buku dapat dipinjam berkali-kali
   - Reference: `transactions.bookId` → `books.id`

## 6. Role-Based Access Control

### Admin (role: "admin")
- **CRUD** semua data: books, members, users, transactions
- **Melihat** semua transaksi
- **Mengembalikan** buku atas nama siswa
- **Generate** laporan PDF
- **Akses** semua menu admin

### User/Siswa (role: "user")
- **Melihat** daftar buku & status
- **Pinjam** buku (membuat transaksi)
- **Kembalikan** buku (update transaksi)
- **Melihat** riwayat pribadi
- **Generate** struk bukti pinjam/kembali
- **Tidak bisa** CRUD data master

## 7. Firestore Security Rules

```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    
    // Helper functions
    function isAdmin() {
      return request.auth != null && 
             get(/databases/$(database)/documents/users/$(request.auth.uid)).data.role == 'admin';
    }
    
    function isUser() {
      return request.auth != null && 
             get(/databases/$(database)/documents/users/$(request.auth.uid)).data.role == 'user';
    }
    
    function isOwner(userId) {
      return request.auth != null && request.auth.uid == userId;
    }
    
    // books collection
    match /books/{bookId} {
      allow read: if request.auth != null;
      allow write: if isAdmin();
    }
    
    // members collection
    match /members/{memberId} {
      allow read: if request.auth != null;
      allow write: if isAdmin();
    }
    
    // users collection
    match /users/{userId} {
      allow read: if request.auth != null;
      allow write: if isAdmin() || isOwner(userId);
    }
    
    // transactions collection
    match /transactions/{transactionId} {
      allow read: if request.auth != null;
      allow create: if isUser() && request.resource.data.userId == request.auth.uid;
      allow update: if isAdmin() || 
                    (isUser() && resource.data.userId == request.auth.uid);
      allow delete: if isAdmin();
    }
  }
}
```

## 8. Flow Peminjaman & Pengembalian

### Flow Peminjaman Buku
```
1. User Login
   │
   ├─> UserPilihBuku
   │     │
   │     ├─> Cek Stok Tersedia
   │     │     │
   │     │     ├─> Stok = 0? → Tampil Error "Buku Tidak Tersedia"
   │     │     │
   │     │     └─> Stok > 0? → Lanjut
   │     │
   │     ├─> Cek Transaksi Aktif (user sudah pinjam buku ini?)
   │     │     │
   │     │     ├─> Sudah Pinjam? → Error "Sudah Meminjam Buku Ini"
   │     │     │
   │     │     └─> Belum Pinjam? → Lanjut
   │     │
   │     └─> UserPilihDurasi
   │           │
   │           ├─> 3 hari
   │           ├─> 7 hari
   │           └─> 1 bulan
   │
   ├─> KonfirmasiPinjam
   │     │
   │     ├─> Tampil: Judul, Durasi, Tanggal Jatuh Tempo
   │     │
   │     └─> Klik "Pinjam"
   │
   ├─> ProsesPinjam (Firestore Transaction)
   │     │
   │     ├─> 1. Create Transaction
   │     │     ├── userId: auth.uid
   │     │     ├── bookId: selectedBook.id
   │     │     ├── borrowDate: now()
   │     │     ├── dueDate: now() + duration
   │     │     ├── status: "dipinjam"
   │     │     └── fine: 0
   │     │
   │     ├─> 2. Update Book Stock
   │     │     └── stokTersedia: decrement(1)
   │     │
   │     └─> 3. Commit Transaction
   │
   └─> TampilStrukBuktiPinjam (PDF)
```

### Flow Pengembalian Buku
```
1. User Login
   │
   ├─> UserPilihBukuDikembalikan
   │     │
   │     └─> Tampil Transaksi Aktif user
   │
   ├─> UserKlikBuku
   │     │
   │     ├─> Tampil Detail:
   │     │     ├── Judul Buku
   │     │     ├── Tanggal Pinjam
   │     │     ├── Tanggal Jatuh Tempo
   │     │     └── Status
   │     │
   │     └─> Klik "Kembalikan"
   │
   ├─> ProsesKembalikan (Firestore Transaction)
   │     │
   │     ├─> 1. Get Transaction
   │     │     └── Hitung Denda
   │     │           ├── today > dueDate?
   │     │           ├── daysLate = today - dueDate
   │     │           └── fine = daysLate × 1000
   │     │
   │     ├─> 2. Update Transaction
   │     │     ├── returnDate: now()
   │     │     ├── status: "dikembalikan" | "terlambat"
   │     │     ├── fine: calculatedFine
   │     │     └── daysLate: calculatedDays
   │     │
   │     ├─> 3. Update Book Stock
   │     │     └── stokTersedia: increment(1)
   │     │
   │     └─> 4. Commit Transaction
   │
   └─> TampilStrukBuktiPengembalian (PDF)
```

## 9. Perhitungan Denda Keterlambatan

### Logika Perhitungan Denda:

```dart
// Contoh implementasi di firestore_service.dart

Future<int> calculateFine(DateTime dueDate) async {
  DateTime today = DateTime.now();
  
  if (today.isBefore(dueDate) || today.isAtSameMomentAs(dueDate)) {
    return 0; // Tidak terlambat
  }
  
  // Hitung selisih hari
  int daysLate = today.difference(dueDate).inDays;
  
  // Denda: Rp 1.000 per hari
  int fine = daysLate * 1000;
  
  return fine;
}
```

### Contoh Perhitungan:

| Tanggal Pinjam | Durasi | Tanggal Jatuh Tempo | Tanggal Kembali | Hari Terlambat | Denda |
|---------------|---------|---------------------|-----------------|----------------|-------|
| 2024-01-01 | 7 hari | 2024-01-08 | 2024-01-10 | 2 hari | Rp 2.000 |
| 2024-01-01 | 3 hari | 2024-01-04 | 2024-01-15 | 11 hari | Rp 11.000 |
| 2024-01-01 | 1 bulan | 2024-02-01 | 2024-01-28 | 0 hari | Rp 0 |

### Catatan Denda:
- **Denda per hari:** Rp 1.000
- **Minimum denda:** Rp 0 (tidak ada denda jika tepat waktu)
- **Maksimum denda:** Tidak ada batas maksimum
- **Pembayaran Denda:** Diatur secara manual oleh admin

## 10. Admin Dashboard Concept

### Dashboard Stats Cards:
```
┌─────────────────────────────────────────────────────────┐
│  📚 Total Buku     │  👥 Total Anggota  │  📦 Stok Buku │
│       150         │        200         │      120      │
└─────────────────────────────────────────────────────────┘
┌─────────────────────────────────────────────────────────┐
│  📋 Dipinjam       │  📋 Dikembalikan   │  💰 Total     │
│       30          │        170         │    Denda      │
│                   │                    │   Rp 50.000   │
└─────────────────────────────────────────────────────────┘
```

### Quick Actions:
- [+] Tambah Buku
- [+] Tambah Anggota
- [📋] Lihat Semua Transaksi
- [📄] Cetak Laporan

### Recent Activity Table:
| Waktu | Aksi | Detail |
|-------|------|--------|
| 10:30 | Pinjam | John Doe - Flutter Dasar |
| 10:15 | Kembali | Jane Smith - Algoritma (+Rp 2.000) |
| 09:45 | Pinjam | Bob Wilson - Database MySQL |

### Charts/Graphs:
- **Peminjaman per Bulan** (Bar Chart)
- **Kategori Buku Terpopuler** (Pie Chart)
- **Tren Denda** (Line Chart)

## 11. UI/UX Design Concept

### Admin App UI:
```
┌─────────────────────────────────────────┐
│  📖 UKKREPAL Admin         👤 Admin v1.0│
├─────────────────────────────────────────┤
│                                         │
│  ┌───┐ ┌───┐ ┌───┐ ┌───┐              │
│  │ 📚│ │ 👥│ │ 📋│ │ 📊│              │
│  │Buku│ │Angg│ │Tran│ │Lapor│           │
│  └───┘ └───┘ └───┘ └───┘              │
│                                         │
│  ┌─────────────────────────────────┐   │
│  │ 📈 Dashboard Stats               │   │
│  │ • 150 Buku • 200 Anggota        │   │
│  │ • 30 Dipinjam • Rp 50rb Denda   │   │
│  └─────────────────────────────────┘   │
│                                         │
│  ┌─────────────────────────────────┐   │
│  │ 📋 Recent Transactions          │   │
│  │ • John Doe → Flutter Dasar      │   │
│  │ • Jane S. → Algoritma (+Rp2rb)  │   │
│  └─────────────────────────────────┘   │
│                                         │
│  [🔍 Search...]                        │
│                                         │
├─────────────────────────────────────────┤
│  🏠 Home  │  📚 Books  │  👥 Users │ ⚙️ │
└─────────────────────────────────────────┘
```

### User App UI:
```
┌─────────────────────────────────────────┐
│  📖 UKKREPAL              👤 John Doe v1.0│
├─────────────────────────────────────────┤
│                                         │
│  ┌─────────────────────────────────┐   │
│  │ 👋 Halo, John!                  │   │
│  │ 📚 2 buku sedang dipinjam        │   │
│  └─────────────────────────────────┘   │
│                                         │
│  ┌─────────────────────────────────┐   │
│  │ 🔍 Cari Buku...                 │   │
│  └─────────────────────────────────┘   │
│                                         │
│  ┌─────┐ ┌─────┐                     │
│  │ 📥 │ │ 📤 │                     │
│  │Pinjam│ │Kembali│                    │
│  └─────┘ └─────┘                     │
│                                         │
│  ┌─────────────────────────────────┐   │
│  │ 📚 Rekomendasi Buku             │   │
│  │ • Flutter Dasar ⭐4.8           │   │
│  │ • Python untuk Pemula ⭐4.5     │   │
│  │ • Web Programming ⭐4.7         │   │
│  └─────────────────────────────────┘   │
│                                         │
│  ┌─────────────────────────────────┐   │
│  │ 📋 Riwayat Peminjaman           │   │
│  │ [Lihat Semua →]                 │   │
│  └─────────────────────────────────┘   │
│                                         │
├─────────────────────────────────────────┤
│  🏠 Home  │  📚 Books  │  📋 History │ 🚪│
└─────────────────────────────────────────┘
```

### Color Scheme:
```dart
// Tema Utama
const Color primaryColor = Color(0xFF1E88E5);      // Biru
const Color secondaryColor = Color(0xFF43A047);     // Hijau
const Color accentColor = Color(0xFFFF9800);        // Oranye
const Color errorColor = Color(0xFFE53935);         // Merah
const Color warningColor = Color(0xFFFFC107);       // Kuning
const Color successColor = Color(0xFF4CAF50);       // Hijau Muda

// Tema Dark/Light
const Color backgroundLight = Color(0xFFF5F5F5);
const Color backgroundDark = Color(0xFF121212);
const Color surfaceLight = Color(0xFFFFFFFF);
const Color surfaceDark = Color(0xFF1E1E1E);
```

## 12. Best Practice Firebase

### 1. **Struktur Data**
- Gunakan **Document ID** yang konsisten dan bermakna
- Hindari **deep nesting** (maksimal 1 level sub-collection)
- Simpan **frequently accessed data** secara redundan jika perlu
- Gunakan **denormalization** untuk read-heavy operations

### 2. **Query Optimization**
- Gunakan **composite indexes** untuk query multi-field
- Hindari **client-side filtering** besar-besaran
- Gunakan **pagination** untuk data besar (>100 items)
- Batasi **query results** dengan `limit()`

### 3. **Security Rules**
- **Selalu validasi** data yang masuk
- Gunakan **server-side checks** untuk operasi sensitif
- **Test rules** sebelum deploy menggunakan Firebase Emulator
- **Audit logs** untuk operasi admin

### 4. **Cost Optimization**
- Gunakan **batch writes** untuk multiple operations
- Cache **read data** di client
- Hapus **unused data** secara berkala
- Monitor **usage** di Firebase Console

### 5. **Error Handling**
```dart
try {
  await FirebaseFirestore.instance.collection('books').add({
    'title': 'New Book',
    'author': 'Author',
  });
} on FirebaseException catch (e) {
  if (e.code == 'permission-denied') {
    // Handle permission error
  } else if (e.code == 'not-found') {
    // Handle document not found
  }
}
```

### 6. **Offline Support**
```dart
// Enable offline persistence
FirebaseFirestore.instance.settings = Settings(
  persistenceEnabled: true,
  cacheSizeBytes: Settings.CACHE_SIZE_UNLIMITED,
);
```

## 13. Deployment Checklist

### Firebase Setup:
- [x] Create Firebase project
- [x] Enable Firebase Auth (Email/Password)
- [x] Enable Cloud Firestore
- [x] Add Android app (package: com.example.ukkrepal)
- [x] Add iOS app (optional)
- [x] Download `google-services.json`
- [x] Publish Firestore Security Rules
- [x] Configure Firebase project settings

### App Configuration:
- [x] Add Firebase dependencies
- [x] Configure `google-services.json` in `android/app/`
- [x] Initialize Firebase in `main.dart`
- [x] Create auth service
- [x] Create firestore service
- [x] Create PDF service

### Testing:
- [x] Test Admin login
- [x] Test User login
- [x] Test CRUD books
- [x] Test CRUD members
- [x] Test borrow book flow
- [x] Test return book flow
- [x] Test PDF generation
- [x] Test offline behavior

## 14. Troubleshooting Common Issues

### Issue: Login Failed
**Cause:** User document doesn't exist in Firestore
**Solution:** Create user through app's "Tambah Anggota" feature

### Issue: Can't Write to Firestore
**Cause:** Security Rules not published
**Solution:** Publish rules at Firebase Console

### Issue: Infinite Loading
**Cause:** Stream not properly disposed
**Solution:** Use `StreamBuilder` with proper disposal

### Issue: PDF Not Printing
**Cause:** Missing permissions or package issue
**Solution:** Check `androidManifest.xml` permissions

---

## 📞 Support

**Firebase Console:** https://console.firebase.google.com/project/ukkrepal

**Dokumentasi:**
- [Firebase Docs](https://firebase.google.com/docs)
- [FlutterFire](https://firebase.flutter.dev/)
- [Firestore Rules](https://firebase.google.com/docs/firestore/security/rules)
