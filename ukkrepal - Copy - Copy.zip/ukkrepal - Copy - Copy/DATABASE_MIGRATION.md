# 🔄 Database Migration Guide

## Masalah
Field `bio` dan `photo_url` belum ada di user yang sudah terdaftar di Firestore sebelumnya.

## Solusi: Automatic Migration

### ✅ Yang Sudah Dilakukan:

1. **Update Model User** ✅
   - Menambahkan field `bio` dan `photo_url`

2. **Update AuthService** ✅
   - Load field `bio` dan `photo_url` saat login
   - Simpan field `bio` dan `photo_url` saat register user baru
   - Simpan `id` (Firebase UID) ke User model

3. **Buat Migration Script** ✅
   - File: `lib/utils/migrate_users.dart`
   - Fungsi: `migrateExistingUsers()`

4. **Integrasi ke main.dart** ✅
   - Migration otomatis dijalankan saat aplikasi start

## 🚀 Cara Menjalankan Migration

### Otomatis (Recommended)

Migration sudah ditambahkan di `main.dart` dan akan **otomatis berjalan** saat aplikasi dibuka.

**Langkah:**
1. **Hot Restart** aplikasi (bukan hot reload)
   - Tekan `R` di terminal atau
   - Stop dan run ulang aplikasi

2. **Cek Console/Debug Output**
   ```
   🔄 Starting user migration...
   📊 Found 5 users to migrate
   ✅ Updated user: abc123 (user@example.com)
   ✅ Updated user: def456 (admin@example.com)
   ...
   🎉 Migration completed!
      ✅ Updated: 5 users
      ⏭️  Skipped: 0 users
   ```

3. **Setelah Migration Selesai**
   
   **PENTING:** Comment baris migration di `main.dart` untuk performa lebih baik:
   
   ```dart
   // 2.5. MIGRATION DATABASE (SUDAH SELESAI - DI-COMMENT)
   // await migrateExistingUsers();
   ```

### Manual via Firebase Console

Jika tidak ingin menggunakan script otomatis:

1. Buka **Firebase Console** → **Firestore Database**
2. Pilih collection **"users"**
3. Untuk setiap user document:
   - Klik document
   - Klik **"Add field"**
   - Field name: `bio`, Type: `string`, Value: (kosongkan)
   - Klik **"Add field"** lagi
   - Field name: `photo_url`, Type: `string`, Value: (kosongkan)
   - Klik **"Save"**

## 📊 Struktur Database Sebelum & Sesudah

### ❌ Sebelum Migration
```
users/{userId}
  ├── username: "user@example.com"
  ├── role: "user"
  ├── memberId: "member123"
  └── created_at: timestamp
```

### ✅ Sesudah Migration
```
users/{userId}
  ├── username: "user@example.com"
  ├── role: "user"
  ├── memberId: "member123"
  ├── bio: null                    ← NEW
  ├── photo_url: null              ← NEW
  ├── created_at: timestamp
  └── updated_at: timestamp        ← NEW
```

## 🔍 Verifikasi Migration

### 1. Cek di Firebase Console
- Buka Firestore Database
- Pilih collection "users"
- Pastikan semua user punya field `bio` dan `photo_url`

### 2. Cek di Aplikasi
- Login sebagai user
- Buka menu "Profil Saya"
- Pastikan tidak ada error
- Coba edit nama/bio
- Coba upload foto profil

## ⚠️ Troubleshooting

### Error: "Field 'bio' doesn't exist"
**Solusi:** Migration belum berjalan. Hot restart aplikasi.

### Error: "Permission denied"
**Solusi:** Update Firestore rules:
```javascript
match /users/{userId} {
  allow read: if request.auth != null;
  allow update: if request.auth.uid == userId;
}
```

### Migration tidak berjalan
**Solusi:**
1. Pastikan ada koneksi internet
2. Cek Firebase Console apakah project sudah benar
3. Cek console output untuk error message
4. Coba manual migration via Firebase Console

### Migration berjalan terus setiap kali app start
**Solusi:** Comment baris migration di `main.dart`:
```dart
// await migrateExistingUsers();
```

## 📝 Notes

- Migration **aman** untuk dijalankan berkali-kali (idempotent)
- User yang sudah punya field akan di-skip
- Migration tidak mengubah data yang sudah ada
- Hanya menambahkan field baru dengan value `null`

## 🎯 Next Steps

Setelah migration selesai:

1. ✅ Comment baris migration di `main.dart`
2. ✅ Test fitur profil dengan login sebagai user
3. ✅ Upload foto profil
4. ✅ Edit nama dan bio
5. ✅ Verifikasi data tersimpan di Firestore

## 🔐 Security Rules (Recommended)

Update Firestore rules untuk mengizinkan user update profil mereka:

```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    // Users collection
    match /users/{userId} {
      // Anyone authenticated can read
      allow read: if request.auth != null;
      
      // User can only update their own profile
      // Cannot change role
      allow update: if request.auth.uid == userId 
                    && request.resource.data.role == resource.data.role;
    }
  }
}
```

Update Storage rules untuk foto profil:

```javascript
rules_version = '2';
service firebase.storage {
  match /b/{bucket}/o {
    // Profile photos
    match /profile_photos/{fileName} {
      // Anyone authenticated can read
      allow read: if request.auth != null;
      
      // Only authenticated users can upload
      // Max file size: 2MB
      allow write: if request.auth != null 
                   && request.resource.size < 2 * 1024 * 1024;
    }
  }
}
```

## ✅ Checklist

- [x] Update User model dengan field baru
- [x] Update AuthService untuk load/save field baru
- [x] Buat migration script
- [x] Integrasi migration ke main.dart
- [ ] Run aplikasi dan cek migration berhasil
- [ ] Comment migration setelah selesai
- [ ] Update Firebase rules
- [ ] Test fitur profil
- [ ] Verifikasi data di Firestore

---

**Migration siap dijalankan!** 🚀

Tinggal hot restart aplikasi dan migration akan berjalan otomatis.
