# 📚 DOKUMENTASI LENGKAP APLIKASI PERPUSTAKAAN SMKN12

## 📋 DAFTAR ISI
1. [Penjelasan Main.dart](#penjelasan-maindart)
2. [Struktur Project](#struktur-project)
3. [Relasi Firebase](#relasi-firebase)
4. [Penjelasan Setiap File](#penjelasan-setiap-file)
5. [Flow Aplikasi](#flow-aplikasi)

---

## 🎯 PENJELASAN MAIN.DART

### **Apa itu main.dart?**
`main.dart` adalah **file utama** dan **pintu masuk** aplikasi Flutter. Ini adalah file pertama yang dijalankan ketika aplikasi dibuka.

### **Kegunaan main.dart:**
1. **Inisialisasi Firebase** - Menghubungkan aplikasi ke Firebase
2. **Konfigurasi Tema** - Mengatur warna, font, dan style aplikasi
3. **Routing Awal** - Menentukan screen mana yang pertama kali muncul
4. **Splash Screen** - Menampilkan loading screen dengan animasi
5. **Auto-Login Check** - Mengecek apakah user sudah login sebelumnya

### **Komponen Utama dalam main.dart:**

#### 1. **Function main()**
```dart
void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
  runApp(const MyApp());
}
```
- **Fungsi:** Entry point aplikasi
- **Tugas:** 
  - Inisialisasi Flutter widgets
  - Koneksi ke Firebase
  - Menjalankan aplikasi

#### 2. **Class MyApp**
- **Fungsi:** Root widget aplikasi
- **Tugas:**
  - Setup responsive design (ScreenUtil)
  - Konfigurasi tema Material Design 3
  - Setup Google Fonts (Poppins)
  - Menentukan home screen (SplashScreen)

#### 3. **Class SplashScreen**
- **Fungsi:** Loading screen dengan animasi
- **Tugas:**
  - Menampilkan logo dan nama aplikasi
  - Animasi fade-in dan scale
  - Cek status login user
  - Redirect ke dashboard sesuai role (admin/user)

---

## 📁 STRUKTUR PROJECT

```
lib/
├── main.dart                          # Entry point aplikasi
├── firebase_options.dart              # Konfigurasi Firebase
│
├── database/
│   └── database_helper.dart           # SQLite local database (backup)
│
├── models/                            # Data models
│   ├── user.dart                      # Model data user
│   ├── book.dart                      # Model data buku
│   ├── member.dart                    # Model data anggota
│   └── transaction.dart               # Model data transaksi
│
├── services/                          # Business logic layer
│   ├── auth_service.dart              # Autentikasi (login/logout)
│   ├── firestore_service.dart         # CRUD Firebase Firestore
│   └── pdf_service.dart               # Generate laporan PDF
│
├── screens/                           # UI Screens
│   ├── login_screen.dart              # Halaman login
│   │
│   ├── admin/                         # Admin screens
│   │   ├── admin_dashboard.dart       # Dashboard admin
│   │   ├── admin_books_screen.dart    # Kelola buku
│   │   ├── admin_book_form_screen.dart # Form tambah/edit buku
│   │   ├── admin_members_screen.dart  # Kelola anggota
│   │   ├── admin_member_form_screen.dart # Form tambah/edit anggota
│   │   └── admin_transactions_screen.dart # Kelola transaksi
│   │
│   └── user/                          # User screens
│       ├── user_dashboard.dart        # Dashboard user
│       ├── user_borrow_screen.dart    # Pinjam buku
│       ├── user_return_screen.dart    # Kembalikan buku
│       └── user_history_screen.dart   # Riwayat peminjaman
│
└── utils/
    └── responsive_helper.dart         # Helper untuk responsive design
```

---

## 🔥 RELASI FIREBASE

### **Dimana Firebase Digunakan?**

#### 1. **main.dart** (Inisialisasi)
```dart
await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
```
- **Lokasi:** Line 13
- **Fungsi:** Menghubungkan aplikasi ke Firebase project
- **Kapan:** Saat aplikasi pertama kali dibuka

#### 2. **firebase_options.dart** (Konfigurasi)
- **Fungsi:** Menyimpan API keys dan konfigurasi Firebase
- **Isi:** 
  - API Key
  - Project ID
  - App ID
  - Messaging Sender ID
  - Storage Bucket
- **Platform:** Android, iOS, Web, Windows, macOS

#### 3. **services/auth_service.dart** (Autentikasi)
```dart
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
```
- **Firebase Auth:** Login, logout, register
- **Firestore:** Menyimpan data user (role, nama, email)
- **Collections:** `users`

#### 4. **services/firestore_service.dart** (Database)
```dart
import 'package:cloud_firestore/cloud_firestore.dart';
```
- **Fungsi:** CRUD operations untuk semua data
- **Collections:**
  - `books` - Data buku
  - `members` - Data anggota perpustakaan
  - `transactions` - Data peminjaman/pengembalian
  - `users` - Data user (admin/member)

#### 5. **Semua Screens** (UI)
- Menggunakan `FirestoreService` untuk mengambil/menyimpan data
- Real-time updates dengan `StreamBuilder`
- Menampilkan data dari Firebase ke UI

---

## 📄 PENJELASAN SETIAP FILE

### **1. main.dart**
- **Fungsi:** Entry point aplikasi
- **Firebase:** Inisialisasi Firebase
- **Komponen:**
  - `main()` - Function utama
  - `MyApp` - Root widget
  - `SplashScreen` - Loading screen
- **Relasi:** Memanggil `AuthService` untuk cek login

### **2. firebase_options.dart**
- **Fungsi:** Konfigurasi Firebase untuk semua platform
- **Auto-generated:** Dibuat oleh Firebase CLI
- **Jangan Edit:** File ini otomatis, jangan diubah manual

### **3. models/user.dart**
- **Fungsi:** Model data user
- **Properties:** id, email, name, role, createdAt
- **Methods:** 
  - `fromFirestore()` - Convert dari Firebase
  - `toFirestore()` - Convert ke Firebase
  - `fromJson()` / `toJson()` - Serialization

### **4. models/book.dart**
- **Fungsi:** Model data buku
- **Properties:** id, title, author, isbn, category, stock, available
- **Firebase Collection:** `books`

### **5. models/member.dart**
- **Fungsi:** Model data anggota
- **Properties:** id, name, email, phone, address, membershipDate
- **Firebase Collection:** `members`

### **6. models/transaction.dart**
- **Fungsi:** Model data transaksi peminjaman
- **Properties:** id, bookId, memberId, borrowDate, returnDate, status
- **Firebase Collection:** `transactions`

### **7. services/auth_service.dart**
- **Fungsi:** Handle autentikasi user
- **Firebase Services:**
  - `FirebaseAuth` - Login/logout
  - `Firestore` - Simpan data user
- **Methods:**
  - `login()` - Login dengan email/password
  - `register()` - Daftar user baru
  - `logout()` - Keluar dari aplikasi
  - `getCurrentUser()` - Ambil data user login
  - `isLoggedIn()` - Cek status login

### **8. services/firestore_service.dart**
- **Fungsi:** CRUD operations ke Firebase Firestore
- **Firebase Service:** `Cloud Firestore`
- **Methods:**
  - `addBook()`, `updateBook()`, `deleteBook()`, `getBooks()`
  - `addMember()`, `updateMember()`, `deleteMember()`, `getMembers()`
  - `addTransaction()`, `updateTransaction()`, `getTransactions()`
- **Real-time:** Menggunakan Stream untuk update otomatis

### **9. services/pdf_service.dart**
- **Fungsi:** Generate laporan PDF
- **Tidak pakai Firebase:** Hanya generate file lokal
- **Methods:**
  - `generateBookReport()` - Laporan daftar buku
  - `generateTransactionReport()` - Laporan transaksi

### **10. screens/login_screen.dart**
- **Fungsi:** Halaman login
- **Firebase:** Memanggil `AuthService.login()`
- **Redirect:** Ke admin/user dashboard sesuai role

### **11. screens/admin/admin_dashboard.dart**
- **Fungsi:** Dashboard admin
- **Firebase:** Ambil statistik dari Firestore
- **Fitur:**
  - Total buku, anggota, transaksi
  - Menu navigasi ke semua fitur admin

### **12. screens/admin/admin_books_screen.dart**
- **Fungsi:** Kelola data buku
- **Firebase:** 
  - `FirestoreService.getBooks()` - Ambil data
  - `FirestoreService.deleteBook()` - Hapus buku
- **Fitur:** List, search, add, edit, delete buku

### **13. screens/admin/admin_book_form_screen.dart**
- **Fungsi:** Form tambah/edit buku
- **Firebase:**
  - `FirestoreService.addBook()` - Tambah buku baru
  - `FirestoreService.updateBook()` - Update buku

### **14. screens/admin/admin_members_screen.dart**
- **Fungsi:** Kelola data anggota
- **Firebase:** CRUD members collection

### **15. screens/admin/admin_member_form_screen.dart**
- **Fungsi:** Form tambah/edit anggota
- **Firebase:** Add/update members

### **16. screens/admin/admin_transactions_screen.dart**
- **Fungsi:** Kelola transaksi peminjaman
- **Firebase:** CRUD transactions collection
- **Fitur:** Approve, reject, complete transaksi

### **17. screens/user/user_dashboard.dart**
- **Fungsi:** Dashboard user/anggota
- **Firebase:** Ambil data buku dan transaksi user
- **Fitur:** Lihat buku tersedia, riwayat pinjaman

### **18. screens/user/user_borrow_screen.dart**
- **Fungsi:** Pinjam buku
- **Firebase:**
  - Ambil daftar buku tersedia
  - Buat transaksi baru
  - Update stok buku

### **19. screens/user/user_return_screen.dart**
- **Fungsi:** Kembalikan buku
- **Firebase:**
  - Update status transaksi
  - Update stok buku

### **20. screens/user/user_history_screen.dart**
- **Fungsi:** Riwayat peminjaman user
- **Firebase:** Query transaksi berdasarkan user ID

### **21. utils/responsive_helper.dart**
- **Fungsi:** Helper untuk responsive design
- **Tidak pakai Firebase**

### **22. database/database_helper.dart**
- **Fungsi:** SQLite local database (backup/offline)
- **Tidak pakai Firebase:** Hanya untuk data lokal

---

## 🔄 FLOW APLIKASI

### **1. Aplikasi Dibuka**
```
main.dart (main function)
  ↓
Firebase.initializeApp() → Koneksi ke Firebase
  ↓
MyApp widget → Setup tema & routing
  ↓
SplashScreen → Loading screen
  ↓
_checkLoginStatus() → Cek apakah user sudah login
  ↓
AuthService.isLoggedIn() → Query ke Firebase Auth
```

### **2. Jika Belum Login**
```
SplashScreen
  ↓
LoginScreen → User input email & password
  ↓
AuthService.login() → Firebase Auth login
  ↓
Firestore query → Ambil data user (role)
  ↓
Redirect berdasarkan role:
  - Admin → AdminDashboard
  - User → UserDashboard
```

### **3. Jika Sudah Login**
```
SplashScreen
  ↓
AuthService.getCurrentUser() → Ambil data dari Firebase
  ↓
Cek role:
  - Admin → AdminDashboard
  - User → UserDashboard
```

### **4. Admin Flow**
```
AdminDashboard
  ↓
Pilih menu:
  - Kelola Buku → AdminBooksScreen → CRUD via FirestoreService
  - Kelola Anggota → AdminMembersScreen → CRUD via FirestoreService
  - Kelola Transaksi → AdminTransactionsScreen → CRUD via FirestoreService
  - Generate Laporan → PDFService (tidak pakai Firebase)
```

### **5. User Flow**
```
UserDashboard
  ↓
Pilih menu:
  - Pinjam Buku → UserBorrowScreen → Create transaction di Firestore
  - Kembalikan Buku → UserReturnScreen → Update transaction di Firestore
  - Riwayat → UserHistoryScreen → Query transactions dari Firestore
```

---

## 🔥 FIREBASE COLLECTIONS STRUCTURE

### **Collection: users**
```
users/
  └── {userId}/
      ├── id: string
      ├── email: string
      ├── name: string
      ├── role: string (admin/member)
      └── createdAt: Timestamp
```

### **Collection: books**
```
books/
  └── {bookId}/
      ├── id: string
      ├── title: string
      ├── author: string
      ├── isbn: string
      ├── category: string
      ├── stock: int
      ├── available: int
      └── createdAt: Timestamp
```

### **Collection: members**
```
members/
  └── {memberId}/
      ├── id: string
      ├── name: string
      ├── email: string
      ├── phone: string
      ├── address: string
      └── membershipDate: Timestamp
```

### **Collection: transactions**
```
transactions/
  └── {transactionId}/
      ├── id: string
      ├── bookId: string
      ├── bookTitle: string
      ├── memberId: string
      ├── memberName: string
      ├── borrowDate: Timestamp
      ├── dueDate: Timestamp
      ├── returnDate: Timestamp (nullable)
      ├── status: string (borrowed/returned/overdue)
      └── createdAt: Timestamp
```

---

## 🎨 DEPENDENCIES (pubspec.yaml)

### **Firebase Dependencies**
```yaml
firebase_core: ^4.4.0           # Core Firebase
firebase_auth: ^6.1.4           # Autentikasi
firebase_auth_web: ^6.1.2       # Auth untuk web
cloud_firestore: ^6.1.2         # Database Firestore
cloud_firestore_web: ^5.1.2     # Firestore untuk web
firebase_storage: ^13.0.6       # Storage (jika upload file)
firebase_storage_web: ^3.11.2   # Storage untuk web
```

### **UI/UX Dependencies**
```yaml
google_fonts: ^6.1.0            # Font Poppins
flutter_animate: ^4.5.0         # Animasi
flutter_screenutil: ^5.9.0      # Responsive design
```

### **Other Dependencies**
```yaml
sqflite: ^2.3.0                 # SQLite local database
shared_preferences: ^2.2.2      # Local storage
pdf: ^3.10.7                    # Generate PDF
printing: ^5.12.0               # Print PDF
intl: ^0.19.0                   # Format tanggal
```

---

## 📝 KESIMPULAN

### **main.dart adalah:**
- ✅ Entry point aplikasi
- ✅ Tempat inisialisasi Firebase
- ✅ Setup tema dan konfigurasi global
- ✅ Routing awal aplikasi
- ✅ Splash screen dengan auto-login check

### **Firebase digunakan di:**
- ✅ `main.dart` - Inisialisasi
- ✅ `firebase_options.dart` - Konfigurasi
- ✅ `auth_service.dart` - Login/logout
- ✅ `firestore_service.dart` - CRUD data
- ✅ Semua screens - Menampilkan data

### **Alur Data:**
```
UI (Screens) 
  ↕️
Services (auth_service, firestore_service)
  ↕️
Firebase (Auth, Firestore)
  ↕️
Models (user, book, member, transaction)
```

---

**Dibuat oleh:** Antigravity AI  
**Tanggal:** 10 Februari 2026  
**Project:** Perpustakaan SMKN12
