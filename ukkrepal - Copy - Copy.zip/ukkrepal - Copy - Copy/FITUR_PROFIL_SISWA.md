# Fitur Profil Siswa

## 📱 Overview
Fitur profil siswa memungkinkan pengguna untuk mengelola profil mereka sendiri, mirip dengan aplikasi media sosial seperti WhatsApp. Siswa dapat melihat dan mengedit informasi pribadi mereka termasuk nama, bio, dan foto profil.

## ✨ Fitur Utama

### 1. **Foto Profil**
- Upload foto dari galeri
- Preview foto profil
- Foto disimpan di Firebase Storage
- Fallback ke avatar dengan inisial nama jika tidak ada foto
- Loading indicator saat upload

### 2. **Edit Nama**
- Ubah nama tampilan
- Validasi maksimal 50 karakter
- Update real-time di dashboard

### 3. **Edit Bio**
- Tambah/ubah bio/status pribadi
- Maksimal 150 karakter
- Multi-line input (3 baris)
- Placeholder "Tambahkan bio..." jika kosong

### 4. **Informasi Read-Only**
- NIS (Nomor Induk Siswa)
- Kelas
- Role (Siswa/Administrator)

## 🎨 UI/UX Design

### Design Principles
- **Modern & Clean**: Menggunakan card-based layout dengan shadow dan rounded corners
- **Consistent Colors**: Menggunakan color scheme yang sama dengan aplikasi (Indigo primary)
- **Intuitive Icons**: Setiap field memiliki icon yang jelas
- **Visual Feedback**: Loading states, success/error messages
- **Responsive**: Menggunakan ScreenUtil untuk adaptasi berbagai ukuran layar

### Color Palette
- Primary: `#6366F1` (Indigo)
- Secondary: `#8B5CF6` (Purple)
- Accent: `#06B6D4` (Cyan) untuk menu profil
- Background: White dengan gradient subtle
- Text: `#1F2937` (Dark Gray)

## 📂 File Structure

```
lib/
├── models/
│   └── user.dart                    # Model User dengan field bio & photoUrl
├── screens/
│   └── user/
│       ├── user_dashboard.dart      # Dashboard dengan menu "Profil Saya"
│       └── user_profile_screen.dart # Screen profil siswa (NEW)
└── services/
    └── firestore_service.dart       # Service dengan method updateUser()
```

## 🔧 Technical Implementation

### 1. Model User
```dart
class User {
  final String? id;
  final String username;
  final String password;
  final String role;
  final String? memberId;
  final String? bio;        // NEW: Bio/status user
  final String? photoUrl;   // NEW: URL foto profil
}
```

### 2. Firebase Storage
- Path: `profile_photos/{userId}_{timestamp}.jpg`
- Format: JPEG
- Max size: 512x512 pixels
- Quality: 75%

### 3. Firestore Structure
```
users/{userId}
  ├── username: string
  ├── password: string
  ├── role: string
  ├── member_id: string?
  ├── bio: string?          // NEW
  ├── photo_url: string?    // NEW
  ├── created_at: timestamp
  └── updated_at: timestamp
```

## 📱 User Flow

### Akses Profil
1. User membuka Dashboard
2. Tap menu "Profil Saya" (card cyan-blue)
3. Screen profil terbuka dengan animasi

### Edit Foto Profil
1. Tap icon kamera di foto profil
2. Pilih foto dari galeri
3. Foto di-resize dan di-compress
4. Upload ke Firebase Storage
5. URL disimpan ke Firestore
6. Foto langsung muncul di profil & dashboard

### Edit Nama/Bio
1. Tap card "Nama" atau "Bio"
2. Dialog edit muncul
3. Ketik perubahan
4. Tap "Simpan"
5. Data diupdate di Firestore
6. Profil di-reload otomatis

## 🔐 Security & Validation

### Input Validation
- **Nama**: Max 50 karakter, tidak boleh kosong
- **Bio**: Max 150 karakter, boleh kosong
- **Foto**: Max 512x512px, quality 75%, format JPEG

### Firebase Rules (Recommended)
```javascript
// Firestore Rules
match /users/{userId} {
  allow read: if request.auth != null;
  allow update: if request.auth.uid == userId 
                && request.resource.data.role == resource.data.role;
}

// Storage Rules
match /profile_photos/{fileName} {
  allow read: if request.auth != null;
  allow write: if request.auth != null 
               && request.resource.size < 2 * 1024 * 1024;
}
```

## 📦 Dependencies

### New Dependencies
```yaml
image_picker: ^1.0.7  # Untuk memilih foto dari galeri
```

### Existing Dependencies
```yaml
firebase_storage: ^13.0.6      # Upload foto ke Firebase
cloud_firestore: ^6.1.2        # Database
flutter_screenutil: ^5.9.0     # Responsive design
google_fonts: ^6.1.0           # Typography
```

## 🎯 Features Comparison

| Feature | WhatsApp | Aplikasi Ini |
|---------|----------|--------------|
| Foto Profil | ✅ | ✅ |
| Edit Nama | ✅ | ✅ |
| Bio/Status | ✅ | ✅ |
| Info Read-Only | ✅ (Phone) | ✅ (NIS, Kelas) |
| Crop Foto | ✅ | ⚠️ (Auto resize) |
| Foto Full Screen | ✅ | ❌ |

## 🚀 Future Enhancements

### Potential Features
1. **Image Cropper**: Tambah fitur crop foto sebelum upload
2. **Camera Support**: Ambil foto langsung dari kamera
3. **Profile Stats**: Tampilkan statistik peminjaman
4. **Achievements**: Badge untuk user aktif
5. **QR Code**: Generate QR code untuk profil
6. **Dark Mode**: Support tema gelap
7. **Profile Sharing**: Share profil ke teman

### Performance Optimizations
1. **Image Caching**: Cache foto profil untuk loading lebih cepat
2. **Lazy Loading**: Load foto hanya saat diperlukan
3. **Compression**: Optimize ukuran file lebih lanjut
4. **CDN**: Gunakan CDN untuk foto profil

## 🐛 Known Issues & Solutions

### Issue 1: Foto tidak muncul
**Cause**: Network error atau URL tidak valid
**Solution**: Error builder menampilkan avatar default

### Issue 2: Upload lambat
**Cause**: Ukuran file terlalu besar
**Solution**: Auto-resize ke 512x512 dan compress ke 75%

### Issue 3: Permission denied
**Cause**: Firebase rules tidak mengizinkan
**Solution**: Update Firestore & Storage rules

## 📊 Usage Statistics (Expected)

- **Profile Views**: ~80% user akan membuka profil
- **Photo Upload**: ~60% user akan upload foto
- **Bio Update**: ~40% user akan menambah bio
- **Name Change**: ~20% user akan mengubah nama

## 🎓 Learning Points

### For Developers
1. **Image Handling**: Cara upload dan display image dari network
2. **Firebase Storage**: Integrasi dengan Firebase Storage
3. **State Management**: Update UI setelah data berubah
4. **Error Handling**: Graceful degradation saat error
5. **Responsive Design**: Menggunakan ScreenUtil untuk berbagai device

### Best Practices Applied
- ✅ Separation of concerns (Model, View, Service)
- ✅ Error handling dengan try-catch
- ✅ Loading states untuk UX yang baik
- ✅ Null safety
- ✅ Responsive design
- ✅ Consistent naming conventions
- ✅ Code documentation

## 📝 Code Examples

### Upload Foto
```dart
Future<void> _pickAndUploadImage() async {
  final ImagePicker picker = ImagePicker();
  final XFile? image = await picker.pickImage(
    source: ImageSource.gallery,
    maxWidth: 512,
    maxHeight: 512,
    imageQuality: 75,
  );
  
  if (image == null) return;
  
  final storageRef = FirebaseStorage.instance
      .ref()
      .child('profile_photos')
      .child('${userId}_${timestamp}.jpg');
  
  await storageRef.putFile(File(image.path));
  final downloadUrl = await storageRef.getDownloadURL();
  
  await updateUser(userId, {'photo_url': downloadUrl});
}
```

### Display Foto
```dart
_currentUser?.photoUrl != null
    ? ClipOval(
        child: Image.network(
          _currentUser!.photoUrl!,
          fit: BoxFit.cover,
          errorBuilder: (context, error, stackTrace) {
            return DefaultAvatar();
          },
        ),
      )
    : DefaultAvatar()
```

## 🎉 Conclusion

Fitur profil siswa ini memberikan pengalaman yang lebih personal dan modern kepada pengguna aplikasi perpustakaan. Dengan UI yang mirip WhatsApp, user akan merasa familiar dan mudah menggunakan fitur ini.

**Key Achievements:**
- ✅ Modern, intuitive UI
- ✅ Full CRUD untuk profil
- ✅ Image upload & storage
- ✅ Real-time updates
- ✅ Error handling
- ✅ Responsive design

**Impact:**
- Meningkatkan engagement user
- Personalisasi pengalaman
- Modernisasi aplikasi
- User satisfaction ⬆️
