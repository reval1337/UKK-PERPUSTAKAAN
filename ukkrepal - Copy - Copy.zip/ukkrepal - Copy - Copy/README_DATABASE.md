# 📚 DOKUMENTASI PERPUSTAKAAN SMKN12

## 📋 Daftar File Dokumentasi

Berikut adalah file-file dokumentasi yang telah dibuat untuk Sistem Perpustakaan SMKN12:

### 1. 📊 ERD_PERPUSTAKAAN.md
**Entity Relationship Diagram - Struktur Database**

File ini berisi:
- ✅ Definisi 6 entitas utama (Anggota, Buku, Peminjaman, Pengarang, Kategori, Buku_Kategori)
- ✅ Atribut lengkap setiap entitas dengan tipe data
- ✅ Relasi antar entitas (1:1, 1:N, M:N)
- ✅ Diagram ERD dalam format text
- ✅ Constraints (Primary Key, Foreign Key, Unique, Check)
- ✅ Normalisasi database (1NF, 2NF, 3NF)
- ✅ Rekomendasi indeks untuk optimasi

**Cara Menggunakan:**
```bash
# Buka file untuk melihat struktur database
code ERD_PERPUSTAKAAN.md
```

---

### 2. 📈 LAPORAN_PERPUSTAKAAN.md
**Laporan Lengkap Sistem Perpustakaan**

File ini berisi 6 jenis laporan:

#### A. Laporan Anggota
- Daftar anggota aktif
- Daftar anggota tidak aktif
- Anggota dengan peminjaman terbanyak

#### B. Laporan Buku
- Daftar buku tersedia
- Daftar buku sedang dipinjam
- Daftar buku hilang/rusak
- Buku paling populer

#### C. Laporan Peminjaman
- Peminjaman aktif
- Peminjaman terlambat
- Peminjaman selesai
- Peminjaman per periode

#### D. Laporan Statistik
- Statistik umum (dashboard)
- Statistik per kategori
- Trend peminjaman

#### E. Laporan Keuangan
- Laporan denda
- Top denda tertunggak

#### F. Laporan Analitik
- Analisis perilaku peminjam
- Analisis waktu peminjaman
- Rekomendasi

**Setiap laporan dilengkapi dengan:**
- Query SQL yang siap pakai
- Format tabel output
- Contoh data
- Visualisasi (grafik/chart dalam text)

**Cara Menggunakan:**
```bash
# Buka file untuk melihat template laporan
code LAPORAN_PERPUSTAKAAN.md
```

---

### 3. 🗄️ database_perpustakaan.sql
**Script SQL Lengkap untuk Database**

File ini berisi:

#### A. DDL (Data Definition Language)
- ✅ CREATE DATABASE
- ✅ CREATE TABLE (6 tabel)
- ✅ PRIMARY KEY & FOREIGN KEY
- ✅ CONSTRAINTS (CHECK, UNIQUE, NOT NULL)
- ✅ INDEXES untuk optimasi

#### B. Triggers
- ✅ `trg_after_insert_peminjaman` - Update stok saat pinjam
- ✅ `trg_after_update_peminjaman` - Update stok saat kembali
- ✅ `trg_before_update_pengembalian` - Hitung denda otomatis

#### C. Views
- ✅ `v_buku_tersedia` - Daftar buku tersedia
- ✅ `v_peminjaman_aktif` - Peminjaman yang sedang berjalan
- ✅ `v_peminjaman_terlambat` - Peminjaman terlambat
- ✅ `v_statistik_perpustakaan` - Dashboard statistik

#### D. Stored Procedures
- ✅ `sp_pinjam_buku` - Proses peminjaman dengan validasi
- ✅ `sp_kembalikan_buku` - Proses pengembalian

#### E. Sample Data
- ✅ 5 Kategori buku
- ✅ 5 Pengarang
- ✅ 5 Buku
- ✅ 5 Anggota
- ✅ 3 Peminjaman (contoh)

**Cara Menggunakan:**

**Opsi 1: MySQL Command Line**
```bash
# Login ke MySQL
mysql -u root -p

# Jalankan script
source database_perpustakaan.sql

# Atau
mysql -u root -p < database_perpustakaan.sql
```

**Opsi 2: MySQL Workbench**
1. Buka MySQL Workbench
2. File → Open SQL Script
3. Pilih `database_perpustakaan.sql`
4. Klik Execute (⚡)

**Opsi 3: phpMyAdmin**
1. Buka phpMyAdmin
2. Klik tab "Import"
3. Choose File → `database_perpustakaan.sql`
4. Klik "Go"

---

## 🎯 Cara Export ke PDF

### Metode 1: Menggunakan Markdown to PDF (Recommended)

**Install Extension VS Code:**
```bash
# Install extension "Markdown PDF"
# Atau cari di VS Code Extensions: Markdown PDF
```

**Cara Export:**
1. Buka file `.md` di VS Code
2. Klik kanan → "Markdown PDF: Export (pdf)"
3. File PDF akan tersimpan di folder yang sama

### Metode 2: Menggunakan Pandoc

**Install Pandoc:**
```bash
# Windows (dengan Chocolatey)
choco install pandoc

# Atau download dari: https://pandoc.org/installing.html
```

**Export ke PDF:**
```bash
# ERD
pandoc ERD_PERPUSTAKAAN.md -o ERD_PERPUSTAKAAN.pdf

# Laporan
pandoc LAPORAN_PERPUSTAKAAN.md -o LAPORAN_PERPUSTAKAAN.pdf

# Dengan styling
pandoc ERD_PERPUSTAKAAN.md -o ERD_PERPUSTAKAAN.pdf --pdf-engine=xelatex -V geometry:margin=1in
```

### Metode 3: Online Converter

**Website:**
- https://www.markdowntopdf.com/
- https://md2pdf.netlify.app/
- https://dillinger.io/ (bisa export PDF)

**Cara:**
1. Buka website
2. Copy-paste isi file `.md`
3. Klik "Convert to PDF" atau "Export"

### Metode 4: Print to PDF dari Browser

1. Buka file `.md` di VS Code
2. Klik "Open Preview" (Ctrl+Shift+V)
3. Klik kanan → "Open in Browser"
4. Di browser: Ctrl+P (Print)
5. Pilih "Save as PDF"
6. Save

---

## 📊 Struktur Database (Ringkasan)

```
perpustakaan_smkn12/
│
├── pengarang (Author)
│   └── Menyimpan data pengarang buku
│
├── kategori (Category)
│   └── Menyimpan kategori/genre buku
│
├── buku (Book)
│   ├── Menyimpan koleksi buku
│   └── Relasi: 1:N dengan pengarang
│
├── buku_kategori (Junction Table)
│   └── Relasi M:N antara buku & kategori
│
├── anggota (Member)
│   └── Menyimpan data anggota perpustakaan
│
└── peminjaman (Borrowing)
    ├── Menyimpan transaksi peminjaman
    ├── Relasi: N:1 dengan anggota
    └── Relasi: N:1 dengan buku
```

---

## 🔑 Fitur Utama Database

### 1. **Automatic Stock Management**
- Stok buku otomatis berkurang saat dipinjam
- Stok buku otomatis bertambah saat dikembalikan
- Menggunakan triggers

### 2. **Automatic Fine Calculation**
- Denda dihitung otomatis berdasarkan keterlambatan
- Rumus: Hari terlambat × Rp 1.000
- Menggunakan trigger

### 3. **Business Rules Validation**
- Maksimal 3 buku dipinjam per anggota
- Hanya anggota aktif yang bisa meminjam
- Buku harus tersedia (stok > 0)
- Menggunakan stored procedure

### 4. **Optimized Queries**
- Views untuk laporan yang sering digunakan
- Indexes pada kolom yang sering di-query
- Foreign keys untuk data integrity

---

## 📝 Query Penting

### Cek Buku Tersedia
```sql
SELECT * FROM v_buku_tersedia;
```

### Cek Peminjaman Aktif
```sql
SELECT * FROM v_peminjaman_aktif;
```

### Cek Peminjaman Terlambat
```sql
SELECT * FROM v_peminjaman_terlambat;
```

### Statistik Dashboard
```sql
SELECT * FROM v_statistik_perpustakaan;
```

### Pinjam Buku (dengan validasi)
```sql
CALL sp_pinjam_buku('P004', 'A001', 'B004', 7);
-- Parameter: id_peminjaman, id_anggota, id_buku, lama_pinjam (hari)
```

### Kembalikan Buku
```sql
CALL sp_kembalikan_buku('P001');
-- Parameter: id_peminjaman
```

---

## 🎨 Visualisasi ERD

Untuk membuat diagram ERD visual, gunakan tools:

### Online Tools:
1. **dbdiagram.io** - https://dbdiagram.io/
   - Paste DDL SQL
   - Generate diagram otomatis

2. **QuickDBD** - https://www.quickdatabasediagrams.com/
   - Input schema
   - Export ke PNG/PDF

3. **Draw.io** - https://app.diagrams.net/
   - Buat diagram manual
   - Export ke berbagai format

### Desktop Tools:
1. **MySQL Workbench**
   - Database → Reverse Engineer
   - Generate ERD dari database

2. **DBeaver**
   - ER Diagram feature
   - Export ke image

---

## 📞 Support & Kontak

**Perpustakaan SMKN12**
- Email: perpustakaan@smkn12.sch.id
- Telepon: (021) 1234-5678
- Website: library.smkn12.sch.id

---

## 📄 Lisensi

Dokumentasi ini dibuat untuk keperluan internal Perpustakaan SMKN12.

---

## 🔄 Update History

| Versi | Tanggal | Perubahan |
|-------|---------|-----------|
| 1.0 | 10 Feb 2026 | Initial release - ERD, Laporan, SQL Script |

---

**Dibuat dengan ❤️ untuk Perpustakaan SMKN12**  
*Sistem Manajemen Perpustakaan Digital*
