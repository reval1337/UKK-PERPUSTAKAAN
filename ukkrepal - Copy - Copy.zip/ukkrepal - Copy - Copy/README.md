# Aplikasi Perpustakaan SMKN12

Aplikasi perpustakaan sederhana untuk SMKN12 yang dibuat dengan Flutter. Aplikasi ini dirancang dengan UI/UX yang sederhana dan mudah digunakan, cocok untuk semua kalangan termasuk anak-anak.

## Fitur Utama

### Untuk Admin:
- ✅ Login sebagai admin
- ✅ Dashboard admin dengan menu navigasi
- ✅ CRUD Data Buku (Create, Read, Update, Delete)
- ✅ CRUD Kelola Anggota (Create, Read, Update, Delete)
- ✅ CRUD Transaksi (Create, Read, Update, Delete)
- ✅ Pencarian data (buku, anggota, transaksi)
- ✅ Cetak/Export Laporan ke PDF:
  - Laporan Data Buku
  - Laporan Data Anggota
  - Laporan Transaksi
- ✅ Logout admin

### Untuk User/Siswa:
- ✅ Login sebagai siswa
- ✅ Dashboard siswa dengan informasi profil
- ✅ Peminjaman Buku
- ✅ Pengembalian Buku
- ✅ Melihat riwayat peminjaman
- ✅ Melihat progress/kondisi buku yang dipinjam
- ✅ Pencarian buku
- ✅ Logout user

## Teknologi yang Digunakan

- **Flutter** - Framework untuk pengembangan aplikasi mobile
- **SQLite (sqflite)** - Database lokal untuk penyimpanan data
- **PDF (pdf package)** - Untuk generate laporan PDF
- **Printing** - Untuk mencetak/export PDF
- **Shared Preferences** - Untuk menyimpan session login
- **Intl** - Untuk format tanggal

## Struktur Database

Aplikasi menggunakan SQLite dengan 4 tabel utama:
1. **users** - Data pengguna (admin dan siswa)
2. **members** - Data anggota perpustakaan
3. **books** - Data buku
4. **transactions** - Data transaksi peminjaman

Lihat file `ERD.md` untuk detail struktur database dan relasi antar tabel.

## Instalasi

1. Pastikan Flutter sudah terinstall di sistem Anda
2. Clone atau download project ini
3. Buka terminal di folder project
4. Install dependencies:
   ```bash
   flutter pub get
   ```
5. Jalankan aplikasi:
   ```bash
   flutter run
   ```

## Default Login

**Admin:**
- Username: `admin`
- Password: `admin123`

**Catatan:** Setelah login pertama kali, disarankan untuk mengubah password admin melalui menu pengelolaan.

## Cara Menggunakan

### Untuk Admin:

1. **Login** dengan username dan password admin
2. **Dashboard Admin** menampilkan 4 menu utama:
   - Kelola Buku: Tambah, edit, hapus, dan cari buku
   - Kelola Anggota: Daftarkan anggota baru, edit, hapus, dan cari anggota
   - Transaksi: Lihat semua transaksi, kembalikan buku, hapus transaksi
   - Laporan: Cetak laporan dalam format PDF

### Untuk Siswa:

1. **Login** dengan username dan password siswa
   - Siswa harus terdaftar sebagai anggota terlebih dahulu oleh admin
   - Admin akan membuatkan akun untuk siswa melalui menu Kelola Anggota
2. **Dashboard Siswa** menampilkan:
   - Informasi profil siswa
   - Jumlah buku yang sedang dipinjam
   - Menu: Pinjam Buku, Kembalikan Buku, Riwayat, Cari Buku

## Fitur Pencarian

- **Admin** dapat mencari:
  - Buku berdasarkan judul, pengarang, atau kategori
  - Anggota berdasarkan nama, NIS, atau kelas
  - Transaksi berdasarkan nama anggota, NIS, atau judul buku

- **Siswa** dapat mencari:
  - Buku berdasarkan judul, pengarang, atau kategori

## Sistem Denda

- Denda dihitung otomatis jika pengembalian melewati tanggal jatuh tempo
- Tarif denda: **Rp 1.000 per hari** keterlambatan
- Masa pinjam: **7 hari** dari tanggal peminjaman

## UI/UX Design

Aplikasi dirancang dengan prinsip:
- **Sederhana** - Interface yang mudah dipahami
- **Warna cerah** - Menggunakan warna-warna yang menarik dan ramah mata
- **Ikon besar** - Ikon yang jelas dan mudah dikenali
- **Teks jelas** - Font size yang mudah dibaca
- **Navigasi intuitif** - Menu yang mudah diakses

## Struktur Project

```
lib/
├── models/           # Model data (Book, Member, Transaction, User)
├── database/         # Database helper dan operasi database
├── services/         # Services (Auth, PDF)
├── screens/          # Halaman aplikasi
│   ├── admin/       # Halaman admin
│   └── user/        # Halaman user/siswa
└── main.dart        # Entry point aplikasi
```

## Dokumentasi

- **ERD.md** - Entity Relationship Diagram dan struktur database
- **README.md** - Dokumentasi ini

## Catatan Penting

1. Database SQLite akan dibuat otomatis saat pertama kali aplikasi dijalankan
2. Data sample (buku contoh) akan otomatis ditambahkan saat pertama kali setup
3. Pastikan untuk membuat backup database secara berkala
4. Untuk production, disarankan untuk menggunakan database server (MySQL/PostgreSQL) dengan backend API

## Lisensi

Project ini dibuat untuk keperluan edukasi dan UKK (Uji Kompetensi Keahlian) SMKN12.

## Kontributor

Dibuat dengan ❤️ untuk Perpustakaan SMKN12
