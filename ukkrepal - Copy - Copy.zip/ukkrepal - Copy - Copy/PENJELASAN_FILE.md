# 📂 PENJELASAN SETIAP FILE

Dokumentasi singkat untuk setiap file dalam project Perpustakaan SMKN12

---

## 📍 ROOT FILES

### **pubspec.yaml**
```yaml
📍 Lokasi: /pubspec.yaml
🎯 Fungsi: Konfigurasi project Flutter
📦 Isi:
  - Nama project: ukkrepal
  - Dependencies (package yang digunakan)
  - Assets (gambar, font, dll)
```

**Dependencies Penting:**
- `firebase_core` - Core Firebase
- `firebase_auth` - Autentikasi
- `cloud_firestore` - Database
- `google_fonts` - Font Poppins
- `flutter_screenutil` - Responsive design

---

### **.firebaserc**
```json
📍 Lokasi: /.firebaserc
🎯 Fungsi: Konfigurasi Firebase project
🔑 Isi: Project ID = flutter-auth-test-d4606
```

---

### **firebase.json**
```json
📍 Lokasi: /firebase.json
🎯 Fungsi: Konfigurasi Firebase Hosting & Firestore
```

---

### **firestore.rules**
```
📍 Lokasi: /firestore.rules
🎯 Fungsi: Security rules untuk Firestore
🔒 Isi: Aturan akses database
```

---

### **firestore.indexes.json**
```json
📍 Lokasi: /firestore.indexes.json
🎯 Fungsi: Index untuk query Firestore
⚡ Isi: Konfigurasi index untuk performa query
```

---

## 📱 LIB FOLDER

### **main.dart**
```dart
📍 Lokasi: lib/main.dart
🎯 Fungsi: Entry point aplikasi
✅ Status: SUDAH ADA KOMENTAR LENGKAP

📝 Isi:
  1. Function main() - Inisialisasi Firebase
  2. Class MyApp - Root widget, setup tema
  3. Class SplashScreen - Loading screen dengan animasi
  
🔥 Firebase:
  - Inisialisasi Firebase di main()
  - Auto-login check di SplashScreen
  
🔄 Flow:
  main() → Firebase.init → MyApp → SplashScreen → Login/Dashboard
```

---

### **firebase_options.dart**
```dart
📍 Lokasi: lib/firebase_options.dart
🎯 Fungsi: Konfigurasi Firebase untuk semua platform
⚠️  JANGAN EDIT: Auto-generated oleh Firebase CLI

📝 Isi:
  - API Keys untuk setiap platform
  - Project ID: flutter-auth-test-d4606
  - App ID untuk Web, Android, iOS, Windows, macOS
  
🔥 Firebase:
  - Digunakan di main.dart untuk inisialisasi
  - DefaultFirebaseOptions.currentPlatform
```

---

## 📦 MODELS FOLDER

### **user.dart**
```dart
📍 Lokasi: lib/models/user.dart
🎯 Fungsi: Model data user

📝 Properties:
  - id: int? (ID lokal SQLite)
  - username: String (email user)
  - password: String (hashed)
  - role: String (admin/user)
  - memberId: String? (ID anggota jika role=user)
  
📋 Methods:
  - fromFirestore() - Convert dari Firestore document
  - toFirestore() - Convert ke Firestore map
  - fromJson() - Convert dari JSON
  - toJson() - Convert ke JSON
  - toMap() - Convert ke Map (untuk SQLite)
  - fromMap() - Convert dari Map
  
🔥 Firebase:
  - Digunakan di auth_service.dart
  - Mapping data dari Firestore collection 'users'
```

---

### **book.dart**
```dart
📍 Lokasi: lib/models/book.dart
🎯 Fungsi: Model data buku

📝 Properties:
  - id: String? (Firestore document ID)
  - title: String (judul buku)
  - author: String (penulis)
  - isbn: String (ISBN)
  - category: String (kategori)
  - stock: int (total stok)
  - available: int (stok tersedia)
  - createdAt: DateTime?
  
📋 Methods:
  - fromFirestore() - Convert dari Firestore
  - toFirestore() - Convert ke Firestore
  - copyWith() - Clone dengan perubahan
  
🔥 Firebase:
  - Collection: books
  - Digunakan di firestore_service.dart
  - Real-time update via StreamBuilder
```

---

### **member.dart**
```dart
📍 Lokasi: lib/models/member.dart
🎯 Fungsi: Model data anggota perpustakaan

📝 Properties:
  - id: String? (Firestore document ID)
  - name: String (nama lengkap)
  - email: String
  - phone: String (nomor telepon)
  - address: String (alamat)
  - membershipDate: DateTime (tanggal daftar)
  - createdAt: DateTime?
  
📋 Methods:
  - fromFirestore() - Convert dari Firestore
  - toFirestore() - Convert ke Firestore
  - copyWith() - Clone dengan perubahan
  
🔥 Firebase:
  - Collection: members
  - Digunakan di firestore_service.dart
```

---

### **transaction.dart**
```dart
📍 Lokasi: lib/models/transaction.dart
🎯 Fungsi: Model data transaksi peminjaman

📝 Properties:
  - id: String? (Firestore document ID)
  - bookId: String (reference ke books)
  - bookTitle: String (nama buku)
  - memberId: String (reference ke members)
  - memberName: String (nama anggota)
  - borrowDate: DateTime (tanggal pinjam)
  - dueDate: DateTime (tanggal jatuh tempo)
  - returnDate: DateTime? (tanggal kembali, nullable)
  - status: String (borrowed/returned/overdue)
  - createdAt: DateTime?
  
📋 Methods:
  - fromFirestore() - Convert dari Firestore
  - toFirestore() - Convert ke Firestore
  - copyWith() - Clone dengan perubahan
  - isOverdue() - Cek apakah terlambat
  
🔥 Firebase:
  - Collection: transactions
  - Digunakan di firestore_service.dart
```

---

## 🔧 SERVICES FOLDER

### **auth_service.dart**
```dart
📍 Lokasi: lib/services/auth_service.dart
🎯 Fungsi: Handle autentikasi user
🔥 Firebase: Firebase Auth + Cloud Firestore

📝 Properties:
  - _auth: FirebaseAuth instance
  - _db: Firestore instance
  - _currentUser: User? (user yang sedang login)
  
📋 Methods:
  1. login(username, password)
     - Login ke Firebase Auth
     - Ambil data dari Firestore users/{UID}
     - Simpan ke SharedPreferences
     - Return: bool (success/fail)
     
  2. logout()
     - Clear current user
     - Sign out dari Firebase Auth
     - Hapus SharedPreferences
     
  3. isLoggedIn()
     - Cek Firebase Auth currentUser
     - Cek Firestore users/{UID}
     - Fallback ke SharedPreferences
     - Return: bool
     
  4. getCurrentUser()
     - Return current user
     - Ambil dari cache atau Firestore
     - Return: User?
     
  5. registerUser(email, password, role, memberId)
     - Create user di Firebase Auth
     - Simpan data ke Firestore users/{UID}
     - Return: bool
     
🔄 Flow:
  Login → Firebase Auth → Firestore → SharedPreferences → Routing
  
🔥 Firebase Collections:
  - users/{UID}
```

---

### **firestore_service.dart**
```dart
📍 Lokasi: lib/services/firestore_service.dart
🎯 Fungsi: CRUD operations ke Firestore
🔥 Firebase: Cloud Firestore

📝 Properties:
  - _db: Firestore instance
  
📋 Methods - BOOKS:
  - getBooks() → Stream<QuerySnapshot>
  - addBook(Book book) → Future<void>
  - updateBook(String id, Book book) → Future<void>
  - deleteBook(String id) → Future<void>
  - getBookById(String id) → Future<Book?>
  
📋 Methods - MEMBERS:
  - getMembers() → Stream<QuerySnapshot>
  - addMember(Member member) → Future<void>
  - updateMember(String id, Member member) → Future<void>
  - deleteMember(String id) → Future<void>
  - getMemberById(String id) → Future<Member?>
  
📋 Methods - TRANSACTIONS:
  - getTransactions() → Stream<QuerySnapshot>
  - addTransaction(Transaction transaction) → Future<void>
  - updateTransaction(String id, Transaction transaction) → Future<void>
  - deleteTransaction(String id) → Future<void>
  - getTransactionsByMember(String memberId) → Stream<QuerySnapshot>
  - getTransactionsByBook(String bookId) → Stream<QuerySnapshot>
  
🔥 Firebase Collections:
  - books
  - members
  - transactions
  
⚡ Real-time:
  - Menggunakan snapshots() untuk real-time update
  - StreamBuilder di UI otomatis rebuild
```

---

### **pdf_service.dart**
```dart
📍 Lokasi: lib/services/pdf_service.dart
🎯 Fungsi: Generate laporan PDF
❌ Firebase: TIDAK menggunakan Firebase

📋 Methods:
  - generateBookReport(List<Book> books)
    - Generate PDF daftar buku
    - Return: File PDF
    
  - generateTransactionReport(List<Transaction> transactions)
    - Generate PDF laporan transaksi
    - Return: File PDF
    
  - generateMemberReport(List<Member> members)
    - Generate PDF daftar anggota
    - Return: File PDF
    
📦 Dependencies:
  - pdf: ^3.10.7
  - printing: ^5.12.0
```

---

## 🖥️ SCREENS FOLDER

### **login_screen.dart**
```dart
📍 Lokasi: lib/screens/login_screen.dart
🎯 Fungsi: Halaman login

📝 UI Components:
  - TextField email
  - TextField password
  - Button login
  - Gradient background
  
🔄 Flow:
  1. User input email & password
  2. Call AuthService.login()
  3. Jika berhasil:
     - Ambil user data
     - Cek role
     - Navigate ke AdminDashboard atau UserDashboard
  4. Jika gagal:
     - Show error message
     
🔥 Firebase:
  - Memanggil AuthService.login()
  - AuthService menggunakan Firebase Auth
```

---

### **admin/admin_dashboard.dart**
```dart
📍 Lokasi: lib/screens/admin/admin_dashboard.dart
🎯 Fungsi: Dashboard admin

📝 UI Components:
  - AppBar dengan gradient
  - Statistik cards (total buku, anggota, transaksi)
  - Menu grid (Kelola Buku, Anggota, Transaksi)
  - Logout button
  
🔄 Flow:
  1. Load data dari Firestore
  2. Hitung statistik
  3. Display cards
  4. Navigate ke screen sesuai menu
  
🔥 Firebase:
  - getBooks() untuk hitung total buku
  - getMembers() untuk hitung total anggota
  - getTransactions() untuk hitung total transaksi
  - Real-time update dengan StreamBuilder
```

---

### **admin/admin_books_screen.dart**
```dart
📍 Lokasi: lib/screens/admin/admin_books_screen.dart
🎯 Fungsi: Kelola data buku (CRUD)

📝 UI Components:
  - AppBar dengan search
  - ListView buku
  - FloatingActionButton tambah buku
  - Card untuk setiap buku
  - Button edit & delete
  
🔄 Flow:
  1. Load buku dari Firestore
  2. Display di ListView
  3. Search/filter buku
  4. Tambah → Navigate ke AdminBookFormScreen
  5. Edit → Navigate ke AdminBookFormScreen dengan data
  6. Delete → Confirm dialog → FirestoreService.deleteBook()
  
🔥 Firebase:
  - FirestoreService.getBooks() - Real-time stream
  - FirestoreService.deleteBook() - Delete
  - StreamBuilder untuk auto-update
```

---

### **admin/admin_book_form_screen.dart**
```dart
📍 Lokasi: lib/screens/admin/admin_book_form_screen.dart
🎯 Fungsi: Form tambah/edit buku

📝 UI Components:
  - TextField title
  - TextField author
  - TextField ISBN
  - TextField category
  - TextField stock
  - Button save
  
🔄 Flow:
  1. Jika edit: Load data buku
  2. User input data
  3. Validate form
  4. Jika tambah: FirestoreService.addBook()
  5. Jika edit: FirestoreService.updateBook()
  6. Navigate back
  
🔥 Firebase:
  - FirestoreService.addBook() - Create
  - FirestoreService.updateBook() - Update
```

---

### **admin/admin_members_screen.dart**
```dart
📍 Lokasi: lib/screens/admin/admin_members_screen.dart
🎯 Fungsi: Kelola data anggota (CRUD)

📝 UI Components:
  - AppBar dengan search
  - ListView anggota
  - FloatingActionButton tambah anggota
  - Card untuk setiap anggota
  - Button edit & delete
  
🔄 Flow:
  Similar dengan admin_books_screen.dart
  
🔥 Firebase:
  - FirestoreService.getMembers()
  - FirestoreService.deleteMember()
```

---

### **admin/admin_member_form_screen.dart**
```dart
📍 Lokasi: lib/screens/admin/admin_member_form_screen.dart
🎯 Fungsi: Form tambah/edit anggota

📝 UI Components:
  - TextField name
  - TextField email
  - TextField phone
  - TextField address
  - DatePicker membership date
  - Button save
  
🔄 Flow:
  Similar dengan admin_book_form_screen.dart
  
🔥 Firebase:
  - FirestoreService.addMember()
  - FirestoreService.updateMember()
```

---

### **admin/admin_transactions_screen.dart**
```dart
📍 Lokasi: lib/screens/admin/admin_transactions_screen.dart
🎯 Fungsi: Kelola transaksi peminjaman

📝 UI Components:
  - AppBar dengan filter
  - ListView transaksi
  - Card untuk setiap transaksi
  - Status badge (borrowed/returned/overdue)
  - Button approve/reject/complete
  
🔄 Flow:
  1. Load transaksi dari Firestore
  2. Display dengan status
  3. Filter by status
  4. Update status transaksi
  5. Update stok buku
  
🔥 Firebase:
  - FirestoreService.getTransactions()
  - FirestoreService.updateTransaction()
  - FirestoreService.updateBook() (untuk stok)
```

---

### **user/user_dashboard.dart**
```dart
📍 Lokasi: lib/screens/user/user_dashboard.dart
🎯 Fungsi: Dashboard user/anggota

📝 UI Components:
  - AppBar dengan greeting
  - Quick stats (buku dipinjam, tersedia)
  - Menu grid (Pinjam, Kembalikan, Riwayat)
  - Daftar buku tersedia
  - Logout button
  
🔄 Flow:
  1. Load data user
  2. Load transaksi user
  3. Load buku tersedia
  4. Display stats
  5. Navigate ke screen sesuai menu
  
🔥 Firebase:
  - getBooks() untuk buku tersedia
  - getTransactionsByMember() untuk transaksi user
  - Real-time update
```

---

### **user/user_borrow_screen.dart**
```dart
📍 Lokasi: lib/screens/user/user_borrow_screen.dart
🎯 Fungsi: Pinjam buku

📝 UI Components:
  - AppBar dengan search
  - ListView buku tersedia
  - Card untuk setiap buku
  - Button pinjam
  - DatePicker due date
  
🔄 Flow:
  1. Load buku dengan available > 0
  2. User pilih buku
  3. User pilih due date
  4. Create transaction
  5. Update stok buku (available - 1)
  6. Navigate back
  
🔥 Firebase:
  - FirestoreService.getBooks() where available > 0
  - FirestoreService.addTransaction()
  - FirestoreService.updateBook() (kurangi available)
```

---

### **user/user_return_screen.dart**
```dart
📍 Lokasi: lib/screens/user/user_return_screen.dart
🎯 Fungsi: Kembalikan buku

📝 UI Components:
  - AppBar
  - ListView buku yang dipinjam
  - Card untuk setiap transaksi
  - Button kembalikan
  - Status overdue (jika terlambat)
  
🔄 Flow:
  1. Load transaksi user dengan status borrowed
  2. User pilih buku yang mau dikembalikan
  3. Update transaction (status = returned, returnDate = now)
  4. Update stok buku (available + 1)
  5. Navigate back
  
🔥 Firebase:
  - FirestoreService.getTransactionsByMember() where status = borrowed
  - FirestoreService.updateTransaction()
  - FirestoreService.updateBook() (tambah available)
```

---

### **user/user_history_screen.dart**
```dart
📍 Lokasi: lib/screens/user/user_history_screen.dart
🎯 Fungsi: Riwayat peminjaman user

📝 UI Components:
  - AppBar
  - ListView transaksi
  - Card untuk setiap transaksi
  - Status badge
  - Filter by status
  
🔄 Flow:
  1. Load semua transaksi user
  2. Display dengan status
  3. Filter by status (all/borrowed/returned/overdue)
  4. Sort by date
  
🔥 Firebase:
  - FirestoreService.getTransactionsByMember()
  - Real-time update
```

---

## 🛠️ UTILS FOLDER

### **responsive_helper.dart**
```dart
📍 Lokasi: lib/utils/responsive_helper.dart
🎯 Fungsi: Helper untuk responsive design
❌ Firebase: TIDAK menggunakan Firebase

📋 Methods:
  - getResponsiveWidth(context, percentage)
  - getResponsiveHeight(context, percentage)
  - getResponsiveFontSize(context, size)
  - isTablet(context)
  - isMobile(context)
  - isDesktop(context)
  
💡 Note:
  Aplikasi ini menggunakan flutter_screenutil
  Helper ini untuk kasus khusus yang tidak covered oleh ScreenUtil
```

---

## 🗄️ DATABASE FOLDER

### **database_helper.dart**
```dart
📍 Lokasi: lib/database/database_helper.dart
🎯 Fungsi: SQLite local database (backup/offline)
❌ Firebase: TIDAK menggunakan Firebase (alternatif offline)

📝 Tables:
  - users
  - books
  - members
  - transactions
  
📋 Methods:
  - initDatabase()
  - insertUser/Book/Member/Transaction()
  - updateUser/Book/Member/Transaction()
  - deleteUser/Book/Member/Transaction()
  - getUsers/Books/Members/Transactions()
  
💡 Note:
  Database lokal sebagai backup jika offline
  Data utama tetap di Firestore
```

---

## 📊 SUMMARY

### **Total Files:**
- ✅ 22 file Dart
- ✅ 5 file dokumentasi
- ✅ 4 file konfigurasi Firebase

### **Firebase Usage:**
| File | Firebase Auth | Firestore | Storage |
|------|--------------|-----------|---------|
| main.dart | ✅ Init | ✅ Init | - |
| firebase_options.dart | ✅ Config | ✅ Config | ✅ Config |
| auth_service.dart | ✅ | ✅ | - |
| firestore_service.dart | - | ✅ | - |
| All screens | - | ✅ | - |

### **Komentar Status:**
- ✅ **main.dart** - LENGKAP
- 🔄 **Lainnya** - Akan ditambahkan

---

**Dibuat oleh:** Antigravity AI  
**Tanggal:** 10 Februari 2026  
**Project:** Perpustakaan SMKN12
