# 🔥 DOKUMENTASI RELASI FIREBASE

## 📋 DAFTAR ISI
1. [Apa itu Firebase?](#apa-itu-firebase)
2. [Firebase Services yang Digunakan](#firebase-services-yang-digunakan)
3. [Lokasi File Firebase](#lokasi-file-firebase)
4. [Alur Kerja Firebase](#alur-kerja-firebase)
5. [Penjelasan Detail Setiap File](#penjelasan-detail-setiap-file)
6. [Struktur Database Firestore](#struktur-database-firestore)
7. [Cara Kerja Autentikasi](#cara-kerja-autentikasi)

---

## 🎯 APA ITU FIREBASE?

**Firebase** adalah platform Backend-as-a-Service (BaaS) dari Google yang menyediakan berbagai layanan backend untuk aplikasi mobile dan web.

### **Keuntungan Menggunakan Firebase:**
- ✅ **Tidak perlu setup server sendiri** - Firebase sudah menyediakan server
- ✅ **Real-time database** - Data update otomatis tanpa refresh
- ✅ **Autentikasi built-in** - Login/register sudah disediakan
- ✅ **Gratis untuk project kecil** - Ada free tier yang cukup besar
- ✅ **Scalable** - Otomatis scale sesuai jumlah user
- ✅ **Cross-platform** - Bisa digunakan di Android, iOS, Web, Desktop

---

## 🔧 FIREBASE SERVICES YANG DIGUNAKAN

Aplikasi ini menggunakan 3 layanan Firebase:

### **1. Firebase Authentication (Auth)**
- **Fungsi:** Mengelola login, logout, dan register user
- **Fitur:**
  - Email & Password authentication
  - Session management (user tetap login)
  - Password reset
  - Email verification
- **Digunakan di:** `auth_service.dart`

### **2. Cloud Firestore (Database)**
- **Fungsi:** Database NoSQL untuk menyimpan data aplikasi
- **Fitur:**
  - Real-time sync (data update otomatis)
  - Offline support (data tersimpan lokal)
  - Query dan filter data
  - Relasi antar collection
- **Digunakan di:** `firestore_service.dart`, semua screens
- **Collections:**
  - `users` - Data user (role, username, dll)
  - `books` - Data buku perpustakaan
  - `members` - Data anggota perpustakaan
  - `transactions` - Data peminjaman/pengembalian

### **3. Firebase Core**
- **Fungsi:** Package dasar untuk inisialisasi Firebase
- **Digunakan di:** `main.dart`, `firebase_options.dart`

---

## 📁 LOKASI FILE FIREBASE

### **1. File Konfigurasi**

#### `firebase_options.dart`
```
📍 Lokasi: lib/firebase_options.dart
🎯 Fungsi: Menyimpan konfigurasi Firebase untuk semua platform
🔑 Isi: API keys, Project ID, App ID, dll
⚠️  JANGAN EDIT: File ini auto-generated oleh Firebase CLI
```

**Isi file:**
- `apiKey` - Kunci API untuk akses Firebase
- `appId` - ID aplikasi di Firebase
- `projectId` - ID project Firebase (`flutter-auth-test-d4606`)
- `messagingSenderId` - ID untuk push notification
- `storageBucket` - Bucket untuk Firebase Storage
- `authDomain` - Domain untuk autentikasi

**Platform yang didukung:**
- ✅ Web
- ✅ Android
- ✅ iOS
- ✅ macOS
- ✅ Windows
- ❌ Linux (belum dikonfigurasi)

#### `.firebaserc`
```
📍 Lokasi: .firebaserc (root project)
🎯 Fungsi: Menyimpan alias project Firebase
```

#### `firebase.json`
```
📍 Lokasi: firebase.json (root project)
🎯 Fungsi: Konfigurasi Firebase Hosting dan Firestore
```

#### `firestore.rules`
```
📍 Lokasi: firestore.rules (root project)
🎯 Fungsi: Security rules untuk Firestore database
```

#### `firestore.indexes.json`
```
📍 Lokasi: firestore.indexes.json (root project)
🎯 Fungsi: Konfigurasi index untuk query Firestore
```

### **2. File Service (Business Logic)**

#### `auth_service.dart`
```
📍 Lokasi: lib/services/auth_service.dart
🎯 Fungsi: Handle autentikasi user
🔥 Firebase: Firebase Auth + Firestore
```

**Methods:**
- `login()` - Login dengan email & password
- `logout()` - Logout user
- `isLoggedIn()` - Cek status login
- `getCurrentUser()` - Ambil data user yang login
- `registerUser()` - Daftar user baru

#### `firestore_service.dart`
```
📍 Lokasi: lib/services/firestore_service.dart
🎯 Fungsi: CRUD operations ke Firestore
🔥 Firebase: Cloud Firestore
```

**Methods:**
- Books: `addBook()`, `updateBook()`, `deleteBook()`, `getBooks()`
- Members: `addMember()`, `updateMember()`, `deleteMember()`, `getMembers()`
- Transactions: `addTransaction()`, `updateTransaction()`, `getTransactions()`

### **3. File Inisialisasi**

#### `main.dart`
```
📍 Lokasi: lib/main.dart
🎯 Fungsi: Entry point aplikasi
🔥 Firebase: Inisialisasi Firebase
```

**Kode inisialisasi:**
```dart
await Firebase.initializeApp(
  options: DefaultFirebaseOptions.currentPlatform
);
```

---

## 🔄 ALUR KERJA FIREBASE

### **1. Saat Aplikasi Dibuka (main.dart)**

```
┌─────────────────────────────────────────────────────────┐
│ 1. main() function dipanggil                           │
│    ↓                                                    │
│ 2. WidgetsFlutterBinding.ensureInitialized()           │
│    (Inisialisasi Flutter framework)                    │
│    ↓                                                    │
│ 3. Firebase.initializeApp()                            │
│    ├─ Baca firebase_options.dart                       │
│    ├─ Deteksi platform (Android/iOS/Web/Windows)       │
│    ├─ Ambil konfigurasi sesuai platform                │
│    └─ Koneksi ke Firebase project                      │
│    ↓                                                    │
│ 4. runApp(MyApp())                                      │
│    (Aplikasi siap digunakan)                           │
└─────────────────────────────────────────────────────────┘
```

### **2. Proses Login (auth_service.dart)**

```
┌─────────────────────────────────────────────────────────┐
│ USER INPUT                                              │
│ ├─ Email: admin@example.com                            │
│ └─ Password: ******                                     │
│    ↓                                                    │
│ FIREBASE AUTH                                           │
│ ├─ FirebaseAuth.signInWithEmailAndPassword()           │
│ ├─ Cek email & password di Firebase Auth               │
│ └─ Return: User UID (jika berhasil)                    │
│    ↓                                                    │
│ FIRESTORE QUERY                                         │
│ ├─ Query: users/{UID}                                   │
│ ├─ Ambil data: username, role, memberId                │
│ └─ Return: User object                                  │
│    ↓                                                    │
│ LOCAL STORAGE                                           │
│ ├─ Simpan di SharedPreferences                         │
│ ├─ Data: username, role, uid, memberId                 │
│ └─ Untuk auto-login next time                          │
│    ↓                                                    │
│ ROUTING                                                 │
│ ├─ Jika role == 'admin' → AdminDashboard               │
│ └─ Jika role == 'user' → UserDashboard                 │
└─────────────────────────────────────────────────────────┘
```

### **3. Proses CRUD Data (firestore_service.dart)**

#### **CREATE (Tambah Data)**
```
┌─────────────────────────────────────────────────────────┐
│ USER ACTION: Tambah buku baru                           │
│    ↓                                                    │
│ FIRESTORE SERVICE                                       │
│ ├─ Method: addBook(Book book)                          │
│ ├─ Convert: book.toFirestore()                         │
│ └─ Firestore: collection('books').add(data)            │
│    ↓                                                    │
│ FIREBASE CLOUD                                          │
│ ├─ Simpan data ke collection 'books'                   │
│ ├─ Generate auto ID                                    │
│ └─ Return: Document ID                                  │
│    ↓                                                    │
│ REAL-TIME UPDATE                                        │
│ ├─ StreamBuilder otomatis rebuild                      │
│ └─ UI update tanpa refresh manual                      │
└─────────────────────────────────────────────────────────┘
```

#### **READ (Ambil Data)**
```
┌─────────────────────────────────────────────────────────┐
│ UI: StreamBuilder<QuerySnapshot>                        │
│    ↓                                                    │
│ FIRESTORE SERVICE                                       │
│ ├─ Method: getBooks()                                   │
│ └─ Return: Stream<QuerySnapshot>                        │
│    ↓                                                    │
│ FIREBASE CLOUD                                          │
│ ├─ Query: collection('books').snapshots()              │
│ ├─ Listen to changes (real-time)                       │
│ └─ Return: Stream of documents                         │
│    ↓                                                    │
│ CONVERT TO MODEL                                        │
│ ├─ Loop: docs.map((doc) => Book.fromFirestore(doc))    │
│ └─ Return: List<Book>                                   │
│    ↓                                                    │
│ UI RENDER                                               │
│ └─ ListView.builder menampilkan data                   │
└─────────────────────────────────────────────────────────┘
```

#### **UPDATE (Edit Data)**
```
┌─────────────────────────────────────────────────────────┐
│ USER ACTION: Edit buku                                  │
│    ↓                                                    │
│ FIRESTORE SERVICE                                       │
│ ├─ Method: updateBook(String id, Book book)            │
│ ├─ Convert: book.toFirestore()                         │
│ └─ Firestore: doc('books/{id}').update(data)           │
│    ↓                                                    │
│ FIREBASE CLOUD                                          │
│ ├─ Update document di collection 'books'               │
│ └─ Trigger real-time update                            │
│    ↓                                                    │
│ REAL-TIME UPDATE                                        │
│ └─ UI otomatis update                                  │
└─────────────────────────────────────────────────────────┘
```

#### **DELETE (Hapus Data)**
```
┌─────────────────────────────────────────────────────────┐
│ USER ACTION: Hapus buku                                 │
│    ↓                                                    │
│ FIRESTORE SERVICE                                       │
│ ├─ Method: deleteBook(String id)                       │
│ └─ Firestore: doc('books/{id}').delete()               │
│    ↓                                                    │
│ FIREBASE CLOUD                                          │
│ ├─ Hapus document dari collection 'books'              │
│ └─ Trigger real-time update                            │
│    ↓                                                    │
│ REAL-TIME UPDATE                                        │
│ └─ UI otomatis update (buku hilang dari list)          │
└─────────────────────────────────────────────────────────┘
```

---

## 📄 PENJELASAN DETAIL SETIAP FILE

### **1. main.dart**

#### **Relasi Firebase:**
```dart
// Line 2: Import Firebase Core
import 'package:firebase_core/firebase_core.dart';

// Line 5: Import konfigurasi Firebase
import 'firebase_options.dart';

// Line 13: INISIALISASI FIREBASE
await Firebase.initializeApp(
  options: DefaultFirebaseOptions.currentPlatform
);
```

**Penjelasan:**
- `Firebase.initializeApp()` adalah function yang **WAJIB** dipanggil sebelum menggunakan Firebase
- `DefaultFirebaseOptions.currentPlatform` otomatis memilih konfigurasi sesuai platform
- Jika tidak dipanggil, semua Firebase service akan error

---

### **2. firebase_options.dart**

#### **Struktur File:**
```dart
class DefaultFirebaseOptions {
  // Getter untuk platform saat ini
  static FirebaseOptions get currentPlatform {
    if (kIsWeb) return web;           // Jika Web
    switch (defaultTargetPlatform) {
      case TargetPlatform.android:
        return android;                // Jika Android
      case TargetPlatform.iOS:
        return ios;                    // Jika iOS
      case TargetPlatform.windows:
        return windows;                // Jika Windows
      // dst...
    }
  }
  
  // Konfigurasi untuk Web
  static const FirebaseOptions web = FirebaseOptions(
    apiKey: 'AIzaSyB0mqkI1nitIsAMTLBeJ2qpfTHuqxrx1LI',
    appId: '1:322905594048:web:6716d327b03aae6935f525',
    projectId: 'flutter-auth-test-d4606',
    // ...
  );
  
  // Konfigurasi untuk Android
  static const FirebaseOptions android = FirebaseOptions(
    apiKey: 'AIzaSyDIhRpcbbKvaNx6toJcyegELO6N66vytec',
    appId: '1:322905594048:android:a3693d6929b0f18a35f525',
    projectId: 'flutter-auth-test-d4606',
    // ...
  );
  
  // dst untuk iOS, macOS, Windows...
}
```

**Penjelasan:**
- File ini **auto-generated** oleh Firebase CLI
- Setiap platform punya API key berbeda
- `projectId` sama untuk semua platform: `flutter-auth-test-d4606`
- **JANGAN EDIT MANUAL** - Gunakan Firebase CLI untuk update

---

### **3. auth_service.dart**

#### **Import Firebase:**
```dart
// Line 1: Firebase Authentication
import 'package:firebase_auth/firebase_auth.dart' as fb_auth;

// Line 2: Cloud Firestore
import 'package:cloud_firestore/cloud_firestore.dart';
```

#### **Instance Firebase:**
```dart
class AuthService {
  // Instance Firebase Auth
  final fb_auth.FirebaseAuth _auth = fb_auth.FirebaseAuth.instance;
  
  // Instance Firestore
  final FirebaseFirestore _db = FirebaseFirestore.instance;
}
```

#### **Method: login()**
```dart
Future<bool> login(String username, String password) async {
  // 1. LOGIN KE FIREBASE AUTH
  final cred = await _auth.signInWithEmailAndPassword(
    email: username.trim(),
    password: password,
  );
  
  // 2. AMBIL USER ID
  final fb_auth.User? fbUser = cred.user;
  
  // 3. QUERY FIRESTORE
  final userRef = _db.collection('users').doc(fbUser.uid);
  final doc = await userRef.get();
  
  // 4. AMBIL DATA USER
  if (doc.exists) {
    final data = doc.data()!;
    _currentUser = User(
      username: data['username'],
      role: data['role'],
      memberId: data['memberId'],
    );
    
    // 5. SIMPAN KE LOCAL STORAGE
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('username', _currentUser!.username);
    await prefs.setString('role', _currentUser!.role);
    
    return true;
  }
  return false;
}
```

**Alur:**
1. Login ke Firebase Auth dengan email & password
2. Dapat User UID dari Firebase Auth
3. Query Firestore collection `users` dengan UID
4. Ambil data user (username, role, memberId)
5. Simpan ke SharedPreferences untuk auto-login
6. Return true jika berhasil

#### **Method: logout()**
```dart
Future<void> logout() async {
  // 1. Clear current user
  _currentUser = null;
  
  // 2. Logout dari Firebase Auth
  await _auth.signOut();
  
  // 3. Hapus data dari SharedPreferences
  final prefs = await SharedPreferences.getInstance();
  await prefs.remove('username');
  await prefs.remove('role');
  await prefs.remove('uid');
  await prefs.remove('memberId');
}
```

#### **Method: isLoggedIn()**
```dart
Future<bool> isLoggedIn() async {
  // 1. Cek Firebase Auth
  final fb_auth.User? fbUser = _auth.currentUser;
  
  if (fbUser != null) {
    // 2. Ambil data dari Firestore
    final doc = await _db.collection('users').doc(fbUser.uid).get();
    
    if (doc.exists) {
      // 3. Set current user
      final data = doc.data()!;
      _currentUser = User(
        username: data['username'],
        role: data['role'],
        memberId: data['memberId'],
      );
      return true;
    }
  }
  
  // 4. Fallback: Cek SharedPreferences
  final prefs = await SharedPreferences.getInstance();
  final username = prefs.getString('username');
  return username != null;
}
```

**Alur:**
1. Cek apakah ada user login di Firebase Auth
2. Jika ada, ambil data dari Firestore
3. Jika tidak ada, cek SharedPreferences (offline)
4. Return true jika ada user login

#### **Method: registerUser()**
```dart
Future<bool> registerUser({
  required String email,
  required String password,
  required String role,
  String? memberId,
}) async {
  // 1. CREATE USER DI FIREBASE AUTH
  final cred = await _auth.createUserWithEmailAndPassword(
    email: email,
    password: password,
  );
  
  // 2. SIMPAN DATA KE FIRESTORE
  final fb_auth.User? fbUser = cred.user;
  if (fbUser != null) {
    await _db.collection('users').doc(fbUser.uid).set({
      'username': email,
      'role': role,
      'memberId': memberId,
      'created_at': FieldValue.serverTimestamp(),
    });
    return true;
  }
  return false;
}
```

**Alur:**
1. Create user baru di Firebase Auth
2. Dapat User UID
3. Simpan data user ke Firestore collection `users`
4. Return true jika berhasil

---

### **4. firestore_service.dart**

#### **Import Firebase:**
```dart
import 'package:cloud_firestore/cloud_firestore.dart';
```

#### **Instance Firestore:**
```dart
class FirestoreService {
  final FirebaseFirestore _db = FirebaseFirestore.instance;
}
```

#### **Method: getBooks() - READ**
```dart
Stream<QuerySnapshot> getBooks() {
  return _db
    .collection('books')        // Collection 'books'
    .orderBy('title')           // Sort by title
    .snapshots();               // Real-time stream
}
```

**Penjelasan:**
- `collection('books')` - Akses collection books
- `orderBy('title')` - Sort berdasarkan title
- `snapshots()` - Return Stream (real-time updates)
- Setiap ada perubahan di Firestore, Stream otomatis emit data baru

#### **Method: addBook() - CREATE**
```dart
Future<void> addBook(Book book) async {
  await _db.collection('books').add({
    'title': book.title,
    'author': book.author,
    'isbn': book.isbn,
    'category': book.category,
    'stock': book.stock,
    'available': book.available,
    'created_at': FieldValue.serverTimestamp(),
  });
}
```

**Penjelasan:**
- `add()` - Tambah document baru dengan auto-generated ID
- `FieldValue.serverTimestamp()` - Timestamp dari server Firebase

#### **Method: updateBook() - UPDATE**
```dart
Future<void> updateBook(String id, Book book) async {
  await _db.collection('books').doc(id).update({
    'title': book.title,
    'author': book.author,
    'isbn': book.isbn,
    'category': book.category,
    'stock': book.stock,
    'available': book.available,
    'updated_at': FieldValue.serverTimestamp(),
  });
}
```

**Penjelasan:**
- `doc(id)` - Akses document dengan ID tertentu
- `update()` - Update field yang disebutkan saja

#### **Method: deleteBook() - DELETE**
```dart
Future<void> deleteBook(String id) async {
  await _db.collection('books').doc(id).delete();
}
```

**Penjelasan:**
- `delete()` - Hapus document dari Firestore

---

## 🗄️ STRUKTUR DATABASE FIRESTORE

### **Collection: users**
```
users/
  └── {UID dari Firebase Auth}/
      ├── username: string (email user)
      ├── role: string ("admin" atau "user")
      ├── memberId: string (nullable, ID anggota jika role=user)
      └── created_at: Timestamp
```

**Contoh Document:**
```json
{
  "username": "admin@example.com",
  "role": "admin",
  "memberId": null,
  "created_at": "2026-02-10T09:00:00Z"
}
```

### **Collection: books**
```
books/
  └── {auto-generated ID}/
      ├── title: string
      ├── author: string
      ├── isbn: string
      ├── category: string
      ├── stock: number
      ├── available: number
      ├── created_at: Timestamp
      └── updated_at: Timestamp
```

**Contoh Document:**
```json
{
  "title": "Harry Potter and the Philosopher's Stone",
  "author": "J.K. Rowling",
  "isbn": "978-0-7475-3269-9",
  "category": "Fiction",
  "stock": 10,
  "available": 8,
  "created_at": "2026-02-10T09:00:00Z",
  "updated_at": "2026-02-10T10:00:00Z"
}
```

### **Collection: members**
```
members/
  └── {auto-generated ID}/
      ├── name: string
      ├── email: string
      ├── phone: string
      ├── address: string
      ├── membershipDate: Timestamp
      └── created_at: Timestamp
```

**Contoh Document:**
```json
{
  "name": "John Doe",
  "email": "john@example.com",
  "phone": "081234567890",
  "address": "Jl. Contoh No. 123",
  "membershipDate": "2026-01-01T00:00:00Z",
  "created_at": "2026-01-01T00:00:00Z"
}
```

### **Collection: transactions**
```
transactions/
  └── {auto-generated ID}/
      ├── bookId: string (reference ke books)
      ├── bookTitle: string
      ├── memberId: string (reference ke members)
      ├── memberName: string
      ├── borrowDate: Timestamp
      ├── dueDate: Timestamp
      ├── returnDate: Timestamp (nullable)
      ├── status: string ("borrowed", "returned", "overdue")
      └── created_at: Timestamp
```

**Contoh Document:**
```json
{
  "bookId": "abc123",
  "bookTitle": "Harry Potter",
  "memberId": "xyz789",
  "memberName": "John Doe",
  "borrowDate": "2026-02-01T00:00:00Z",
  "dueDate": "2026-02-15T00:00:00Z",
  "returnDate": null,
  "status": "borrowed",
  "created_at": "2026-02-01T00:00:00Z"
}
```

---

## 🔐 CARA KERJA AUTENTIKASI

### **1. Register User Baru**
```
Admin Input:
├─ Email: user@example.com
├─ Password: password123
└─ Role: user
   ↓
Firebase Auth:
├─ createUserWithEmailAndPassword()
├─ Hash password (otomatis)
└─ Return: User UID
   ↓
Firestore:
├─ Create document di users/{UID}
└─ Data: {username, role, memberId, created_at}
```

### **2. Login**
```
User Input:
├─ Email: user@example.com
└─ Password: password123
   ↓
Firebase Auth:
├─ signInWithEmailAndPassword()
├─ Verify email & password
└─ Return: User UID + Session Token
   ↓
Firestore:
├─ Query: users/{UID}
└─ Return: {username, role, memberId}
   ↓
SharedPreferences:
└─ Save: {username, role, uid, memberId}
   ↓
Routing:
├─ If role == 'admin' → AdminDashboard
└─ If role == 'user' → UserDashboard
```

### **3. Auto-Login (App Restart)**
```
App Start:
   ↓
SplashScreen:
├─ _checkLoginStatus()
└─ AuthService.isLoggedIn()
   ↓
Firebase Auth:
├─ Check: currentUser
└─ If exists → User UID
   ↓
Firestore:
├─ Query: users/{UID}
└─ Return: {username, role, memberId}
   ↓
Routing:
├─ If role == 'admin' → AdminDashboard
└─ If role == 'user' → UserDashboard
```

### **4. Logout**
```
User Click Logout:
   ↓
AuthService.logout():
├─ _currentUser = null
├─ FirebaseAuth.signOut()
└─ SharedPreferences.clear()
   ↓
Routing:
└─ Navigate to LoginScreen
```

---

## 📊 DIAGRAM RELASI FIREBASE

```
┌─────────────────────────────────────────────────────────────────┐
│                         APLIKASI FLUTTER                        │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  ┌──────────────┐                                               │
│  │  main.dart   │                                               │
│  │              │                                               │
│  │ Firebase.    │                                               │
│  │ initializeApp│────────┐                                      │
│  └──────────────┘        │                                      │
│                          ▼                                      │
│              ┌────────────────────────┐                         │
│              │ firebase_options.dart  │                         │
│              │                        │                         │
│              │ - API Keys             │                         │
│              │ - Project ID           │                         │
│              │ - Platform configs     │                         │
│              └────────────────────────┘                         │
│                          │                                      │
│                          ▼                                      │
│  ┌───────────────────────────────────────────────────┐          │
│  │              FIREBASE SERVICES                    │          │
│  ├───────────────────────────────────────────────────┤          │
│  │                                                   │          │
│  │  ┌─────────────────┐    ┌──────────────────────┐ │          │
│  │  │ Firebase Auth   │    │  Cloud Firestore     │ │          │
│  │  │                 │    │                      │ │          │
│  │  │ - Login         │    │  Collections:        │ │          │
│  │  │ - Logout        │    │  ├─ users            │ │          │
│  │  │ - Register      │    │  ├─ books            │ │          │
│  │  │ - Session       │    │  ├─ members          │ │          │
│  │  └─────────────────┘    │  └─ transactions     │ │          │
│  │          │               └──────────────────────┘ │          │
│  │          │                          │             │          │
│  └──────────┼──────────────────────────┼─────────────┘          │
│             │                          │                        │
│             ▼                          ▼                        │
│  ┌──────────────────┐      ┌──────────────────────┐            │
│  │ auth_service.dart│      │ firestore_service.dart│            │
│  │                  │      │                       │            │
│  │ - login()        │      │ - getBooks()          │            │
│  │ - logout()       │      │ - addBook()           │            │
│  │ - isLoggedIn()   │      │ - updateBook()        │            │
│  │ - getCurrentUser()      │ - deleteBook()        │            │
│  │ - registerUser() │      │ - getMembers()        │            │
│  └──────────────────┘      │ - addMember()         │            │
│             │               │ - etc...              │            │
│             │               └──────────────────────┘            │
│             │                          │                        │
│             ▼                          ▼                        │
│  ┌─────────────────────────────────────────────────┐            │
│  │                   SCREENS                       │            │
│  ├─────────────────────────────────────────────────┤            │
│  │                                                 │            │
│  │  - LoginScreen                                  │            │
│  │  - AdminDashboard                               │            │
│  │  - UserDashboard                                │            │
│  │  - AdminBooksScreen                             │            │
│  │  - UserBorrowScreen                             │            │
│  │  - etc...                                       │            │
│  │                                                 │            │
│  └─────────────────────────────────────────────────┘            │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
                    ┌──────────────────┐
                    │  FIREBASE CLOUD  │
                    │                  │
                    │  - Authentication│
                    │  - Firestore DB  │
                    │  - Storage       │
                    └──────────────────┘
```

---

## 🎓 KESIMPULAN

### **Firebase digunakan di:**
1. ✅ **main.dart** - Inisialisasi Firebase
2. ✅ **firebase_options.dart** - Konfigurasi Firebase
3. ✅ **auth_service.dart** - Autentikasi (Firebase Auth + Firestore)
4. ✅ **firestore_service.dart** - CRUD data (Firestore)
5. ✅ **Semua screens** - Menampilkan data dari Firestore

### **Alur Data:**
```
UI (Screens)
    ↕️
Services (auth_service, firestore_service)
    ↕️
Firebase SDK (firebase_auth, cloud_firestore)
    ↕️
Firebase Cloud (Authentication, Firestore Database)
```

### **Keuntungan Arsitektur Ini:**
- ✅ **Separation of Concerns** - UI terpisah dari business logic
- ✅ **Reusable** - Service bisa digunakan di banyak screen
- ✅ **Testable** - Service bisa di-test terpisah
- ✅ **Maintainable** - Mudah di-maintain dan di-update
- ✅ **Scalable** - Mudah ditambah fitur baru

---

**Dibuat oleh:** Antigravity AI  
**Tanggal:** 10 Februari 2026  
**Project:** Perpustakaan SMKN12
