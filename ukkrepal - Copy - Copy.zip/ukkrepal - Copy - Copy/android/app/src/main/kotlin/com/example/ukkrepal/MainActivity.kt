package com.example.ukkrepal

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
