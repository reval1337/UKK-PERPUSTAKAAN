# 🚀 Firebase Storage untuk Profil Siswa

## 📋 Daftar Isi
1. [Apa itu Firebase Storage?](#apa-itu-firebase-storage)
2. [Setup Firebase Storage](#setup-firebase-storage)
3. [Struktur Folder di Storage](#struktur-folder-di-storage)
4. [Cara Penggunaan di Flutter](#cara-penggunaan-di-flutter)
5. [Firebase Security Rules](#firebase-security-rules)
6. [Troubleshooting](#troubleshooting)

---

## 🔥 Apa itu Firebase Storage?

**Firebase Storage** adalah layanan untuk menyimpan dan menyajikan file pengguna seperti foto, video, dan dokumen di cloud Firebase.

### Keuntungan:
- ✅ **Gratis** (Free tier 5GB)
- ✅ **Secure** dengan Firebase Security Rules
- ✅ **Scalable** - otomatis scale sesuai kebutuhan
- ✅ **Fast** - CDN global untuk loading cepat
- ✅ **Real-time** - upload progress dapat dilacak

---

## ⚙️ Setup Firebase Storage

### Langkah 1: Aktifkan Firebase Storage di Console

1. Buka [Firebase Console](https://console.firebase.google.com/)
2. Pilih project Anda (`flutter-auth-test-d4606`)
3. Di menu kiri, klik **Build** → **Storage**
4. Klik **Get Started**
5. Pilih lokasi storage (sesuaikan dengan lokasi server)
6. Klik **Done**

### Langkah 2: Setup Security Rules (PENTING!)

Di Firebase Console → Storage → **Rules**

```javascript
// rules untuk profile_photos
rules_version = '2';
service firebase.storage {
  match /b/{bucket}/o {
    // Allow anyone to read profile photos
    match /profile_photos/{allPaths=**} {
      allow read: if true;
      allow write: if request.auth != null 
                   && request.resource.size < 2 * 1024 * 1024  // Max 2MB
                   && request.resource.contentType.matches('image/.*')
                   && request.auth.uid == request.resource.name.split('_')[0];
    }
    
    // Allow all authenticated users to read, only owner can write
    match /users/{userId}/{allPaths=**} {
      allow read: if request.auth != null;
      allow write: if request.auth != null && request.auth.uid == userId;
    }
  }
}
```

### Langkah 3: Setup CORS (untuk Web)

Buat file `storage_cors.json` di root project:

```json
[
  {
    "origin": ["http://localhost:5000", "http://localhost:8080"],
    "method": ["GET", "POST", "PUT", "DELETE", "HEAD"],
    "maxAgeSeconds": 3600
  }
]
```

Jalankan command:
```bash
gsutil cors set storage_cors.json gs://flutter-auth-test-d4606.appspot.com
```

---

## 📁 Struktur Folder di Storage

```
flutter-auth-test-d4606.appspot.com/
├── profile_photos/
│   ├── userId_1707500000000.jpg    # Foto profil siswa
│   ├── userId_1707500000001.jpg
│   └── ...
└── books/
    ├── book_cover_1.jpg
    └── book_cover_2.jpg
```

### Penjelasan:
- **profile_photos/**: Folder khusus untuk foto profil siswa
- **Naming Convention**: `{userId}_{timestamp}.jpg`
  - `userId`: ID user dari Firebase Auth
  - `timestamp`: Waktu upload dalam milliseconds

---

## 💻 Cara Penggunaan di Flutter

### 1. Import Dependencies

 Pastikan di `pubspec.yaml` sudah ada:

```yaml
dependencies:
  firebase_storage: ^13.0.6
  image_picker: ^1.0.7
```

### 2. Penggunaan Dasar

```dart
import 'dart:io';
import 'package:image_picker/image_picker.dart';
import 'package:firebase_storage/firebase_storage.dart';
import '../../services/profile_storage_service.dart';

class ProfileService {
  final _storage = ProfileStorageService.instance;

  /// Upload foto profil
  Future<String> uploadProfilePhoto(String userId, File imageFile) async {
    try {
      final url = await _storage.uploadProfilePhoto(
        userId: userId,
        imageFile: imageFile,
      );
      return url;
    } catch (e) {
      throw Exception('Upload gagal: $e');
    }
  }

  /// Update foto profil (hapus lama, upload baru)
  Future<String> updateProfilePhoto(String userId, File newPhoto, String? oldPhotoUrl) async {
    try {
      final url = await _storage.updateProfilePhoto(
        userId: userId,
        newImageFile: newPhoto,
        oldPhotoUrl: oldPhotoUrl,
      );
      return url;
    } catch (e) {
      throw Exception('Update gagal: $e');
    }
  }
}
```

### 3. Contoh Penggunaan di UI

```dart
class UserProfileScreen extends StatefulWidget {
  const UserProfileScreen({super.key});

  @override
  State<UserProfileScreen> createState() => _UserProfileScreenState();
}

class _UserProfileScreenState extends State<UserProfileScreen> {
  final _storage = ProfileStorageService.instance;
  final _auth = AuthService.instance;
  final _firestore = FirestoreService.instance;
  
  bool _isUploading = false;

  Future<void> _pickAndUploadImage() async {
    final ImagePicker picker = ImagePicker();
    
    // Pilih gambar dari galeri
    final XFile? image = await picker.pickImage(
      source: ImageSource.gallery,
      maxWidth: 512,
      maxHeight: 512,
      imageQuality: 75,
    );
    
    if (image == null) return;
    
    setState(() => _isUploading = true);
    
    try {
      final user = _auth.currentUser;
      if (user == null) return;

      // Upload ke Firebase Storage
      final downloadUrl = await _storage.uploadProfilePhotoWithResize(
        userId: user.id!,
        imagePath: image.path,
      );

      // Update URL di Firestore
      await _firestore.updateUser(user.id!, {
        'photo_url': downloadUrl,
      });

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Foto profil berhasil diperbarui!')),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Gagal: $e')),
        );
      }
    } finally {
      setState(() => _isUploading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          // Foto Profil dengan Edit Button
          Stack(
            children: [
              // Tampilkan foto dari URL atau avatar default
              _currentUser?.photoUrl != null
                  ? ClipOval(
                      child: Image.network(
                        _currentUser!.photoUrl!,
                        width: 140,
                        height: 140,
                        fit: BoxFit.cover,
                        errorBuilder: (context, error, stackTrace) {
                          return _buildDefaultAvatar();
                        },
                      ),
                    )
                  : _buildDefaultAvatar(),
              
              // Edit Button
              Positioned(
                bottom: 0,
                right: 0,
                child: GestureDetector(
                  onTap: _isUploading ? null : _pickAndUploadImage,
                  child: Container(
                    padding: const EdgeInsets.all(8),
                    decoration: const BoxDecoration(
                      color: Color(0xFF6366F1),
                      shape: BoxShape.circle,
                    ),
                    child: _isUploading
                        ? const CircularProgressIndicator(strokeWidth: 2)
                        : const Icon(Icons.camera_alt, color: Colors.white),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
```

---

## 🔐 Firebase Security Rules (Lanjutan)

### Untuk Development:
```javascript
rules_version = '2';
service firebase.storage {
  match /b/{bucket}/o {
    match /profile_photos/{allPaths=**} {
      allow read: if true;
      allow write: if request.auth != null 
                   && request.resource.size < 2 * 1024 * 1024
                   && request.resource.contentType.matches('image/.*');
    }
  }
}
```

### Untuk Production (lebih ketat):
```javascript
rules_version = '2';
service firebase.storage {
  match /b/{bucket}/o {
    match /profile_photos/{userId}/{fileName} {
      allow read: if true;
      allow write: if request.auth != null
                   && request.auth.uid == userId
                   && request.resource.size < 2 * 1024 * 1024
                   && request.resource.contentType.matches('image/.*')
                   && fileName.matches(request.auth.uid + '_[0-9]+.jpg');
    }
  }
}
```

---

## 🐛 Troubleshooting

### Error: "Permission denied"

**Penyebab:** Security Rules tidak mengizinkan akses

**Solusi:**
1.cek Rules di Firebase Console
2.Pastikan user sudah login sebelum upload
3.Tambahkan logging untuk debugging

### Error: "Network error"

**Penyebab:** Koneksi internet bermasalah

**Solusi:**
1.Cek koneksi internet
2.Tambahkan retry mechanism
3.Tampilkan error message yang jelas ke user

### Error: "File too large"

**Penyebab:** File > 2MB

**Solusi:**
1.Resize gambar sebelum upload
2.Compress gambar dengan quality lebih rendah
3.Batas maksimal di Rules: 2MB

### Error: "Invalid file type"

**Penyebab:** Bukan file gambar

**Solusi:**
1.Pastikan menggunakan `image_picker` yang benar
2.Cek contentType di metadata
3.Format yang didukung: JPEG, PNG, GIF, WebP

---

## 📊 Best Practices

1. **Resize sebelum upload** - Gunakan maxWidth 512px untuk foto profil
2. **Compress gambar** - Quality 75% sudah cukup untuk foto profil
3. **Naming convention** - Gunakan `{userId}_{timestamp}.jpg`
4. **Hapus foto lama** - Saat update foto, hapus foto lama
5. **Loading state** - Selalu tampilkan progress saat upload
6. **Error handling** - Tangani semua kemungkinan error
7. **Security Rules** - Gunakan rules yang ketat di production

---

## 📚 Referensi

- [Firebase Storage Documentation](https://firebase.google.com/docs/storage)
- [Firebase Storage Flutter](https://firebase.flutter.dev/docs/storage/overview/)
- [Image Picker Flutter](https://pub.dev/packages/image_picker)
