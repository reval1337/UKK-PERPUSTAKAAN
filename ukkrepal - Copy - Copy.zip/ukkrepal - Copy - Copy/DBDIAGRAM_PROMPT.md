# Prompt untuk dbdiagram.io

Copy dan paste prompt berikut ke AI (ChatGPT, Claude, dll) untuk generate schema database perpustakaan:

---

## Prompt:

```
Buatkan schema database untuk aplikasi perpustakaan sekolah dengan fitur berikut:

1. Users (Admin & Siswa)
   - id, username, password, role (admin/user), created_at

2. Members (Anggota Perpustakaan)
   - id, nis, nama, kelas, alamat, telepon, email, created_at

3. Books (Buku)
   - id, isbn, judul, penulis, penerbit, tahun_terbit, kategori, stok, deskripsi, cover_url, created_at

4. Categories (Kategori Buku)
   - id, nama_kategori, deskripsi

5. Transactions (Peminjaman/Pengembalian)
   - id, user_id, member_id, book_id, tanggal_pinjam, tanggal_kembali, status (dipinjam/dikembalikan/terlambat), denda

6. Profile Photos (Firebase Storage)
   - user_id, photo_url, uploaded_at

Relasi:
- Users 1:M Transactions (satu user bisa banyak transaksi)
- Members 1:M Transactions (satu anggota banyak transaksi)
- Books 1:M Transactions (satu buku banyak transaksi)
- Categories 1:M Books (satu kategori banyak buku)

Format output dalam syntax dbdiagram.io:
```

Contoh output yang diharapkan:

```
// Users Table
Table users as U {
  id string [pk]
  username string
  password string
  role string [note: "admin or user"]
  bio string
  photo_url string
  created_at timestamp
}

// Members Table
Table members as M {
  id string [pk]
  nis string
  nama string
  kelas string
  alamat string
  telepon string
  email string
  created_at timestamp
}

// Books Table
Table books as B {
  id string [pk]
  isbn string
  judul string
  penulis string
  penerbit string
  tahun_terbit int
  kategori_id string [ref: > C.id]
  stok int
  deskripsi string
  cover_url string
  created_at timestamp
}

// Categories Table
Table categories as C {
  id string [pk]
  nama_kategori string
  deskripsi string
}

// Transactions Table
Table transactions as T {
  id string [pk]
  user_id string [ref: > U.id]
  member_id string [ref: > M.id]
  book_id string [ref: > B.id]
  tanggal_pinjam date
  tanggal_kembali date
  status string [note: "dipinjam/dikembalikan/terlambat"]
  denda decimal
  created_at timestamp
}

// Profile Photos (Firebase Storage)
Table profile_photos as PP {
  user_id string [pk, ref: > U.id]
  photo_url string
  uploaded_at timestamp
}

// Relationships
Ref: U.id < T.user_id
Ref: M.id < T.member_id
Ref: B.id < T.book_id
Ref: C.id < B.kategori_id
```

---
## Cara Menggunakan di dbdiagram.io:

1. Buka [dbdiagram.io](https://dbdiagram.io/)
2. Klik "Import" → "Import from text"
3. Paste code di atas
4. Klik "Import"
5. Export sebagai PNG/PDF jika perlu
