# 📚 APLIKASI PERPUSTAKAAN SMKN12

Sistem Manajemen Perpustakaan Digital berbasis Flutter dengan Firebase Backend

---

## 📖 DOKUMENTASI LENGKAP

Aplikasi ini dilengkapi dengan dokumentasi lengkap untuk memudahkan pemahaman:

### **1. 📘 DOKUMENTASI_LENGKAP.md**
**Dokumentasi utama aplikasi**
- ✅ Penjelasan lengkap `main.dart` dan kegunaannya
- ✅ Struktur project dan folder
- ✅ Penjelasan setiap file dan fungsinya
- ✅ Flow aplikasi dari awal sampai akhir
- ✅ Dependencies yang digunakan

👉 **[Buka DOKUMENTASI_LENGKAP.md](./DOKUMENTASI_LENGKAP.md)**

### **2. 🔥 FIREBASE_RELASI.md**
**Dokumentasi khusus Firebase**
- ✅ Apa itu Firebase dan kenapa digunakan
- ✅ Firebase services yang dipakai (Auth, Firestore)
- ✅ Lokasi file Firebase di project
- ✅ Alur kerja Firebase (login, CRUD, dll)
- ✅ Struktur database Firestore
- ✅ Cara kerja autentikasi
- ✅ Diagram relasi Firebase

👉 **[Buka FIREBASE_RELASI.md](./FIREBASE_RELASI.md)**

### **3. 📊 ERD_PERPUSTAKAAN.md**
**Entity Relationship Diagram**
- ✅ Struktur database
- ✅ Relasi antar tabel
- ✅ Field dan tipe data

👉 **[Buka ERD_PERPUSTAKAAN.md](./ERD_PERPUSTAKAAN.md)**

### **4. 📋 LAPORAN_PERPUSTAKAAN.md**
**Laporan project**
- ✅ Deskripsi aplikasi
- ✅ Fitur-fitur
- ✅ Teknologi yang digunakan
- ✅ Screenshot aplikasi

👉 **[Buka LAPORAN_PERPUSTAKAAN.md](./LAPORAN_PERPUSTAKAAN.md)**

### **5. 🎨 UI_UX_ENHANCEMENTS.md**
**Dokumentasi UI/UX**
- ✅ Design system
- ✅ Color palette
- ✅ Typography
- ✅ Components

👉 **[Buka UI_UX_ENHANCEMENTS.md](./UI_UX_ENHANCEMENTS.md)**

---

## 🚀 QUICK START

### **1. Install Dependencies**
```bash
flutter pub get
```

### **2. Jalankan Aplikasi**
```bash
flutter run
```

### **3. Login**
**Admin:**
- Email: `admin@example.com`
- Password: (sesuai yang didaftarkan di Firebase)

**User:**
- Email: `user@example.com`
- Password: (sesuai yang didaftarkan di Firebase)

---

## 📁 STRUKTUR PROJECT

```
lib/
├── main.dart                    # Entry point aplikasi (SUDAH ADA KOMENTAR LENGKAP ✅)
├── firebase_options.dart        # Konfigurasi Firebase
│
├── models/                      # Data models
│   ├── user.dart
│   ├── book.dart
│   ├── member.dart
│   └── transaction.dart
│
├── services/                    # Business logic
│   ├── auth_service.dart        # Autentikasi Firebase
│   ├── firestore_service.dart   # CRUD Firestore
│   └── pdf_service.dart         # Generate PDF
│
├── screens/                     # UI Screens
│   ├── login_screen.dart
│   ├── admin/                   # Admin screens
│   │   ├── admin_dashboard.dart
│   │   ├── admin_books_screen.dart
│   │   ├── admin_members_screen.dart
│   │   └── admin_transactions_screen.dart
│   └── user/                    # User screens
│       ├── user_dashboard.dart
│       ├── user_borrow_screen.dart
│       ├── user_return_screen.dart
│       └── user_history_screen.dart
│
└── utils/
    └── responsive_helper.dart
```

---

## 🔥 FIREBASE SETUP

### **Collections di Firestore:**

#### **1. users**
```
users/{UID}
  ├── username: string
  ├── role: string (admin/user)
  ├── memberId: string
  └── created_at: Timestamp
```

#### **2. books**
```
books/{ID}
  ├── title: string
  ├── author: string
  ├── isbn: string
  ├── category: string
  ├── stock: number
  ├── available: number
  └── created_at: Timestamp
```

#### **3. members**
```
members/{ID}
  ├── name: string
  ├── email: string
  ├── phone: string
  ├── address: string
  └── membershipDate: Timestamp
```

#### **4. transactions**
```
transactions/{ID}
  ├── bookId: string
  ├── bookTitle: string
  ├── memberId: string
  ├── memberName: string
  ├── borrowDate: Timestamp
  ├── dueDate: Timestamp
  ├── returnDate: Timestamp
  ├── status: string
  └── created_at: Timestamp
```

---

## 🎯 FITUR APLIKASI

### **Admin:**
- ✅ Dashboard dengan statistik
- ✅ Kelola buku (CRUD)
- ✅ Kelola anggota (CRUD)
- ✅ Kelola transaksi peminjaman
- ✅ Generate laporan PDF
- ✅ Real-time data update

### **User/Anggota:**
- ✅ Dashboard dengan daftar buku
- ✅ Pinjam buku
- ✅ Kembalikan buku
- ✅ Lihat riwayat peminjaman
- ✅ Real-time status peminjaman

---

## 🛠️ TEKNOLOGI

### **Framework & Language:**
- Flutter 3.8.1
- Dart

### **Backend:**
- Firebase Authentication
- Cloud Firestore
- Firebase Storage

### **UI/UX:**
- Material Design 3
- Google Fonts (Poppins)
- Flutter ScreenUtil (Responsive)
- Flutter Animate (Animasi)

### **Other:**
- PDF Generation
- Local Database (SQLite)
- Shared Preferences

---

## 📝 KOMENTAR DI KODE

### **File dengan Komentar Lengkap:**
- ✅ **main.dart** - Sudah ada komentar detail untuk setiap bagian

### **Yang Akan Ditambahkan:**
- 🔄 auth_service.dart
- 🔄 firestore_service.dart
- 🔄 Semua screens
- 🔄 Semua models

---

## 🎓 CARA BACA DOKUMENTASI

### **Untuk Pemula:**
1. Baca **DOKUMENTASI_LENGKAP.md** dulu
2. Pahami struktur project
3. Baca **FIREBASE_RELASI.md** untuk memahami backend
4. Lihat kode di `main.dart` (sudah ada komentar lengkap)

### **Untuk yang Sudah Paham Flutter:**
1. Baca **FIREBASE_RELASI.md** untuk memahami arsitektur
2. Lihat **ERD_PERPUSTAKAAN.md** untuk struktur database
3. Langsung baca kode dengan bantuan komentar

---

## 📞 KONTAK

**Developer:** SMKN12 Team  
**Project:** Perpustakaan Digital  
**Tahun:** 2026

---

## 📄 LICENSE

Copyright © 2026 SMKN12. All rights reserved.

---

**Dokumentasi dibuat oleh:** Antigravity AI  
**Tanggal:** 10 Februari 2026  
**Status:** ✅ Complete dengan komentar lengkap di main.dart
