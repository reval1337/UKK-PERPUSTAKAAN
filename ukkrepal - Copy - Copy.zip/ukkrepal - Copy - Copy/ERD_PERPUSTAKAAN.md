# 📊 Entity Relationship Diagram (ERD)
# Sistem Perpustakaan SMKN12

---

## 🎯 Overview

Dokumen ini menjelaskan struktur database untuk Sistem Manajemen Perpustakaan SMKN12, termasuk entitas, atribut, dan relasi antar entitas.

---

## 📦 Entitas dan Atribut

### 1. 👥 ANGGOTA (Member)

Entitas yang menyimpan informasi anggota perpustakaan.

| Atribut | Tipe Data | Keterangan | Constraint |
|---------|-----------|------------|------------|
| **id_anggota** | VARCHAR(20) | ID unik anggota | PRIMARY KEY |
| nama | VARCHAR(100) | Nama lengkap anggota | NOT NULL |
| alamat | TEXT | Alamat lengkap | - |
| telepon | VARCHAR(15) | Nomor telepon | - |
| email | VARCHAR(100) | Email anggota | UNIQUE |
| nis | VARCHAR(20) | Nomor Induk Siswa | UNIQUE |
| kelas | VARCHAR(20) | Kelas siswa | - |
| status | ENUM | Status: aktif/tidak aktif | DEFAULT 'aktif' |
| tanggal_daftar | DATE | Tanggal pendaftaran | DEFAULT CURRENT_DATE |

**Contoh Data:**
```
id_anggota: A001
nama: Budi Santoso
alamat: Jl. Merdeka No. 123, Jakarta
telepon: 081234567890
email: budi@smkn12.sch.id
nis: 12345
kelas: XII RPL 1
status: aktif
```

---

### 2. 📚 BUKU (Book)

Entitas yang menyimpan informasi koleksi buku perpustakaan.

| Atribut | Tipe Data | Keterangan | Constraint |
|---------|-----------|------------|------------|
| **id_buku** | VARCHAR(20) | ID unik buku | PRIMARY KEY |
| judul | VARCHAR(200) | Judul buku | NOT NULL |
| penulis | VARCHAR(100) | Nama penulis | NOT NULL |
| penerbit | VARCHAR(100) | Nama penerbit | - |
| tahun_terbit | YEAR | Tahun penerbitan | - |
| isbn | VARCHAR(20) | ISBN buku | UNIQUE |
| jumlah_halaman | INT | Jumlah halaman | - |
| stok | INT | Jumlah stok tersedia | DEFAULT 1 |
| status | ENUM | Status: tersedia/dipinjam/hilang | DEFAULT 'tersedia' |
| id_pengarang | VARCHAR(20) | ID pengarang | FOREIGN KEY |

**Contoh Data:**
```
id_buku: B001
judul: Pemrograman Flutter untuk Pemula
penulis: John Doe
penerbit: Gramedia
tahun_terbit: 2023
isbn: 978-602-1234-56-7
stok: 5
status: tersedia
```

---

### 3. 🔄 PEMINJAMAN (Borrowing)

Entitas yang menyimpan transaksi peminjaman buku.

| Atribut | Tipe Data | Keterangan | Constraint |
|---------|-----------|------------|------------|
| **id_peminjaman** | VARCHAR(20) | ID unik peminjaman | PRIMARY KEY |
| **id_anggota** | VARCHAR(20) | ID anggota peminjam | FOREIGN KEY |
| **id_buku** | VARCHAR(20) | ID buku dipinjam | FOREIGN KEY |
| tanggal_peminjaman | DATE | Tanggal pinjam | NOT NULL |
| tanggal_kembali | DATE | Tanggal harus kembali | NOT NULL |
| tanggal_pengembalian | DATE | Tanggal aktual kembali | NULL |
| status | ENUM | Status: dipinjam/dikembalikan/terlambat | DEFAULT 'dipinjam' |
| denda | DECIMAL(10,2) | Denda keterlambatan | DEFAULT 0 |

**Contoh Data:**
```
id_peminjaman: P001
id_anggota: A001
id_buku: B001
tanggal_peminjaman: 2026-02-01
tanggal_kembali: 2026-02-08
tanggal_pengembalian: NULL
status: dipinjam
denda: 0
```

---

### 4. ✍️ PENGARANG (Author)

Entitas yang menyimpan informasi pengarang buku.

| Atribut | Tipe Data | Keterangan | Constraint |
|---------|-----------|------------|------------|
| **id_pengarang** | VARCHAR(20) | ID unik pengarang | PRIMARY KEY |
| nama | VARCHAR(100) | Nama pengarang | NOT NULL |
| alamat | TEXT | Alamat pengarang | - |
| telepon | VARCHAR(15) | Nomor telepon | - |
| email | VARCHAR(100) | Email pengarang | - |
| biografi | TEXT | Biografi singkat | - |
| negara | VARCHAR(50) | Negara asal | - |

**Contoh Data:**
```
id_pengarang: PG001
nama: Andrea Hirata
alamat: Belitung, Indonesia
telepon: 081234567890
email: andrea@example.com
biografi: Penulis novel Laskar Pelangi
negara: Indonesia
```

---

### 5. 🏷️ KATEGORI (Category)

Entitas yang menyimpan kategori/genre buku.

| Atribut | Tipe Data | Keterangan | Constraint |
|---------|-----------|------------|------------|
| **id_kategori** | VARCHAR(20) | ID unik kategori | PRIMARY KEY |
| nama_kategori | VARCHAR(50) | Nama kategori | NOT NULL, UNIQUE |
| deskripsi | TEXT | Deskripsi kategori | - |

**Contoh Data:**
```
id_kategori: K001
nama_kategori: Teknologi
deskripsi: Buku-buku tentang teknologi dan komputer
```

---

### 6. 🔗 BUKU_KATEGORI (Book-Category Junction)

Tabel penghubung untuk relasi many-to-many antara Buku dan Kategori.

| Atribut | Tipe Data | Keterangan | Constraint |
|---------|-----------|------------|------------|
| **id_buku** | VARCHAR(20) | ID buku | FOREIGN KEY, PRIMARY KEY |
| **id_kategori** | VARCHAR(20) | ID kategori | FOREIGN KEY, PRIMARY KEY |

---

## 🔗 Relasi Antar Entitas

### 1. ANGGOTA ←→ PEMINJAMAN (One-to-Many)

```
ANGGOTA (1) ----< PEMINJAMAN (N)
```

**Penjelasan:**
- Satu anggota dapat melakukan banyak peminjaman
- Setiap peminjaman hanya dilakukan oleh satu anggota
- **Kardinalitas:** 1:N
- **Foreign Key:** `id_anggota` di tabel PEMINJAMAN

**Aturan Bisnis:**
- Anggota harus terdaftar sebelum bisa meminjam
- Anggota dengan status "tidak aktif" tidak bisa meminjam
- Maksimal peminjaman aktif per anggota: 3 buku

---

### 2. BUKU ←→ PEMINJAMAN (One-to-Many)

```
BUKU (1) ----< PEMINJAMAN (N)
```

**Penjelasan:**
- Satu buku dapat dipinjam berkali-kali (dalam waktu berbeda)
- Setiap peminjaman hanya untuk satu buku
- **Kardinalitas:** 1:N
- **Foreign Key:** `id_buku` di tabel PEMINJAMAN

**Aturan Bisnis:**
- Buku hanya bisa dipinjam jika status "tersedia"
- Stok buku berkurang saat dipinjam
- Stok bertambah saat dikembalikan

---

### 3. PENGARANG ←→ BUKU (One-to-Many)

```
PENGARANG (1) ----< BUKU (N)
```

**Penjelasan:**
- Satu pengarang dapat menulis banyak buku
- Setiap buku memiliki satu pengarang utama
- **Kardinalitas:** 1:N
- **Foreign Key:** `id_pengarang` di tabel BUKU

**Catatan:**
- Untuk buku dengan multiple authors, bisa menggunakan tabel junction terpisah
- Saat ini simplified menjadi one-to-many

---

### 4. BUKU ←→ KATEGORI (Many-to-Many)

```
BUKU (M) ----< BUKU_KATEGORI >---- KATEGORI (N)
```

**Penjelasan:**
- Satu buku dapat memiliki banyak kategori
- Satu kategori dapat dimiliki banyak buku
- **Kardinalitas:** M:N
- **Junction Table:** BUKU_KATEGORI

**Contoh:**
```
Buku "Pemrograman Flutter" bisa memiliki kategori:
- Teknologi
- Pemrograman
- Mobile Development
```

---

## 📊 Diagram ERD (Text Representation)

```
┌─────────────────────┐
│     ANGGOTA         │
├─────────────────────┤
│ PK id_anggota       │
│    nama             │
│    alamat           │
│    telepon          │
│    email            │
│    nis              │
│    kelas            │
│    status           │
└─────────────────────┘
         │
         │ 1
         │
         │ meminjam
         │
         │ N
         ▼
┌─────────────────────┐
│   PEMINJAMAN        │
├─────────────────────┤
│ PK id_peminjaman    │
│ FK id_anggota       │
│ FK id_buku          │
│    tgl_peminjaman   │
│    tgl_kembali      │
│    tgl_pengembalian │
│    status           │
│    denda            │
└─────────────────────┘
         ▲
         │ N
         │
         │ dipinjam
         │
         │ 1
         │
┌─────────────────────┐         ┌─────────────────────┐
│       BUKU          │    M:N  │     KATEGORI        │
├─────────────────────┤◄───────►├─────────────────────┤
│ PK id_buku          │         │ PK id_kategori      │
│    judul            │         │    nama_kategori    │
│    penulis          │         │    deskripsi        │
│    penerbit         │         └─────────────────────┘
│    tahun_terbit     │
│    isbn             │
│    stok             │
│    status           │
│ FK id_pengarang     │
└─────────────────────┘
         ▲
         │ N
         │
         │ menulis
         │
         │ 1
         │
┌─────────────────────┐
│    PENGARANG        │
├─────────────────────┤
│ PK id_pengarang     │
│    nama             │
│    alamat           │
│    telepon          │
│    email            │
│    biografi         │
│    negara           │
└─────────────────────┘
```

---

## 🔑 Constraints dan Aturan

### Primary Keys (PK)
- `id_anggota` → ANGGOTA
- `id_buku` → BUKU
- `id_peminjaman` → PEMINJAMAN
- `id_pengarang` → PENGARANG
- `id_kategori` → KATEGORI
- `(id_buku, id_kategori)` → BUKU_KATEGORI (Composite PK)

### Foreign Keys (FK)
- `PEMINJAMAN.id_anggota` → `ANGGOTA.id_anggota`
- `PEMINJAMAN.id_buku` → `BUKU.id_buku`
- `BUKU.id_pengarang` → `PENGARANG.id_pengarang`
- `BUKU_KATEGORI.id_buku` → `BUKU.id_buku`
- `BUKU_KATEGORI.id_kategori` → `KATEGORI.id_kategori`

### Unique Constraints
- `ANGGOTA.email`
- `ANGGOTA.nis`
- `BUKU.isbn`
- `KATEGORI.nama_kategori`

### Check Constraints
- `BUKU.stok >= 0`
- `PEMINJAMAN.tanggal_kembali > tanggal_peminjaman`
- `PEMINJAMAN.denda >= 0`

---

## 📈 Normalisasi Database

Database ini sudah dalam bentuk **3NF (Third Normal Form)**:

### 1NF (First Normal Form) ✅
- Semua atribut bernilai atomic (tidak ada multi-value)
- Setiap tabel memiliki primary key
- Tidak ada repeating groups

### 2NF (Second Normal Form) ✅
- Sudah memenuhi 1NF
- Semua non-key attributes fully dependent pada primary key
- Tidak ada partial dependency

### 3NF (Third Normal Form) ✅
- Sudah memenuhi 2NF
- Tidak ada transitive dependency
- Semua non-key attributes hanya dependent pada primary key

---

## 🎯 Indeks untuk Optimasi

Untuk meningkatkan performa query, buat indeks pada:

```sql
-- Index untuk pencarian
CREATE INDEX idx_buku_judul ON BUKU(judul);
CREATE INDEX idx_anggota_nama ON ANGGOTA(nama);
CREATE INDEX idx_anggota_nis ON ANGGOTA(nis);

-- Index untuk foreign keys
CREATE INDEX idx_peminjaman_anggota ON PEMINJAMAN(id_anggota);
CREATE INDEX idx_peminjaman_buku ON PEMINJAMAN(id_buku);
CREATE INDEX idx_buku_pengarang ON BUKU(id_pengarang);

-- Index untuk filtering
CREATE INDEX idx_peminjaman_status ON PEMINJAMAN(status);
CREATE INDEX idx_buku_status ON BUKU(status);
CREATE INDEX idx_anggota_status ON ANGGOTA(status);
```

---

## 📝 Catatan Implementasi

1. **Auto Increment:** Gunakan UUID atau auto-increment untuk ID
2. **Soft Delete:** Pertimbangkan soft delete untuk data historis
3. **Audit Trail:** Tambahkan `created_at`, `updated_at`, `deleted_at`
4. **Triggers:** Buat trigger untuk update stok buku otomatis
5. **Views:** Buat views untuk laporan yang sering digunakan

---

**Dibuat untuk:** Perpustakaan SMKN12  
**Versi:** 1.0  
**Tanggal:** 10 Februari 2026  
**Penyusun:** Sistem Manajemen Perpustakaan Digital
